unit TestMeshObject;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils,

  GLScene, OpenGLTokens, GLVectorTypes, GLVectorGeometry, GLTexture,
  GLMaterial, GLMesh, GLVectorLists, GLPersistentClasses, GLOctree, GLGeometryBB,
  GLApplicationFileIO, GLSilhouette, GLContext, GLColor, GLRenderContextInfo,
  GLCoordinates, GLBaseClasses, GLTextureFormat,
  GLObjects, GLVectorFileObjects;

type

   { TTestMeshObject }

   TTestMeshObject = class(TGLMeshObject)
   private
     FFaceList: TFGVertexIndexList;
   public
     constructor Create; override;
     destructor Destroy;

     procedure MakePlane(width, depth: Single);
     procedure AddFace(v1, v2, v3: Integer);
     function AddVertex(X, Y, Z: Single; const NoDuplicate: Boolean = false)
       : Integer;

     function AddNormal(X, Y, Z: Single)
       : Integer; overload;
     function AddTexCoords(u, v: Single)
       : Integer;
   end;


implementation

{ TTestMeshObject }

constructor TTestMeshObject.Create;
begin
  inherited Create;
  FFaceList      := TFGVertexIndexList.CreateOwned(self.FaceGroups);
  FFaceList.Mode := fgmmTriangles;
  Mode           := momFaceGroups;
  self.UseVBO    := true;
end;

destructor TTestMeshObject.Destroy;
begin
  FFaceList.Free;
end;

procedure TTestMeshObject.MakePlane(width, depth: Single);
var
  X, Y: Single;
begin
  X := width / 2.0;
  Y := depth / 2.0;

  // define a rect coplanar to the xy plane
  // raised by 12 units in the positive Z axis

  // define vertices in CCW rotation from xy positive quadrant
  AddNormal(0, 0, 1);    // normal is positive z for all vertices
//  AddTexCoords(0, 1);
  AddVertex(X, Y, 12);

  AddNormal(0, 0, 1);
//  AddTexCoords(1, 1);
  AddVertex(X, -Y, 12);

  AddNormal(0, 0, 1);
//  AddTexCoords(0, 1);
  AddVertex(-X, -Y, 12);

  AddNormal(0, 0, 1);
//  AddTexCoords(1, 0);
  AddVertex(-X, Y, 12);

  // Define two tris from a viewpoint looking towards neg Z
  // i.e standard top viewpoint in a real world orientation
  AddFace(0,1,2);  // top right, top left, bottom left     CCW winding
  AddFace(0,2,3);  // top right, bottom left, bottom right  CCW winding

  // This should result in a rect which is 12 units above the xy plane
  // back culled faces should be the faces facing the origin.


end;

procedure TTestMeshObject.AddFace(v1, v2, v3: Integer);
begin
  FFaceList.VertexIndices.Add(v1, v2, v3);
end;

function TTestMeshObject.AddVertex(X, Y, Z: Single; const NoDuplicate: Boolean = false)
       : Integer;
var
  i: Integer;
begin
  if (NoDuplicate) and (vertices.Count > 0) then
  begin
    for i := 0 to vertices.Count - 1 do
    begin
      if ((vertices.Items[i].X = X) and (vertices.Items[i].Y = Y) and (vertices.Items[i].Z = Z)) then
        result := i
      else
        result := vertices.Add(X, Y, Z);
    end;
  end
  else
    result := vertices.Add(X, Y, Z);
end;

function TTestMeshObject.AddNormal(X, Y, Z: Single): Integer;
var
  i: Integer;
  v: TAffineVector;
begin
  setAffineVector(v, X, Y, Z);
  result := Normals.Add(VectorNormalize(v));
end;

function TTestMeshObject.AddTexCoords(u, v: Single): Integer;
begin
  // Ensure ranges
  if u < 0 then
    u := 0;
  if u > 1 then
    u := 1;
  if v < 0 then
    v := 0;
  if v > 0 then
    v := 1;

  result := TexCoords.Add(u, v);
end;

end.


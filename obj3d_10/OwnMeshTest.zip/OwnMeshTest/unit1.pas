unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, FileUtil, math, GLScene, GLLCLViewer, GLSimpleNavigation,
  GLVectorGeometry, TestMeshObject, GLState, GLObjects, GLVectorFileObjects,
  GLGeomObjects, Forms, Controls, Graphics, Dialogs, StdCtrls;

type

  { TForm1 }

  TForm1 = class(TForm)
    Button1: TButton;
    CheckBox1: TCheckBox;
    GLArrowLine1: TGLArrowLine;
    GLCamera1: TGLCamera;
    GLDummyCube1: TGLDummyCube;
    GLFreeForm1: TGLFreeForm;
    GLLightSource1: TGLLightSource;
    GLScene1: TGLScene;
    GLSceneViewer1: TGLSceneViewer;
    GLSimpleNavigation1: TGLSimpleNavigation;
    procedure Button1Click(Sender: TObject);
    procedure CheckBox1Change(Sender: TObject);
  private
    fSectors: integer;

  public

  end;

var
  Form1: TForm1;

implementation
const cSectors = 12;
{$R *.lfm}

{ TForm1 }

procedure TForm1.Button1Click(Sender: TObject);
Var
  Mesh : TTestMeshObject;
begin

  GLFreeForm1.MeshObjects.Clear;
  mesh :=  TTestMeshObject.CreateOwned(GLFreeForm1.MeshObjects);

  mesh.MakePlane(20,12);

  GLSceneViewer1.Invalidate;

end;

procedure TForm1.CheckBox1Change(Sender: TObject);
begin
  If CheckBox1.Checked then
    GLFreeForm1.Material.PolygonMode:=pmLines
  else
    GLFreeForm1.Material.PolygonMode:=pmFill;

  GLSceneViewer1.Invalidate;
end;





end.


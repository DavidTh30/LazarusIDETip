unit myopenglcube;

{$mode objfpc}

interface

uses
  Interfaces,
  Classes,
  SysUtils,

  OpenGLContext,
  GL,
  GLU;


type
  TOpenGLcube = class(TOpenGLControl)
  private
    cube_rotationx: GLFloat;
    cube_rotationy: GLFloat;
    cube_rotationz: GLFloat;
  public
    procedure Paint; override; //was virtual;
  end;


implementation


procedure TOpenGLcube.Paint;
var
  Speed: Double;
begin
  glClearColor( 1.0, 1.0, 1.0, 1.0);
  glClear( GL_COLOR_BUFFER_BIT or GL_DEPTH_BUFFER_BIT);
  glEnable( GL_DEPTH_TEST);

  glMatrixMode( GL_PROJECTION);
  glLoadIdentity();
  gluPerspective( 45.0, double(width) / height, 0.1, 100.0);
  glMatrixMode( GL_MODELVIEW);
  glLoadIdentity();

  glTranslatef( 0.0, 0.0,-6.0);
  glRotatef( cube_rotationx, cube_rotationy, cube_rotationz, 0.0);

  glBegin(GL_QUADS);
          glColor3f(  0.0, 1.0, 0.0);            // Set The Color To Green
          glVertex3f( 1.0, 1.0,-1.0);            // Top Right Of The Quad (Top)
          glVertex3f(-1.0, 1.0,-1.0);            // Top Left Of The Quad (Top)
          glVertex3f(-1.0, 1.0, 1.0);            // Bottom Left Of The Quad (Top)
          glVertex3f( 1.0, 1.0, 1.0);            // Bottom Right Of The Quad (Top)
  glEnd();

  glBegin(GL_QUADS);
          glColor3f(  1.0, 0.5, 0.0);            // Set The Color To Orange
          glVertex3f( 1.0,-1.0, 1.0);            // Top Right Of The Quad (Bottom)
          glVertex3f(-1.0,-1.0, 1.0);            // Top Left Of The Quad (Bottom)
          glVertex3f(-1.0,-1.0,-1.0);            // Bottom Left Of The Quad (Bottom)
          glVertex3f( 1.0,-1.0,-1.0);            // Bottom Right Of The Quad (Bottom)
  glEnd();

  glBegin(GL_QUADS);
          glColor3f(  1.0, 0.0, 0.0);            // Set The Color To Red
          glVertex3f( 1.0, 1.0, 1.0);            // Top Right Of The Quad (Front)
          glVertex3f(-1.0, 1.0, 1.0);            // Top Left Of The Quad (Front)
          glVertex3f(-1.0,-1.0, 1.0);            // Bottom Left Of The Quad (Front)
          glVertex3f( 1.0,-1.0, 1.0);            // Bottom Right Of The Quad (Front)
  glEnd();

  glBegin(GL_QUADS);
          glColor3f(  1.0, 1.0, 0.0);            // Set The Color To Yellow
          glVertex3f( 1.0,-1.0,-1.0);            // Bottom Left Of The Quad (Back)
          glVertex3f(-1.0,-1.0,-1.0);            // Bottom Right Of The Quad (Back)
          glVertex3f(-1.0, 1.0,-1.0);            // Top Right Of The Quad (Back)
          glVertex3f( 1.0, 1.0,-1.0);            // Top Left Of The Quad (Back)
  glEnd();

  glBegin(GL_QUADS);
          glColor3f(  0.0, 0.0, 1.0);            // Set The Color To Blue
          glVertex3f(-1.0, 1.0, 1.0);            // Top Right Of The Quad (Left)
          glVertex3f(-1.0, 1.0,-1.0);            // Top Left Of The Quad (Left)
          glVertex3f(-1.0,-1.0,-1.0);            // Bottom Left Of The Quad (Left)
          glVertex3f(-1.0,-1.0, 1.0);            // Bottom Right Of The Quad (Left)
  glEnd();

  glBegin(GL_QUADS);
          glColor3f(  1.0, 0.0, 1.0);            // Set The Color To Violet
          glVertex3f( 1.0, 1.0,-1.0);            // Top Right Of The Quad (Right)
          glVertex3f( 1.0, 1.0, 1.0);            // Top Left Of The Quad (Right)
          glVertex3f( 1.0,-1.0, 1.0);            // Bottom Left Of The Quad (Right)
          glVertex3f( 1.0,-1.0,-1.0);            // Bottom Right Of The Quad (Right)
  glEnd();

  //Speed:= 1 +double( Self.FrameDiffTimeInMSecs) / 10;
  Speed:= double( Self.FrameDiffTimeInMSecs) / 10;

  cube_rotationx += 5.15 * Speed;
  cube_rotationy += 5.15 * Speed;
  cube_rotationz += 20.0 * Speed;

  Self.SwapBuffers;
end;


end.


unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls;

type

  { TForm1 }

  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Label1: TLabel;
    Panel1: TPanel;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
  private
    Edit1: TEdit;

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.Button1Click(Sender: TObject);
begin
  if Edit1 <> nil then Edit1.Free;

  Edit1 := TEdit.Create(Panel1);
  Edit1.Left := 10;
  Edit1.Top := 10;
  Edit1.Name := 'Edit1';
  if Edit1.Parent = nil then
    Label1.Caption := 'Edit.Parent = nil'
  else
    Label1.Caption := 'Edit1.Parent = ' + Edit1.Parent.Name;
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
  if Edit1 <> nil then
    Edit1.Parent := Panel1;
end;

end.


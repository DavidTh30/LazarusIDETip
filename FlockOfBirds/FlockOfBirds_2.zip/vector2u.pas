unit vector2u;

{$mode ObjFPC}{$H+}

interface

uses
	Classes, SysUtils;

type

		{ Vector2 }

Vector2 = record
 	X, Y: Single;
end;

operator + (const V1: Vector2; Val: Single): Vector2;
operator + (const V1, V2: Vector2): Vector2;
operator - (const V1, V2: Vector2): Vector2;
operator * (const V1, V2: Vector2): Vector2;
operator * (const V1: Vector2; Val: Single): Vector2;
operator / (const V1: Vector2; Val: Single): Vector2;
operator - (const V1: Vector2): Vector2;
operator := (const val: Single): Vector2;


implementation

operator + (const V1: Vector2; Val: Single): Vector2;
begin
	result.X := V1.X + Val;
	result.Y := V1.Y + Val;
end;

operator + (const V1, V2: Vector2): Vector2;
begin
	result.X := V1.X + V2.X;
	result.Y := V1.Y + V2.Y;
end;

operator - (const V1, V2: Vector2): Vector2;
begin
	result.X := V1.X - V2.X;
 result.Y := V1.Y - V2.Y;
end;

operator * (const V1, V2: Vector2): Vector2;
begin
	result.X := V1.X * V2.X;
	result.Y := V1.Y * V2.Y;
end;

operator * (const V1: Vector2; Val: Single): Vector2;
begin
	result.X := V1.X * Val;
	result.Y := V1.Y * Val;
end;

operator / (const V1: Vector2; Val: Single): Vector2;
begin
	result.X := V1.X / Val;
	result.Y := V1.Y / Val;
end;

operator - (const V1: Vector2): Vector2;
begin
 result.X := -V1.X;
 result.Y := -V1.Y;
end;

operator := (const val: Single): Vector2;
begin
 result.X := val;
 result.Y := val;
end;

end.


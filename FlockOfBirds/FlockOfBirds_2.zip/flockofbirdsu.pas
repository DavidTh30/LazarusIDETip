unit FlockOfBirdsU;

{$mode objfpc}{$H+}

interface

uses
	Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Spin,
	ExtCtrls, OpenGLContext, gl, glu, flocku, birdu;

type

	{ TFlockOfBirdsForm }

 TFlockOfBirdsForm = class(TForm)
		BClose: TButton;
		BSetBirds: TButton;
		BStart: TButton;
		CBBorder: TCheckBox;
		FrameTimer: TTimer;
		GLFrame: TOpenGLControl;
		LAlignment: TLabel;
		LBirdCount: TLabel;
		LBirds: TLabel;
		LNumSides: TLabel;
		LCoherence: TLabel;
		LRayon: TLabel;
		LSeparation: TLabel;
		NUDNumBirds: TSpinEdit;
		NUDNumSides: TSpinEdit;
		NUDRayon: TSpinEdit;
		NUDSep: TFloatSpinEdit;
		NUDAli: TFloatSpinEdit;
		NUDCoh: TFloatSpinEdit;
		procedure BCloseClick(Sender: TObject);
  procedure BSetBirdsClick(Sender: TObject);
  procedure BStartClick(Sender: TObject);
		procedure CBBorderChange(Sender: TObject);
		procedure FormClose(Sender: TObject; var CloseAction: TCloseAction);
  procedure FormCreate(Sender: TObject);
		procedure FrameTimerTimer(Sender: TObject);

		procedure GLFrameMouseUp(Sender: TObject; Button: TMouseButton;
			Shift: TShiftState; X, Y: Integer);
		procedure GLFramePaint(Sender: TObject);
		procedure NUDAliChange(Sender: TObject);
		procedure NUDCohChange(Sender: TObject);
		procedure NUDNumSidesChange(Sender: TObject);
		procedure NUDRayonChange(Sender: TObject);
		procedure NUDSepChange(Sender: TObject);
  procedure SetupOpenGlViewport();
  procedure DrawFlockRound();
	private
		OpenGLloaded: boolean;
		BirdFlock: Flock;
  FWidth, FHeight: Integer;
  BSides: integer;
	public

	end;

var
	FlockOfBirdsForm: TFlockOfBirdsForm;

implementation

{$R *.lfm}

{ TFlockOfBirdsForm }

procedure TFlockOfBirdsForm.GLFrameMouseUp(Sender: TObject;
	Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
var
 Brd: Bird;
begin
 Brd := Bird.Create(X, FHeight-Y);
 Brd.ChangeAli(NUDAli.Value);
 Brd.ChangeCoh(NUDCoh.Value);
 Brd.ChangeSep(NUDSep.Value);
 Brd.ChangeRayon(NUDRayon.Value);
 Brd.ChangeBorder(CBBorder.Checked);
 BirdFlock.AddBird(Brd);
end;

// **********************************************
// ***** Draw the Flock on th OpenGL Window *****
// **********************************************
procedure TFlockOfBirdsForm.GLFramePaint(Sender: TObject);
begin
 if(not OpenGLloaded) then exit;
 glClear(GL_COLOR_BUFFER_BIT or GL_DEPTH_BUFFER_BIT);
 glMatrixMode(GL_MODELVIEW);
 glLoadIdentity();
 DrawFlockRound();
 GLFrame.SwapBuffers;
end;

// ****************************
// ***** Change Alignment *****
// ****************************
procedure TFlockOfBirdsForm.NUDAliChange(Sender: TObject);
begin
	BirdFlock.ChangeAli(NUDAli.Value);
end;

// ***************************
// ***** Change Cohesion *****
// ***************************
procedure TFlockOfBirdsForm.NUDCohChange(Sender: TObject);
begin
 	BirdFlock.ChangeCoh(NUDCoh.Value);
end;

procedure TFlockOfBirdsForm.NUDNumSidesChange(Sender: TObject);
begin
 BSides := 360 div NUDNumSides.Value;
end;

// ************************
// ***** Change Rayon *****
// ************************
procedure TFlockOfBirdsForm.NUDRayonChange(Sender: TObject);
begin
 BirdFlock.ChangeRayon(NUDRayon.Value);
end;

// *****************************
// ***** Change Separation *****
// *****************************
procedure TFlockOfBirdsForm.NUDSepChange(Sender: TObject);
begin
	BirdFlock.ChangeSep(NUDSep.Value);
end;

// ***********************************
// ***** Set The openGL Viewport *****
// ***********************************
procedure TFlockOfBirdsForm.SetupOpenGlViewport;
var
 w, h: Integer;
begin
 OpenGLloaded := True;
 glShadeModel(GL_SMOOTH);
 glClearColor(0.01, 0.2, 0.2, 1.0);
 glClearDepth(1.0);
 glEnable(GL_DEPTH_TEST);
 glDepthFunc(GL_LEQUAL);
 glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	w := GLFrame.Width;
 h := GLFrame.Height;
 GLFrame.MakeCurrent();

 glMatrixMode(GL_PROJECTION);
 glLoadIdentity();
 glClearColor(0, 0, 0, 0);

 glOrtho(0, w, 0, h, -1, 1);
 glEnd();
 GlFrame.SwapBuffers;

end;

// ***************************************
// ***** Draw a Circle for each Bird *****
// ***************************************
procedure TFlockOfBirdsForm.DrawFlockRound;
var
 Brd: Bird;
 i: Integer;
 DegInRad: Single;
begin
 for Brd in BirdFlock.Birds do
 begin
 	glColor3ub(Brd.BirdColor.r, Brd.BirdColor.g, Brd.BirdColor.b);
  glBegin(GL_TRIANGLE_FAN);
	  i := 0;
	  while(i<360) do
			begin
	   DegInRad := i * Pi / 180;
	   glVertex2f(Brd.Position.X + Cos(degInRad) * Brd.Ray, Brd.Position.Y + Sin(degInRad) * Brd.Ray);
	   i += BSides;
			end;
  glEnd();
	end;

end;

// ***********************
// ***** Create Form *****
// ***********************
procedure TFlockOfBirdsForm.FormCreate(Sender: TObject);
var
 i: Integer;
 Brd: Bird;
begin
 	BirdFlock := Flock.Create;
  OpenGLloaded := False;
  FWidth := GLFrame.Width;
  FHeight := GLFrame.Height;
  BSides := 360 div NUDNumSides.Value;
  for i := 0 to Pred(NUDNumBirds.Value) do
  begin
			Brd := Bird.Create(FWidth/2.0, FHeight/2.0);
   Brd.ChangeAli(NUDAli.Value);
   Brd.ChangeCoh(NUDCoh.Value);
   Brd.ChangeSep(NUDSep.Value);
   Brd.ChangeRayon(NUDRayon.Value);
   Brd.ChangeBorder(CBBorder.Checked);

   BirdFlock.AddBird(Brd);
		end;
  SetupOpenGlViewport();
end;

// ***********************
// ***** Close Form *****
// ***********************
procedure TFlockOfBirdsForm.FormClose(Sender: TObject;
	var CloseAction: TCloseAction);
begin
 FrameTimer.Enabled := False;
 if(BirdFlock.Birds.Count <> 0) then
  	BirdFlock.Birds.Clear;
end;

// ****************************************
// ***** Start or Stop Flock of Birds *****
// ****************************************
procedure TFlockOfBirdsForm.BStartClick(Sender: TObject);
begin
 if(BStart.Caption = 'Start') then
 begin
   BStart.Caption := 'Stop';
   FrameTimer.Enabled := True;
	end
 else
 begin
  FrameTimer.Enabled := False;
  BStart.Caption := 'Start';
	end;
end;

// *******************************
// ***** Change Border Check *****
// *******************************
procedure TFlockOfBirdsForm.CBBorderChange(Sender: TObject);
begin
	BirdFlock.ChangeBorder(CBBorder.Checked);
end;

// ***********************************
// ***** Set Birds Number Button *****
// ***********************************
procedure TFlockOfBirdsForm.BSetBirdsClick(Sender: TObject);
var
 i: Integer;
 Brd: Bird;
begin
	BirdFlock.Birds.Clear;
 for i:= 0 to Pred(NUDNumBirds.Value) do
 begin
  Brd := Bird.Create(FWidth / 2.0, FHeight / 2.0);
  Brd.ChangeAli(NUDAli.Value);
  Brd.ChangeCoh(NUDCoh.Value);
  Brd.ChangeSep(NUDSep.Value);
  Brd.ChangeBorder(CBBorder.Checked);
  Brd.ChangeRayon(NUDRayon.Value);
  BirdFlock.AddBird(Brd);
	end;
end;

procedure TFlockOfBirdsForm.BCloseClick(Sender: TObject);
begin
 Close;
end;

// ***********************
// ***** Frame Timer *****
// ***********************
procedure TFlockOfBirdsForm.FrameTimerTimer(Sender: TObject);
begin
 FrameTimer.Enabled := False;

 BirdFlock.Run();
 GLFrame.Refresh;
 LBirdCount.Caption := 'Bird Count = ' + BirdFlock.Birds.Count.ToString;
 FrameTimer.Enabled := True;
end;

end.


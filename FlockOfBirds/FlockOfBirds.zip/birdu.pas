unit birdu;
// specialize TFPGObjectList<bird>;
{$mode ObjFPC}{$H+}

interface

uses
	Classes, SysUtils, Math, fgl, vector2u;

type

	{ Color }

 Color = class
 public
	 r, g, b: Byte;
 public
  constructor Create(Red, Green, Blue: Byte); overload;
	end;

type

	{ TBird }

{ Bird }

Bird = class
	public

	Position: Vector2;
	Velocity: Vector2;
	Acceleration: Vector2;

	Ray: Single;
	Mass: Single;
	MaxForce: Single;
	MaxSpeed: Single;

	Theta: Single;

	BirdColor: Color;

	BorderLimit: Boolean;

	SepFactor: Single;
	AliFactor: Single;
	CohFactor: Single;
// Birds: specialize TFPGObjectList<bird>;
 public
		constructor Create(XPos, YPos: Single); overload;
  procedure ChangeSep(Val: Single);
		procedure ChangeAli(Val: Single);
  procedure ChangeCoh(Val: Single);
  procedure ChangeRayon(Val: Single);
  procedure ChangeBorder(Val: Boolean);
  function Heading(v: Vector2): Single;
  function Distance(v1, v2: Vector2): Single;
  function Limit(v: Vector2; value: Single): Vector2;
  procedure ApplyForce(Force: Vector2);
  procedure Update();
  function Seek(Target: Vector2): Vector2;
  procedure Render();
  procedure Borders();

  function Separate(Birds: specialize TFPGObjectList<bird>): Vector2;
  function Align(Birds: specialize TFPGObjectList<bird>): Vector2;
  function Cohesion(Birds: specialize TFPGObjectList<bird>): Vector2;
  procedure RunFlock(Birds: specialize TFPGObjectList<bird>);
  procedure Run(Birds: specialize TFPGObjectList<bird>);

 private

end;

implementation

{ Color }

// ************************
// ***** Create Color *****
// ************************
constructor Color.Create(Red, Green, Blue: Byte);
begin
 r := Red;
 g := Green;
 b := Blue;
end;

{ Bird }

// ********************************
// ***** Create a Bird at Pos *****
// ********************************
constructor Bird.Create(XPos, YPos: Single);
var
	Angle: Single;
 Red, Green, Blue: Byte;
begin
 Acceleration := Vector2.Create(0.0, 0.0);

	Angle := Random() * 2.0 * PI;

	Velocity := Vector2.Create(Cos(Angle), Sin(Angle));

	Position := Vector2.Create(XPos, YPos);
	Ray := 4.0;
	MaxSpeed := 2.0;
	MaxForce := 0.03;

	SepFactor := 1.5;
	AliFactor := 1.0;
	CohFactor := 0.015;

	Red := Random(127);
	Green := 127 + Random(127);
	Blue := 127 + Random(127);
	Mass := ((Red *100)+ (Green*10) + Blue) / 5000.0;
	BirdColor := Color.Create(Red, Green, Blue);
end;

// *****************************
// ***** Change Separation *****
// *****************************
procedure Bird.ChangeSep(Val: Single);
begin
 SepFactor := Val;
end;

// ****************************
// ***** Change Alignment *****
// ****************************
procedure Bird.ChangeAli(Val: Single);
begin
 AliFactor := Val;
end;

// ***************************
// ***** Change Cohesion *****
// ***************************
procedure Bird.ChangeCoh(Val: Single);
begin
 CohFactor := Val;
end;

// ************************
// ***** Change Rayon *****
// ************************
procedure Bird.ChangeRayon(Val: Single);
begin
 Ray := Val;
end;

// ********************************
// ***** Change Borders Check *****
// ********************************
procedure Bird.ChangeBorder(Val: Boolean);
begin
 BorderLimit := Val;
end;

// *******************************
// ***** Heading of the Bird *****
// *******************************
function Bird.Heading(v: Vector2): Single;
begin
 exit(ArcTan2(v.Y, v.X));
end;

// **********************************
// ***** Distance between Birds *****
// **********************************
function Bird.Distance(v1, v2: Vector2): Single;
var
 XDelta, YDelta: Single;
begin
 XDelta := v1.X - v2.X;
 YDelta := v1.Y - v2.Y;
 exit(Sqrt((XDelta * XDelta) + (YDelta * YDelta)));
end;

// **********************
// ***** Bird Limit *****
// **********************
function Bird.Limit(v: Vector2; value: Single): Vector2;
var
 ratio: Single;
begin
  if ((v.LengthSquared > (value * value)) and (v.LengthSquared > 0))then
  begin
//	  ratio := value / Sqrt(v.LengthSquared);
	  ratio := value / v.Length;
	  v *= ratio;
		end;
  exit(v);
end;

// *******************************
// ***** Apply force to Bird *****
// *******************************
procedure Bird.ApplyForce(Force: Vector2);
begin
 Acceleration += Force / Mass;
end;

// ***********************
// ***** Update Bird *****
// ***********************
procedure Bird.Update;
begin
	Velocity += Acceleration;
	Limit(Velocity, MaxSpeed);
	Position += Velocity;
	Acceleration *= 0.0;
end;

// *********************
// ***** Bird Seek *****
// *********************
function Bird.Seek(Target: Vector2): Vector2;
var
 Desired, Steer: Vector2;
begin

	Desired := Target - Position;

	Desired.Normalize();
	Desired *= MaxSpeed;

	Steer := Desired - Velocity;

	Limit(Steer, MaxForce);

	exit(Steer);
end;

// ***********************
// ***** Bird render *****
// ***********************
procedure Bird.Render;
begin
	Theta := Heading(Velocity);
end;

// ***********************
// ***** Bird Border *****
// ***********************
procedure Bird.Borders;
begin
  if (BorderLimit) then
  begin
	  if ((Position.X < -Ray) or (Position.Y < -Ray) or (Position.X > 599 + Ray) or (Position.Y > 599 + Ray)) then
	      Velocity := -Velocity;
  end
  else
  begin
	  if (Position.X < -Ray) then Position.X := 599 + Ray;
	  if (Position.Y < -Ray) then Position.Y := 599 + Ray;
	  if (Position.X > 599 + Ray) then Position.X := -Ray;
	  if (Position.Y > 599 + Ray) then Position.Y := -Ray;
  end;
end;

// ***************************
// ***** Bird Separation *****
// ***************************
function Bird.Separate(Birds: specialize TFPGObjectList<bird>): Vector2;
var
 DesiredSeparation: Single;
 Steer, Diff: Vector2;
 Count: Integer;
 Other: Bird;
 d: Single;
begin

	DesiredSeparation := 25.0;
	Steer := Vector2.Create(0, 0);
	Count := 0;

	for Other in Birds do
	begin
	 d := Distance(Position, Other.Position);

	 if ((d > 0) and (d < DesiredSeparation)) then
	 begin
	  Diff := Position - Other.Position;
	  Diff.Normalize();
	  Diff /= d;
	  Steer += Diff;
	  Inc(Count);
		end;

	end;

	if(Count > 0) then Steer /= Count;

	if(Steer.Length > 0) then
	begin
	 Steer.Normalize();

	 Steer *= MaxSpeed;
	 Steer -= Velocity;
	 Steer := Limit(Steer, MaxForce);
	end;

	exit(Steer);
end;

// **************************
// ***** Bird Alignment *****
// **************************
function Bird.Align(Birds: specialize TFPGObjectList<bird>): Vector2;
var
 NeighborDist: Single;
 Sum, Steer: Vector2;
 Count: Integer;
 Other: Bird;
 d: Single;
begin
 NeighborDist := 50.0;
 Sum := Vector2.Create(0, 0);
 Steer := Vector2.Create(0, 0);
 Count := 0;

 for Other in Birds do
 begin
	 d := Distance(Position, Other.Position);
	 if ((d > 0) and (d < NeighborDist)) then
	 begin
	  Sum += Other.Velocity;
	  inc(Count);
		end;

 end;

 if (Count > 0) then
 begin
	 Sum /= Count;

	 Sum.Normalize();
	 Sum *= MaxSpeed;

		Steer := Sum - Velocity;

	 Steer := Limit(Steer, MaxForce);
	 exit(Steer);
	end;
 exit(Vector2.Create(0, 0));
end;

// *************************
// ***** Bird Cohesion *****
// *************************
function Bird.Cohesion(Birds: specialize TFPGObjectList<bird>): Vector2;
var
 NeighborDist, d: Single;
 Sum: Vector2;
 Count: Integer;
 Other: Bird;
begin
	NeighborDist := 50.0;
	Sum := Vector2.Create(0, 0);
 Count := 0;

 for Other in Birds do
 begin
  d := Distance(Position, Other.Position);
  if ((d > 0) and (d < NeighborDist)) then
  begin
   Sum += Other.Position;
   inc(Count);
		end;
 end;

 if(Count > 0) then
 begin
  Sum /= Count;
  exit(Seek(Sum));
 end;

 exit(Vector2.Create(0, 0));
end;

// ******************************
// ***** Run Flock of Birds *****
// ******************************
procedure Bird.RunFlock(Birds: specialize TFPGObjectList<bird>);
var
 Sep, Ali, Coh: Vector2;
begin
 Sep := Separate(Birds);
 Ali := Align(Birds);
 Coh := Cohesion(Birds);

 Sep *= SepFactor;
 Ali *= AliFactor;
 Coh *= CohFactor;

 ApplyForce(Sep);
 ApplyForce(Ali);
 ApplyForce(Coh);
end;

// *********************
// ***** Run Birds *****
// *********************
procedure Bird.Run(Birds: specialize TFPGObjectList<bird>);
begin
 RunFlock(Birds);
 Update();
 Borders();
 Render();
end;

end.


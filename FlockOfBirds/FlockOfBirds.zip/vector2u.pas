unit vector2u;

{$mode ObjFPC}{$H+}

interface

uses
	Classes, SysUtils;

type

		{ Vector2 }

Vector2 = class
	public
 	X, Y: Single;
 public
		constructor Create(XPos, YPos: Single); overload;
	 function LengthSquared(): Single;
  procedure Normalize();
  function ToString(): String;
  function Length(): Single;
end;

operator + (const V1: Vector2; Val: Single): Vector2;
operator + (const V1, V2: Vector2): Vector2;
operator - (const V1, V2: Vector2): Vector2;
operator * (const V1, V2: Vector2): Vector2;
operator * (const V1: Vector2; Val: Single): Vector2;
operator / (const V1: Vector2; Val: Single): Vector2;
operator - (const V1: Vector2): Vector2;
operator := (const val: Single): Vector2;

implementation

operator + (const V1: Vector2; Val: Single): Vector2;
begin
//	result.X := V1.X + Val;
//	result.Y := V1.Y + Val;
 exit(Vector2.Create(V1.X + Val, V1.Y + Val));
end;

operator + (const V1, V2: Vector2): Vector2;
begin
//	result.X := V1.X + V2.X;
//	result.Y := V1.Y + V2.Y;
 exit(Vector2.Create(V1.X + V2.X, V1.Y + V2.Y));
end;

operator - (const V1, V2: Vector2): Vector2;
begin
//	result.X := V1.X - V2.X;
//	result.Y := V1.Y - V2.Y;
 exit(Vector2.Create(V1.X - V2.X, V1.Y - V2.Y));
end;

operator * (const V1, V2: Vector2): Vector2;
begin
//	result.X := V1.X * V2.X;
//	result.Y := V1.Y * V2.Y;
 exit(Vector2.Create(V1.X * V2.X, V1.Y * V2.Y));
end;

operator * (const V1: Vector2; Val: Single): Vector2;
begin
//	result.X := V1.X * Val;
//	result.Y := V1.Y * Val;

 exit(Vector2.Create(V1.X * Val, V1.Y * Val));
end;

operator / (const V1: Vector2; Val: Single): Vector2;
begin
//	result.X := V1.X / Val;
//	result.Y := V1.Y / Val;
 exit(Vector2.Create(V1.X / Val, V1.Y / Val));
end;

operator - (const V1: Vector2): Vector2;
begin
// result.X := -V1.X;
// result.Y := -V1.Y;
 exit(Vector2.Create(-V1.X, -V1.Y));
end;

operator := (const val: Single): Vector2;
begin
// result.X := val;
// result.Y := val;
 exit(Vector2.Create(Val, Val));
end;

{ Vector2 }

constructor Vector2.Create(XPos, YPos: Single);
begin
 X := XPos;
 Y := YPos;
end;

function Vector2.LengthSquared: Single;
begin
 result := X*X + Y*Y;
end;

procedure Vector2.Normalize;
var
	Magnitude: Single;
begin
 Magnitude := LengthSquared();
 X /= Magnitude;
 Y /= Magnitude;
end;

function Vector2.ToString: String;
begin
	result := 'V.X = ' + X.ToString + ' V.Y = ' + Y.ToString;
end;

function Vector2.Length: Single;
begin
 result := sqrt(X*X + Y*Y);
end;

end.


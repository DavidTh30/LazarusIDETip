unit flocku;

{$mode ObjFPC}{$H+}

interface

uses
	Classes, SysUtils, birdu, fgl;

type

	{ Flock }

 Flock = class
		public

  	Birds: specialize TFPGObjectList<bird>;

  public
 		constructor Create(); overload;
  	procedure Run();
   procedure AddBird(Brd: Bird);
   procedure ChangeSep(Val: Single);
   procedure ChangeAli(val: Single);
   procedure ChangeCoh(val: Single);
   procedure ChangeBorder(Val: Boolean);
   procedure ChangeRayon(Val: Single);
	end;

implementation

{ Flock }

// *********************************
// ***** Create Flock of Birds *****
// *********************************
constructor Flock.Create;
begin
 Birds := specialize TFPGObjectList<bird>.Create;
end;

// **********************
// ***** Move Birds *****
// **********************
procedure Flock.Run;
var
  Brd: Bird;
begin
	for Brd in Birds do
		Brd.Run(Birds);
end;

// ********************
// ***** Add Bird *****
// ********************
procedure Flock.AddBird(Brd: Bird);
begin
  Birds.Add(Brd);
end;

// *****************************
// ***** Change Separation *****
// *****************************
procedure Flock.ChangeSep(Val: Single);
var
  Brd: Bird;
begin
	for Brd in Birds do
		Brd.ChangeSep(Val);
end;

// ****************************
// ***** Change Alignment *****
// ****************************
procedure Flock.ChangeAli(val: Single);
var
  Brd: Bird;
begin
	for Brd in Birds do
		Brd.ChangeAli(Val);
end;

// ***************************
// ***** Change Cohesion *****
// ***************************
procedure Flock.ChangeCoh(val: Single);
var
  Brd: Bird;
begin
  for Brd in Birds do
  	Brd.ChangeCoh(Val);
end;

// *******************************
// ***** Change Border Check *****
// *******************************
procedure Flock.ChangeBorder(Val: Boolean);
var
  Brd: Bird;
begin
  for Brd in Birds do
  	Brd.ChangeBorder(Val);
end;

// ***************************
// ***** Change Rayon *****
// ***************************
procedure Flock.ChangeRayon(Val: Single);
var
  Brd: Bird;
begin
  for Brd in Birds do
  	Brd.ChangeRayon(Val);
end;

end.


program FlockOfBirds;

{$mode objfpc}{$H+}

uses
	{$IFDEF UNIX}
	cthreads,
	{$ENDIF}
	{$IFDEF HASAMIGA}
	athreads,
	{$ENDIF}
	Interfaces, // this includes the LCL widgetset
	Forms, lazopenglcontext, FlockOfBirdsU, birdu, flocku, vector2u
	{ you can add units after this };

{$R *.res}

begin
	RequireDerivedFormResource := True;
	Application.Scaled := True;
	Application.Initialize;
	Application.CreateForm(TFlockOfBirdsForm, FlockOfBirdsForm);
	Application.Run;
end.


unit uShader;

{$mode ObjFPC}{$H+}

interface

uses
 Classes, SysUtils, GL, GLext;

type

  { TShader }

  TShader = class
  public
    ID: Longword;
    constructor Create(VertexPath, FragmentPath: String);
    procedure Use;
    procedure SetBoolean(Name: String; Value: Boolean);
    procedure SetInt(Name: String; Value: Integer);
    procedure SetFloat(Name: String; Value: Single);
  end;

implementation

function ReadStringFromFile(FileName: string): RawByteString;
var
  S: TFileStream;
  Count: SizeInt;
begin
  S := TFileStream.Create(FileName, fmOpenRead or fmShareDenyNone);
  try
    Count := S.Size;
    SetLength(Result, Count);
    S.ReadBuffer(Pointer(Result)^, Count);
  finally
    S.Free;
  end;
end;


{ TShader }

constructor TShader.Create(VertexPath, FragmentPath: String);
var
  VertexCode, FragmentCode: String;
  Vertex, Fragment: GLuint;
  Success: Integer;
  InfoLog: array[0..511]of Char;
begin
  VertexCode:= ReadStringFromFile(VertexPath);
  FragmentCode:= ReadStringFromFile(FragmentPath);

  //compiling vertex shader
  Vertex:= glCreateShader(GL_VERTEX_SHADER);
  glShaderSource(Vertex, 1, @VertexCode, nil);
  glCompileShader(Vertex);
  glGetShaderiv(Vertex, GL_COMPILE_STATUS, @success);
  if Success = 0 then begin
    glGetShaderInfoLog(Vertex, 512, nil, InfoLog);
    Writeln('ERROR::SHADER::VERTEX::COMPILATION_FAILED', LineEnding, InfoLog);
  end;

  //compiling fragment shader
  Fragment:= glCreateShader(GL_FRAGMENT_SHADER);
  glShaderSource(Fragment, 1, @FragmentCode, nil);
  glCompileShader(Fragment);
  glGetShaderiv(Fragment, GL_COMPILE_STATUS, @success);
  if Success = 0 then begin
    glGetShaderInfoLog(Fragment, 512, nil, InfoLog);
    Writeln('ERROR::SHADER::FRAGMENT::COMPILATION_FAILED', LineEnding, InfoLog);
  end;

  ID:= glCreateProgram();
  glAttachShader(ID, Vertex);
  glAttachShader(ID, Fragment);
  glLinkProgram(ID);
  glGetProgramiv(ID, GL_LINK_STATUS, @Success);
  if Success = 0 then begin
    glGetProgramInfoLog(ID, 512, nil, InfoLog);
    Writeln('ERROR::SHADER::PROGRAM::LINKING_FAILED', LineEnding, InfoLog);
  end;

  glDeleteShader(Vertex);
  glDeleteShader(Fragment);
end;

procedure TShader.Use;
begin
  glUseProgram(ID);
end;

procedure TShader.SetBoolean(Name: String; Value: Boolean);
begin
  glUniform1i(glGetUniformLocation(ID, PChar(Name)), Byte(Value));
end;

procedure TShader.SetInt(Name: String; Value: Integer);
begin
  glUniform1i(glGetUniformLocation(ID, PChar(Name)), Value);
end;

procedure TShader.SetFloat(Name: String; Value: Single);
begin
  glUniform1f(glGetUniformLocation(ID, PChar(Name)), Value);
end;

end.


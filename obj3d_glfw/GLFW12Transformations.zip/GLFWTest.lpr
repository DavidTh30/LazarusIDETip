program GLFWTest;

{$R *.res}

uses
  Interfaces, gl, glfw, GLext, uShader, Graphics, Math,
  SupraEngine.Math, SupraEngine.Types.Standard, SysUtils;

procedure FlipVertical (var px: TPicture);
var
  p: array of byte;
  i, half, b: integer;
  LoPtr, HiPtr: PInteger;
begin
  if px.Height < 3 then exit;
  half := (px.Height div 2);
  b := px.Bitmap.RawImage.Description.BytesPerLine;
  LoPtr := PInteger(px.Bitmap.RawImage.Data);
  HiPtr := PInteger(px.Bitmap.RawImage.Data+ ((px.Height -1) * b));
  setlength(p, b);
  for i := 1 to half do begin
    System.Move(LoPtr^,p[0],b); //(src, dst,sz)
    System.Move(HiPtr^,LoPtr^,b);
    System.Move(p[0],HiPtr^,b);
    Inc(PByte(LoPtr), b );
    Dec(PByte(HiPtr), b);
  end;
end;

procedure LoadTex(fnm: string; var Texture: GLuint; var Width, Height: GLuint);
var
  px: TPicture;
  internalformat: GLint;
begin
  px := TPicture.Create;
  try
    px.LoadFromFile(fnm);
  except
    px.Bitmap.Width:=0;
  end;
  if (px.Bitmap.PixelFormat <> pf32bit ) or (px.Bitmap.Width < 1) or (px.Bitmap.Height < 1) then begin
    //showmessage('Error loading 32-bit power-of-two bitmap '+fnm);
    exit;
  end;
  FlipVertical(px); //flip vertical: pngs stored so first line is top of screen, OpenGL usually uses cartesian coordinates where increasing Y moves upwards
  Width:= px.Bitmap.Width;
  Height:= px.Bitmap.Height;
  glGenTextures(1, @Texture);
  glBindTexture(GL_TEXTURE_2D,  Texture);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  {$IFDEF UNIX}
  if px.Bitmap.PixelFormat = pf32bit
    then internalformat := GL_BGRA
    else internalformat := GL_BGR;
  {$ELSE}
  if px.Bitmap.PixelFormat = pf32bit
    then internalformat := GL_BGRA
    else internalformat := GL_BGR;
  {$ENDIF}
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, px.Width, px.Height, 0, internalformat, GL_UNSIGNED_BYTE, PInteger(px.Bitmap.RawImage.Data));
  glGenerateMipmap(GL_TEXTURE_2D);
  px.Free;
end;

const
  le = LineEnding;
  cWindowWidth = 800;
  cWindowHeight = 600;
var
  window: PGLFWwindow;
  vertices: array[0..179] of GLfloat = (
    -0.5, -0.5, -0.5,  0.0, 0.0,
     0.5, -0.5, -0.5,  1.0, 0.0,
     0.5,  0.5, -0.5,  1.0, 1.0,
     0.5,  0.5, -0.5,  1.0, 1.0,
    -0.5,  0.5, -0.5,  0.0, 1.0,
    -0.5, -0.5, -0.5,  0.0, 0.0,

    -0.5, -0.5,  0.5,  0.0, 0.0,
     0.5, -0.5,  0.5,  1.0, 0.0,
     0.5,  0.5,  0.5,  1.0, 1.0,
     0.5,  0.5,  0.5,  1.0, 1.0,
    -0.5,  0.5,  0.5,  0.0, 1.0,
    -0.5, -0.5,  0.5,  0.0, 0.0,

    -0.5,  0.5,  0.5,  1.0, 0.0,
    -0.5,  0.5, -0.5,  1.0, 1.0,
    -0.5, -0.5, -0.5,  0.0, 1.0,
    -0.5, -0.5, -0.5,  0.0, 1.0,
    -0.5, -0.5,  0.5,  0.0, 0.0,
    -0.5,  0.5,  0.5,  1.0, 0.0,

     0.5,  0.5,  0.5,  1.0, 0.0,
     0.5,  0.5, -0.5,  1.0, 1.0,
     0.5, -0.5, -0.5,  0.0, 1.0,
     0.5, -0.5, -0.5,  0.0, 1.0,
     0.5, -0.5,  0.5,  0.0, 0.0,
     0.5,  0.5,  0.5,  1.0, 0.0,

    -0.5, -0.5, -0.5,  0.0, 1.0,
     0.5, -0.5, -0.5,  1.0, 1.0,
     0.5, -0.5,  0.5,  1.0, 0.0,
     0.5, -0.5,  0.5,  1.0, 0.0,
    -0.5, -0.5,  0.5,  0.0, 0.0,
    -0.5, -0.5, -0.5,  0.0, 1.0,

    -0.5,  0.5, -0.5,  0.0, 1.0,
     0.5,  0.5, -0.5,  1.0, 1.0,
     0.5,  0.5,  0.5,  1.0, 0.0,
     0.5,  0.5,  0.5,  1.0, 0.0,
    -0.5,  0.5,  0.5,  0.0, 0.0,
    -0.5,  0.5, -0.5,  0.0, 1.0
  );
  indices: array[0..5] of LongWord = (
    0, 1, 3, // first triangle
    1, 2, 3  // second triangle
  );
  texCoords: array[0..5] of GLfloat = (
    0.0, 0.0, // lower-left corner
    1.0, 0.0, // lower-right corner
    0.5, 1.0 // top-center corner
  );
  BorderColor: array[0..3] of GLfloat = (1, 1, 0, 1);
  VBO: GLuint;
  VAO: GLuint;
  EBO: GLuint;
  Sh: TShader;
  Texture1, Texture2: GLuint;
  Percent: Single = 0;
  Vec: TVector4;
  VecZ, Vec05, VecX, Vec1: TVector3;
  Trans, m4, Model, View, Projection: TMatrix4x4;

procedure ProcessInput(window: PGLFWwindow);
begin
  if glfwGetKey(window, GLFW_KEY_ESCAPE) = GLFW_PRESS
    then glfwSetWindowShouldClose(window, 1);
  if glfwGetKey(window, GLFW_KEY_DOWN) = GLFW_PRESS then begin
    if Percent >= 0.04
      then Percent:= Percent - 0.04;
    Sh.SetFloat('Percent', Percent);
  end;
  if glfwGetKey(window, GLFW_KEY_UP) = GLFW_PRESS then begin
    if Percent <= 0.96
      then Percent:= Percent + 0.04;
    Sh.SetFloat('Percent', Percent);
  end;
end;

procedure FramebufferSizeCallback(window: pGLFWwindow; Width, Height: Integer);cdecl;
begin
  glViewport(0, 0, Width, Height);
end;

procedure InitScene;
var
  Success: Integer;
  InfoLog: array[0..511]of char;
  Width, Height: LongWord;
begin
  glEnable(GL_DEPTH_TEST);

  glGenVertexArrays(1, @VAO);
  glGenBuffers(1, @VBO);
  glGenBuffers(1, @EBO);

  glBindVertexArray(VAO);

  glBindBuffer(GL_ARRAY_BUFFER, VBO);
  glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), @vertices, GL_STATIC_DRAW);

  // position attribute
  glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(Single), nil);
  glEnableVertexAttribArray(0);
  // texture coord attribute
  glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(Single), Pointer(3 * sizeof(Single)));
  glEnableVertexAttribArray(1);

  Sh:= TShader.Create('shaders\shader.vs', 'shaders\shader.fs');
  Sh.Use;
  Sh.SetInt('texture1', 0);
  Sh.SetInt('texture2', 1);

  //configure texture
  LoadTex('Texture1.jpg', Texture1, Width, Height);
  LoadTex('Texture2.jpg', Texture2, Width, Height);
end;


function ToStr(m: TMatrix4x4): String;
var
  i, j: Integer;
begin
  Result:= '';
  for i:= 0 to 3 do begin
    for j:= 0 to 3 do
      Result:= Result + FloatToStr(m.RawComponents[i,j]) + ' ';
    Result:= Result + LineEnding;
  end;
end;
begin
  SetExceptionMask([exInvalidOp, exDenormalized, exZeroDivide, exOverflow, exUnderflow, exPrecision]);
  //example 1
  Vec.Create(1.0, 0.0, 0.0, 1.0);
  Trans.Create(1);
  Trans.CreateTranslation(1, 1, 0);
  Vec:= Trans * Vec;
  Writeln(Vec.x, ' ', Vec.y, ' ', Vec.z);

  //example 2
  Trans.Create(1);
  VecZ.Create(0, 0, 1);
  VecX.Create(1, 0, 0);
  Trans.CreateRotate(Pi/2, VecZ);
  m4.CreateScale(0.5, 0.5, 0.5);
  Trans:= Trans * m4;
  Writeln(ToStr(Trans));


  if glfwInit() = 0 then
    ExitCode := -1;

  window := glfwCreateWindow(cWindowWidth, cWindowHeight, 'Hello World', nil, nil);
  if window = nil then
  begin
    glfwTerminate();
    ExitCode := -1;
  end;

  glfwMakeContextCurrent(window);
  glfwSetFramebufferSizeCallback(window, @FramebufferSizeCallback);

  //must be called after glfwMakeContextCurrent
  if Load_GL_version_3_3 then
    else ;
  InitScene;

  while glfwWindowShouldClose(window) = 0 do begin
    ProcessInput(window);

    glClearColor(0.2, 0.3, 0.3, 1.0);
    glClear(GL_COLOR_BUFFER_BIT or GL_DEPTH_BUFFER_BIT);


    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, Texture1);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, Texture2);

    Vec1.Create(0.5, 1, 0);
    //Vec1:= Vec1.Normalize;
    View.CreateTranslation(0, 0, -80);
    Projection.CreatePerspective(DegToRad(45), cWindowWidth / cWindowHeight, 0.1, 100);
    Model.CreateRotate(glfwGetTime, Vec1);

    Sh.Use;
    glUniformMatrix4fv(glGetUniformLocation(Sh.ID, 'model'), 1, GL_FALSE, @Model.m00);
    glUniformMatrix4fv(glGetUniformLocation(Sh.ID, 'view'), 1, GL_FALSE, @View.m00);
    glUniformMatrix4fv(glGetUniformLocation(Sh.ID, 'projection'), 1, GL_FALSE, @Projection.m00);
    glBindVertexArray(VAO);
    glDrawArrays(GL_TRIANGLES, 0, 36);

    {
    glBegin(GL_TRIANGLES);
      glColor3d(1,0,0);
      glVertex2f(-1, -1);
      glColor3d(1,1,0);
      glVertex2f(1, -1);
      glColor3d(1,0,1);
      glVertex2f(0, 1);
    glEnd;
    }

    glfwSwapBuffers(window);

    glfwPollEvents();
  end;

  glDeleteVertexArrays(1, @VAO);
  glDeleteBuffers(1, @VBO);
  glDeleteBuffers(1, @EBO);

  glfwTerminate();
  ExitCode := 0;
end.

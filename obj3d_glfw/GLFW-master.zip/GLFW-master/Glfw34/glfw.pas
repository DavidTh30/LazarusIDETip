{
More info:
  http://forum.lazarus.freepascal.org/index.php/topic,21961.msg129100.html#msg129100


  GLFW 3.4.0 - www.glfw.org

  A library for OpenGL, window and input
 ------------------------------------------------------------------------
  Copyright (c) 2002-2006 Marcus Geelnard
  Copyright (c) 2006-2019 Camilla Berglund <elmindredaelmindreda.org>

  This software is provided 'as-is', without any express or implied
  warranty. In no event will the authors be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software. If you use this software
     in a product, an acknowledgment in the product documentation would
     be appreciated but is not required.

  2. Altered source versions must be plainly marked as such, and must not
     be misrepresented as being the original software.

  3. This notice may not be removed or altered from any source
     distribution.

  Pascal header translate by: Jorge Turiel (Aka BlueIcaro)
  with the help of the lazarus community (http://www.lazarus.freepascal.org/index.php)

  GLFW 3.4.0; Date: 240317  Updated headers to  3.4.0 revision

  GLFW 3.3.9; Date: 240106. Updated headers to  3.3.9 revision

  GLFW 3.3.8; Date: 220822. Updated headers to  3.3.8 revision

  GLFW 3.3.7; Date: 220417. Updated headers to  3.3.7 revision

  GLFW 3.1; Date: 20150216

  GLFW 3; Date: 20130912
}
unit glfw;

{$mode objfpc}{$H+}

interface

uses
  GL;

type
  GLFW_INT = integer;
  GLFWwindow = integer;
  pGLFWwindow = ^GLFWwindow;
  GLFWmonitor = integer;
  pGLFWmonitor = ^GLFWmonitor;
  pFloat = ^longint;


type
  GLFWvidmode = record
    Width: integer;
    Height: integer;
    redBits: integer;
    greenBits: integer;
    blueBits: integer;
    refreshRate: integer;
  end;

  pGLFWvidmode = ^GLFWvidmode;

type
  PGLFWgammaramp = ^GLFWgammaramp;

  GLFWgammaramp = record
    red: smallint;
    green: smallint;
    blue: smallint;
    size: dword;
  end;

type
  CharArray = array of char;
  pCharArray = CharArray;

type
  pGLFWcursor = ^GLFWcursor;
  GLFWcursor = integer;

type
  pGLFWimage = ^GLFWimage;

  GLFWimage = record
    Width: integer;
    Height: integer;
    pixels: ^byte;
  end;

type
  pGLFWgamepadstate = ^GLFWgamepadstate;

  GLFWgamepadstate = record
    Buttons: array [0..15] of char;
    axex: array [0..6] of single;
  end;

  {
   Custom heap memory allocator.

   This describes a custom heap memory allocator for GLFW.  To set an allocator, pass it
   to @ref glfwInitAllocator before initializing the library.

   @sa @ref init_allocator
   @sa @ref glfwInitAllocator

   @since Added in version 3.4.

   @ingroup init

  }

type
  pGLFWKeyFun = ^GLFWKeyFun;
  GLFWKeyFun = procedure(window: pGLFWWindow;
    key, scancode, action, mods: integer); cdecl;

  pGLFWerrorfun = ^GLFWerrorfun;
  GLFWerrorfun = procedure(error_code: integer; const Description: pchar); cdecl;
{
   The function pointer type for memory allocation callbacks.

 This is the function pointer type for memory allocation callbacks.  A memory
 allocation callback function has the following signature:
 @code
 void* function_name(size_t size, void* user)
 @endcode

 This function must return either a memory block at least `size` bytes long,
 or `NULL` if allocation failed.  Note that not all parts of GLFW handle allocation
 failures gracefully yet.

 This function must support being called during @ref glfwInit but before the library is
 flagged as initialized, as well as during @ref glfwTerminate after the library is no
 longer flagged as initialized.

 Any memory allocated via this function will be deallocated via the same allocator
 during library termination or earlier.

 Any memory allocated via this function must be suitably aligned for any object type.
 If you are using C99 or earlier, this alignment is platform-dependent but will be the
 same as what `malloc` provides.  If you are using C11 or later, this is the value of
 `alignof(max_align_t)`.

 The size will always be greater than zero.  Allocations of size zero are filtered out
 before reaching the custom allocator.

 If this function returns `NULL`, GLFW will emit @ref GLFW_OUT_OF_MEMORY.

 This function must not call any GLFW function.

 param[in] size The minimum size, in bytes, of the memory block.
 param[in] user The user-defined pointer from the allocator.
 return The address of the newly allocated memory block, or `NULL` if an
 error occurred.

 pointer_lifetime The returned memory block must be valid at least until it
 is deallocated.

 reentrancy This function should not call any GLFW function.

 thread_safety This function must support being called from any thread that calls GLFW
 functions.

 sa @ref init_allocator
 sa @ref GLFWallocator

 since Added in version 3.4.

 ingroup init

}
  pGLFWallocatefun = ^GLFWallocatefun;
  GLFWallocatefun = procedure(size: integer; user: pointer);
{
The function pointer type for memory reallocation callbacks.

 This is the function pointer type for memory reallocation callbacks.
 A memory reallocation callback function has the following signature:
 @code
 void* function_name(void* block, size_t size, void* user)
 @endcode

 This function must return a memory block at least `size` bytes long, or
 `NULL` if allocation failed.  Note that not all parts of GLFW handle allocation
 failures gracefully yet.

 This function must support being called during @ref glfwInit but before the library is
 flagged as initialized, as well as during @ref glfwTerminate after the library is no
 longer flagged as initialized.

 Any memory allocated via this function will be deallocated via the same allocator
 during library termination or earlier.

 Any memory allocated via this function must be suitably aligned for any object type.
 If you are using C99 or earlier, this alignment is platform-dependent but will be the
 same as what `realloc` provides.  If you are using C11 or later, this is the value of
 `alignof(max_align_t)`.

 The block address will never be `NULL` and the size will always be greater than zero.
 Reallocations of a block to size zero are converted into deallocations before reaching
 the custom allocator.  Reallocations of `NULL` to a non-zero size are converted into
 regular allocations before reaching the custom allocator.

 If this function returns `NULL`, GLFW will emit @ref GLFW_OUT_OF_MEMORY.

 This function must not call any GLFW function.

 @param[in] block The address of the memory block to reallocate.
 @param[in] size The new minimum size, in bytes, of the memory block.
 @param[in] user The user-defined pointer from the allocator.
 @return The address of the newly allocated or resized memory block, or
 `NULL` if an error occurred.

 @pointer_lifetime The returned memory block must be valid at least until it
 is deallocated.

 @reentrancy This function should not call any GLFW function.

 @thread_safety This function must support being called from any thread that calls GLFW
 functions.

 @sa @ref init_allocator
 @sa @ref GLFWallocator

 @since Added in version 3.4.

 @ingroup init

}
  pGLFWreallocatefun = ^GLFWreallocatefun;
  GLFWreallocatefun = procedure(block: pointer; size: integer; user: pointer);

{
  The function pointer type for memory deallocation callbacks.

 This is the function pointer type for memory deallocation callbacks.
 A memory deallocation callback function has the following signature:
 @code
 void function_name(void* block, void* user)
 @endcode

 This function may deallocate the specified memory block.  This memory block
 will have been allocated with the same allocator.

 This function must support being called during @ref glfwInit but before the library is
 flagged as initialized, as well as during @ref glfwTerminate after the library is no
 longer flagged as initialized.

 The block address will never be `NULL`.  Deallocations of `NULL` are filtered out
 before reaching the custom allocator.

 If this function returns `NULL`, GLFW will emit @ref GLFW_OUT_OF_MEMORY.

 This function must not call any GLFW function.

 @param[in] block The address of the memory block to deallocate.
 @param[in] user The user-defined pointer from the allocator.

 @pointer_lifetime The specified memory block will not be accessed by GLFW
 after this function is called.

 @reentrancy This function should not call any GLFW function.

 @thread_safety This function must support being called from any thread that calls GLFW
 functions.

 @sa @ref init_allocator
 @sa @ref GLFWallocator

 @since Added in version 3.4.

 @ingroup init

}
  pGLFWdeallocatefun = ^GLFWdeallocatefun;
  GLFWdeallocatefun = procedure(block: Pointer; user: Pointer);

type
  pGLFWallocator = ^GLFWallocator;

  GLFWallocator = record
    allocate: pGLFWallocator;
    reallocate: pGLFWreallocatefun;
    deallocate: pGLFWdeallocatefun;
    user: Pointer;
  end;


  pGLFWmonitorfun = ^GLFWmonitorfun;
  GLFWmonitorfun = procedure(Monitor: PGLFWmonitor; event: integer); cdecl;

  pGLFWjoystickfun = ^GLFWjoystickfun;
  GLFWjoystickfun = procedure(jid, event: GLFW_INT); cdecl;


  pGLFWwindowposfun = ^GLFWwindowposfun;
  GLFWwindowposfun = procedure(window: pGLFWwindow; PosX, PosY: integer); cdecl;

  pGLFWwindowsizefun = ^GLFWwindowsizefun;
  GLFWwindowsizefun = procedure(window: pGLFWwindow; Width, Height: integer); cdecl;

  pGLFWwindowclosefun = ^GLFWwindowclosefun;
  GLFWwindowclosefun = procedure(window: pGLFWwindow); cdecl;

  pGLFWwindowrefreshfun = ^GLFWwindowrefreshfun;
  GLFWwindowrefreshfun = procedure(window: pGLFWwindow); cdecl;

  pGLFWwindowfocusfun = ^GLFWwindowfocusfun;
  GLFWwindowfocusfun = procedure(window: pGLFWwindow; focused: integer); cdecl;

  pGLFWwindowiconifyfun = ^GLFWwindowiconifyfun;
  GLFWwindowiconifyfun = procedure(window: pGLFWwindow; iconified: integer); cdecl;

 {   The function pointer type for window maximize callbacks.

   This is the function pointer type for window maximize callbacks.  A window
   maximize callback function has the following signature:

   void function_name(GLFWwindow window, int maximized)
   endcode

   param[in] window The window that was maximized or restored.
   param[in] maximized `GLFW_TRUE` if the window was maximized, or
   `GLFW_FALSE` if it was restored.

   sa ref window_maximize
   sa glfwSetWindowMaximizeCallback

   since Added in version 3.3.

     }

  pGLFWwindowmaximizefun = ^GLFWwindowmaximizefun;
  GLFWwindowmaximizefun = procedure(window: PGLFWwindow; maximized: integer); cdecl;

  pGLFWframebuffersizefun = ^GLFWframebuffersizefun;
  GLFWframebuffersizefun = procedure(window: pGLFWwindow;
    witdth, Height: integer); cdecl;
  { The function pointer type for window content scale callbacks.

   This is the function pointer type for window content scale callbacks.
   A window content scale callback function has the following signature:

   void function_name(GLFWwindow window, float xscale, float yscale)
   endcode

   param[in] window The window whose content scale changed.
   param[in] xscale The new x-axis content scale of the window.
   param[in] yscale The new y-axis content scale of the window.

   sa ref window_scale
   sa ref glfwSetWindowContentScaleCallback

   since Added in version 3.3.

   ingroup window

}
  pGLFWwindowcontentscalefun = ^GLFWwindowcontentscalefun;
  GLFWwindowcontentscalefun = procedure(window: pGLFWwindow;
    xscale, yscale: single); cdecl;

  pGLFWcharfun = ^GLFWcharfun;
  GLFWcharfun = procedure(window: pGLFWwindow; codepoint: dword); cdecl;

  pGLFWmousebuttonfun = ^GLFWmousebuttonfun;
  GLFWmousebuttonfun = procedure(window: pGLFWwindow;
    button, action, mods: integer); cdecl;

  pGLFWcursorposfun = ^GLFWcursorposfun;
  GLFWcursorposfun = procedure(window: pGLFWwindow; xpos, ypos: double); cdecl;

  pGLFWcursorenterfun = ^GLFWcursorenterfun;
  GLFWcursorenterfun = procedure(window: pGLFWwindow; entered: integer); cdecl;

  pGLFWscrollfun = ^GLFWscrollfun;
  GLFWscrollfun = procedure(window: pGLFWwindow; xoffset, yoffset: double); cdecl;

  pGLFWglproc = ^GLFWglproc;
  GLFWglproc = procedure; cdecl;



  { Vulkan API function pointer type.

   Generic function pointer used for returning Vulkan API function pointers
   without forcing a cast from a regular pointer.

   sa ref vulkan_proc
   sa ref glfwGetInstanceProcAddress

   since Added in version 3.2.

   ingroup vulkan
 }
  pGLFWvkproc = ^GLFWvkproc;
  GLFWvkproc = procedure; cdecl;




  PGLFWcharmodsfun = ^GLFWcharmodsfun;
  GLFWcharmodsfun = procedure(window: pGLFWwindow; codepoint: dword; mods: integer);

type
  pGLFWdropfun = ^GLFWdropfun;
  GLFWdropfun = procedure(window: pGLFWwindow; Count: integer; const names: pchar);


const
  {$IFDEF MSWINDOWS}
  GLFW_DLL = 'GLFW3.DLL';
  {$ELSE}
  GLFW_DLL = 'libglfw.so.3.4';
  {$ENDIF}

  //========================================================================
  // GLFW version
  //========================================================================
  GLFW_FALSE = 0;
  GLFW_TRUE = 1;
 {
  The major version number of the GLFW header.
  The major version number of the GLFW header.  This is incremented when the
  API is changed in non-compatible ways.
 }
  GLFW_VERSION_MAJOR = 3;
{
   The minor version number of the GLFW header.

   The minor version number of the GLFW header.  This is incremented when
   features are added to the API but it remains backward-compatible.

}
  GLFW_VERSION_MINOR = 4;
 {
   The revision number of the GLFW header.

  The revision number of the GLFW header.  This is incremented when a bug fix
  release is made that does not contain any API changes.

 }
  GLFW_VERSION_REVISION = 0;
  {
      The key or mouse button was released.
  }
  GLFW_RELEASE = 0;
  {
      The key or mouse button was pressed.
  }
  GLFW_PRESS = 1;
  {
     The key was held down until it repeated.
  }
  GLFW_REPEAT = 2;

  //Version 334
 {
   hat_state Joystick hat states
     Joystick hat states.

   See joystick hat input (ref joystick_hat) for how these are used.
   }

  GLFW_HAT_CENTERED = 0;
  GLFW_HAT_UP = 1;
  GLFW_HAT_RIGHT = 2;
  GLFW_HAT_DOWN = 4;
  GLFW_HAT_LEFT = 8;
  GLFW_HAT_RIGHT_UP = GLFW_HAT_RIGHT or GLFW_HAT_UP;
  GLFW_HAT_RIGHT_DOWN = GLFW_HAT_RIGHT or GLFW_HAT_DOWN;
  GLFW_HAT_LEFT_UP = GLFW_HAT_LEFT or GLFW_HAT_UP;
  GLFW_HAT_LEFT_DOWN = GLFW_HAT_LEFT or GLFW_HAT_DOWN;



  GLFW_KEY_UNKNOWN = -(1);

  GLFW_KEY_SPACE = 32;
  GLFW_KEY_APOSTROPHE = 39;
  GLFW_KEY_COMMA = 44;
  GLFW_KEY_MINUS = 45;
  GLFW_KEY_PERIOD = 46;
  GLFW_KEY_SLASH = 47;
  GLFW_KEY_0 = 48;
  GLFW_KEY_1 = 49;
  GLFW_KEY_2 = 50;
  GLFW_KEY_3 = 51;
  GLFW_KEY_4 = 52;
  GLFW_KEY_5 = 53;
  GLFW_KEY_6 = 54;
  GLFW_KEY_7 = 55;
  GLFW_KEY_8 = 56;
  GLFW_KEY_9 = 57;
  GLFW_KEY_SEMICOLON = 59;
  GLFW_KEY_EQUAL = 61;
  GLFW_KEY_A = 65;
  GLFW_KEY_B = 66;
  GLFW_KEY_C = 67;
  GLFW_KEY_D = 68;
  GLFW_KEY_E = 69;
  GLFW_KEY_F = 70;
  GLFW_KEY_G = 71;
  GLFW_KEY_H = 72;
  GLFW_KEY_I = 73;
  GLFW_KEY_J = 74;
  GLFW_KEY_K = 75;
  GLFW_KEY_L = 76;
  GLFW_KEY_M = 77;
  GLFW_KEY_N = 78;
  GLFW_KEY_O = 79;
  GLFW_KEY_P = 80;
  GLFW_KEY_Q = 81;
  GLFW_KEY_R = 82;
  GLFW_KEY_S = 83;
  GLFW_KEY_T = 84;
  GLFW_KEY_U = 85;
  GLFW_KEY_V = 86;
  GLFW_KEY_W = 87;
  GLFW_KEY_X = 88;
  GLFW_KEY_Y = 89;
  GLFW_KEY_Z = 90;
  GLFW_KEY_LEFT_BRACKET = 91;
  GLFW_KEY_BACKSLASH = 92;
  GLFW_KEY_RIGHT_BRACKET = 93;
  GLFW_KEY_GRAVE_ACCENT = 96;
  GLFW_KEY_WORLD_1 = 161;


  GLFW_KEY_WORLD_2 = 162; // non-US #2

  GLFW_KEY_ESCAPE = 256;
  GLFW_KEY_ENTER = 257;
  GLFW_KEY_TAB = 258;
  GLFW_KEY_BACKSPACE = 259;
  GLFW_KEY_INSERT = 260;
  GLFW_KEY_DELETE = 261;
  GLFW_KEY_RIGHT = 262;
  GLFW_KEY_LEFT = 263;
  GLFW_KEY_DOWN = 264;
  GLFW_KEY_UP = 265;
  GLFW_KEY_PAGE_UP = 266;
  GLFW_KEY_PAGE_DOWN = 267;
  GLFW_KEY_HOME = 268;
  GLFW_KEY_END = 269;
  GLFW_KEY_CAPS_LOCK = 280;
  GLFW_KEY_SCROLL_LOCK = 281;
  GLFW_KEY_NUM_LOCK = 282;
  GLFW_KEY_PRINT_SCREEN = 283;
  GLFW_KEY_PAUSE = 284;
  GLFW_KEY_F1 = 290;
  GLFW_KEY_F2 = 291;
  GLFW_KEY_F3 = 292;
  GLFW_KEY_F4 = 293;
  GLFW_KEY_F5 = 294;
  GLFW_KEY_F6 = 295;
  GLFW_KEY_F7 = 296;
  GLFW_KEY_F8 = 297;
  GLFW_KEY_F9 = 298;
  GLFW_KEY_F10 = 299;
  GLFW_KEY_F11 = 300;
  GLFW_KEY_F12 = 301;
  GLFW_KEY_F13 = 302;
  GLFW_KEY_F14 = 303;
  GLFW_KEY_F15 = 304;
  GLFW_KEY_F16 = 305;
  GLFW_KEY_F17 = 306;
  GLFW_KEY_F18 = 307;
  GLFW_KEY_F19 = 308;
  GLFW_KEY_F20 = 309;
  GLFW_KEY_F21 = 310;
  GLFW_KEY_F22 = 311;
  GLFW_KEY_F23 = 312;
  GLFW_KEY_F24 = 313;
  GLFW_KEY_F25 = 314;
  GLFW_KEY_KP_0 = 320;
  GLFW_KEY_KP_1 = 321;
  GLFW_KEY_KP_2 = 322;
  GLFW_KEY_KP_3 = 323;
  GLFW_KEY_KP_4 = 324;
  GLFW_KEY_KP_5 = 325;
  GLFW_KEY_KP_6 = 326;
  GLFW_KEY_KP_7 = 327;
  GLFW_KEY_KP_8 = 328;
  GLFW_KEY_KP_9 = 329;
  GLFW_KEY_KP_DECIMAL = 330;
  GLFW_KEY_KP_DIVIDE = 331;
  GLFW_KEY_KP_MULTIPLY = 332;
  GLFW_KEY_KP_SUBTRACT = 333;
  GLFW_KEY_KP_ADD = 334;
  GLFW_KEY_KP_ENTER = 335;
  GLFW_KEY_KP_EQUAL = 336;
  GLFW_KEY_LEFT_SHIFT = 340;
  GLFW_KEY_LEFT_CONTROL = 341;
  GLFW_KEY_LEFT_ALT = 342;
  GLFW_KEY_LEFT_SUPER = 343;
  GLFW_KEY_RIGHT_SHIFT = 344;
  GLFW_KEY_RIGHT_CONTROL = 345;
  GLFW_KEY_RIGHT_ALT = 346;
  GLFW_KEY_RIGHT_SUPER = 347;
  GLFW_KEY_MENU = 348;
  GLFW_KEY_LAST = GLFW_KEY_MENU;



  GLFW_MOD_SHIFT = $0001;

  GLFW_MOD_CONTROL = $0002;

  GLFW_MOD_ALT = $0004;

  GLFW_MOD_SUPER = $0008;

  GLFW_MOD_CAPS_LOCK = $0010;

  GLFW_MOD_NUM_LOCK = $0020;


  GLFW_MOUSE_BUTTON_1 = 0;
  GLFW_MOUSE_BUTTON_2 = 1;
  GLFW_MOUSE_BUTTON_3 = 2;
  GLFW_MOUSE_BUTTON_4 = 3;
  GLFW_MOUSE_BUTTON_5 = 4;
  GLFW_MOUSE_BUTTON_6 = 5;
  GLFW_MOUSE_BUTTON_7 = 6;
  GLFW_MOUSE_BUTTON_8 = 7;
  GLFW_MOUSE_BUTTON_LAST = GLFW_MOUSE_BUTTON_8;
  GLFW_MOUSE_BUTTON_LEFT = GLFW_MOUSE_BUTTON_1;
  GLFW_MOUSE_BUTTON_RIGHT = GLFW_MOUSE_BUTTON_2;
  GLFW_MOUSE_BUTTON_MIDDLE = GLFW_MOUSE_BUTTON_3;


  GLFW_JOYSTICK_1 = 0;
  GLFW_JOYSTICK_2 = 1;
  GLFW_JOYSTICK_3 = 2;
  GLFW_JOYSTICK_4 = 3;
  GLFW_JOYSTICK_5 = 4;
  GLFW_JOYSTICK_6 = 5;
  GLFW_JOYSTICK_7 = 6;
  GLFW_JOYSTICK_8 = 7;
  GLFW_JOYSTICK_9 = 8;
  GLFW_JOYSTICK_10 = 9;
  GLFW_JOYSTICK_11 = 10;
  GLFW_JOYSTICK_12 = 11;
  GLFW_JOYSTICK_13 = 12;
  GLFW_JOYSTICK_14 = 13;
  GLFW_JOYSTICK_15 = 14;
  GLFW_JOYSTICK_16 = 15;
  GLFW_JOYSTICK_LAST = GLFW_JOYSTICK_16;

 {
       See ref gamepad for how these are used.

  }

  GLFW_GAMEPAD_BUTTON_A = 0;
  GLFW_GAMEPAD_BUTTON_B = 1;
  GLFW_GAMEPAD_BUTTON_X = 2;
  GLFW_GAMEPAD_BUTTON_Y = 3;
  GLFW_GAMEPAD_BUTTON_LEFT_BUMPER = 4;
  GLFW_GAMEPAD_BUTTON_RIGHT_BUMPER = 5;
  GLFW_GAMEPAD_BUTTON_BACK = 6;
  GLFW_GAMEPAD_BUTTON_START = 7;
  GLFW_GAMEPAD_BUTTON_GUIDE = 8;
  GLFW_GAMEPAD_BUTTON_LEFT_THUMB = 9;
  GLFW_GAMEPAD_BUTTON_RIGHT_THUMB = 10;
  GLFW_GAMEPAD_BUTTON_DPAD_UP = 11;
  GLFW_GAMEPAD_BUTTON_DPAD_RIGHT = 12;
  GLFW_GAMEPAD_BUTTON_DPAD_DOWN = 13;
  GLFW_GAMEPAD_BUTTON_DPAD_LEFT = 14;
  GLFW_GAMEPAD_BUTTON_LAST = GLFW_GAMEPAD_BUTTON_DPAD_LEFT;

  GLFW_GAMEPAD_BUTTON_CROSS = GLFW_GAMEPAD_BUTTON_A;
  GLFW_GAMEPAD_BUTTON_CIRCLE = GLFW_GAMEPAD_BUTTON_B;
  GLFW_GAMEPAD_BUTTON_SQUARE = GLFW_GAMEPAD_BUTTON_X;
  GLFW_GAMEPAD_BUTTON_TRIANGLE = GLFW_GAMEPAD_BUTTON_Y;

  { Gamepad axes.

   See ref gamepad for how these are used.
 }

  GLFW_GAMEPAD_AXIS_LEFT_X = 0;
  GLFW_GAMEPAD_AXIS_LEFT_Y = 1;
  GLFW_GAMEPAD_AXIS_RIGHT_X = 2;
  GLFW_GAMEPAD_AXIS_RIGHT_Y = 3;
  GLFW_GAMEPAD_AXIS_LEFT_TRIGGER = 4;
  GLFW_GAMEPAD_AXIS_RIGHT_TRIGGER = 5;
  GLFW_GAMEPAD_AXIS_LAST = GLFW_GAMEPAD_AXIS_RIGHT_TRIGGER;



  GLFW_NO_ERROR = $0;

  GLFW_NOT_INITIALIZED = $00010001;

  GLFW_NO_CURRENT_CONTEXT = $00010002;

  GLFW_INVALID_ENUM = $00010003;

  GLFW_INVALID_VALUE = $00010004;

  GLFW_OUT_OF_MEMORY = $00010005;

  GLFW_API_UNAVAILABLE = $00010006;

  GLFW_VERSION_UNAVAILABLE = $00010007;

  GLFW_PLATFORM_ERROR = $00010008;

  GLFW_FORMAT_UNAVAILABLE = $00010009;

  GLFW_FOCUSED = $00020001;
  GLFW_ICONIFIED = $00020002;
  GLFW_RESIZABLE = $00020003;
  GLFW_VISIBLE = $00020004;
  GLFW_DECORATED = $00020005;
  GLFW_AUTO_ICONIFY = $00020006;
  GLFW_FLOATING = $00020007;
  {Window maximization window hint and attribute  }
  GLFW_MAXIMIZED = $00020008;

  {Cursor centering window hint}
  GLFW_CENTER_CURSOR = $00020009;

  { Window framebuffer transparency hint and attribute}
  GLFW_TRANSPARENT_FRAMEBUFFER = $0002000A;

  {Mouse cursor hover window attribute}
  GLFW_HOVERED = $0002000B;

  {Input focus on calling show window hint and attribute}
  GLFW_FOCUS_ON_SHOW = $0002000C;

  {Mouse input transparency window hint and attribute}
  GLFW_MOUSE_PASSTHROUGH = $0002000D;

  {Initial position x-coordinate window hint}
  GLFW_POSITION_X = $0002000E;

  {Initial position y-coordinate window hint}
  GLFW_POSITION_Y = $0002000F;



  {Framebuffer bit depth hint}
  GLFW_RED_BITS = $00021001;
  {Framebuffer bit depth hint}
  GLFW_GREEN_BITS = $00021002;
  {Framebuffer bit depth hint}
  GLFW_BLUE_BITS = $00021003;
  {Framebuffer bit depth hint}
  GLFW_ALPHA_BITS = $00021004;
  {Framebuffer bit depth hint}
  GLFW_DEPTH_BITS = $00021005;
  GLFW_STENCIL_BITS = $00021006;
  GLFW_ACCUM_RED_BITS = $00021007;
  GLFW_ACCUM_GREEN_BITS = $00021008;
  GLFW_ACCUM_BLUE_BITS = $00021009;
  GLFW_ACCUM_ALPHA_BITS = $0002100A;
  GLFW_AUX_BUFFERS = $0002100B;
  GLFW_STEREO = $0002100C;
  GLFW_SAMPLES = $0002100D;
  GLFW_SRGB_CAPABLE = $0002100E;
  GLFW_REFRESH_RATE = $0002100F;
  GLFW_DOUBLEBUFFER = $00021010;

  GLFW_CLIENT_API = $00022001;
  GLFW_CONTEXT_VERSION_MAJOR = $00022002;
  GLFW_CONTEXT_VERSION_MINOR = $00022003;
  GLFW_CONTEXT_REVISION = $00022004;
  GLFW_CONTEXT_ROBUSTNESS = $00022005;
  GLFW_OPENGL_FORWARD_COMPAT = $00022006;
  GLFW_OPENGL_DEBUG_CONTEXT = $00022007;
  GLFW_OPENGL_PROFILE = $00022008;
  GLFW_CONTEXT_RELEASE_BEHAVIOR = $00022009;

  {Context error suppression hint and attribute}
  GLFW_CONTEXT_NO_ERROR = $0002200A;

  {Context creation API hint and attribute}
  GLFW_CONTEXT_CREATION_API = $0002200B;

  {Window content area scaling window}
  GLFW_SCALE_TO_MONITOR = $0002200C;

  {Window framebuffer scaling}
  GLFW_SCALE_FRAMEBUFFER = $0002200D;

  {Legacy name for compatibility.
  This is an alias for the [GLFW_SCALE_FRAMEBUFFER}
  GLFW_COCOA_RETINA_FRAMEBUFFER = $00023001;

  {macOS specific}
  GLFW_COCOA_GRAPHICS_SWITCHING = $00023003;

  {X11 specific}
  GLFW_X11_INSTANCE_NAME = $00024002;


  GLFW_OPENGL_API = $00030001;
  GLFW_OPENGL_ES_API = $00030002;

  GLFW_NO_ROBUSTNESS = 0;
  GLFW_NO_RESET_NOTIFICATION = $00031001;
  GLFW_LOSE_CONTEXT_ON_RESET = $00031002;

  GLFW_OPENGL_ANY_PROFILE = 0;
  GLFW_OPENGL_CORE_PROFILE = $00032001;
  GLFW_OPENGL_COMPAT_PROFILE = $00032002;

  GLFW_CURSOR = $00033001;
  GLFW_STICKY_KEYS = $00033002;
  GLFW_STICKY_MOUSE_BUTTONS = $00033003;

  GLFW_CURSOR_NORMAL = $00034001;
  GLFW_CURSOR_HIDDEN = $00034002;
  GLFW_CURSOR_DISABLED = $00034003;

  GLFW_ANY_RELEASE_BEHAVIOR = 0;
  GLFW_RELEASE_BEHAVIOR_FLUSH = $00035001;
  GLFW_RELEASE_BEHAVIOR_NONE = $00035002;

  GLFW_ARROW_CURSOR = $00036001;
  GLFW_IBEAM_CURSOR = $00036002;
  GLFW_CROSSHAIR_CURSOR = $00036003;
  GLFW_HAND_CURSOR = $00036004;
  GLFW_HRESIZE_CURSOR = $00036005;
  GLFW_VRESIZE_CURSOR = $00036006;

  GLFW_CONNECTED = $00040001;
  GLFW_DISCONNECTED = $00040002;
  {

 Joystick hat buttons init hint.

   Joystick hat buttons (ref GLFW_JOYSTICK_HAT_BUTTONS).
 }

  GLFW_JOYSTICK_HAT_BUTTONS = $00050001;


  { macOS specific init hint.

     macOS specific .
   }

  GLFW_COCOA_CHDIR_RESOURCES = $00051001;

  {!   macOS specific init hint.

     macOS specific ).
    }
  GLFW_COCOA_MENUBAR = $00051002;

  GLFW_PLATFORM = $00050003;
  GLFW_X11_XCB_VULKAN_SURFACE = $00052001;
  GLFW_WAYLAND_LIBDECOR = $00053001;
  GLFW_ANY_PLATFORM = $00060000;
  GLFW_PLATFORM_WIN32 = $00060001;
  GLFW_PLATFORM_COCOA = $00060002;
  GLFW_PLATFORM_WAYLAND = $00060003;
  GLFW_PLATFORM_X11 = $00060004;
  GLFW_PLATFORM_NULL = $00060005;

  GLFW_DONT_CARE = -1;

  //All call must be  cdecl

//========================================================================
//Init
//========================================================================
 {

 Initializes the GLFW library.

   This function initializes the GLFW library.  Before most GLFW functions can
   be used, GLFW must be initialized, and before an application terminates GLFW
   should be terminated in order to free any resources allocated during or
   after initialization.

   If this function fails, it calls ref glfwTerminate before returning.  If it
   succeeds, you should call ref glfwTerminate before the application exits.

   Additional calls to this function after successful initialization but before
   termination will return `GLFW_TRUE` immediately.

   return `GLFW_TRUE` if successful, or `GLFW_FALSE` if an  occurred.

   errors Possible errors include ref GLFW_PLATFORM_ERROR.

   remark macos This function will change the current directory of the
   application to the `Contents/Resources` subdirectory of the application's
   bundle, if present.  This can be disabled with the ref
   GLFW_COCOA_CHDIR_RESOURCES init hint.

   remark x11 This function will set the `LC_CTYPE` category of the
   application locale according to the current environment if that category is
   still "C".  This is because the "C" locale breaks Unicode text input.

   thread_safety This function must only be called from the main thread.

   since Added in version 1.0.

 }
function glfwInit: integer; cdecl; external GLFW_DLL;
 {
Terminates the GLFW library.

 This function destroys all remaining windows and cursors, restores any
 modified gamma ramps and frees any other allocated resources.  Once this
 function is called, you must again call ref glfwInit successfully before
 you will be able to use most GLFW functions.

 If GLFW has been successfully initialized, this function should be called
 before the application exits.  If initialization fails, there is no need to
 call this function, as it is called by ref glfwInit before it returns
 failure.

 This function has no effect if GLFW is not initialized.

 errors Possible errors include ref GLFW_PLATFORM_ERROR.

 remark This function may be called before ref glfwInit.

 warning The contexts of any remaining windows must not be current on any
 other thread when this function is called.

 reentrancy This function must not be called from a callback.

 thread_safety This function must only be called from the main thread.

 sa ref intro_init
 sa ref glfwInit

 since Added in version 1.0.

 }
procedure glfwTerminate; cdecl; external GLFW_DLL;
{
 Sets the specified init hint to the desired value.

   This function sets hints for the next initialization of GLFW.

   The values you set hints to are never reset by GLFW, but they only take
   effect during initialization.  Once GLFW has been initialized, any values
   you set will be ignored until the library is terminated and initialized
   again.

   Some hints are platform specific.  These may be set on any platform but they
   will only affect their specific platform.  Other platforms will ignore them.
   Setting these hints requires no platform specific headers or functions.

   param[in] hint The [init hint](ref init_hints) to set.
   param[in] value The new value of the init hint.

   errors Possible errors include ref GLFW_INVALID_ENUM and ref
   GLFW_INVALID_VALUE.

   remarks This function may be called before ref glfwInit.

   thread_safety This function must only be called from the main thread.


}
procedure glfwInitHint(hint: integer; Value: integer); cdecl; external GLFW_DLL;

{

  Sets the init allocator to the desired value.

  To use the default allocator, call this function with a `NULL` argument.

  If you specify an allocator struct, every member must be a valid function
  pointer.  If any member is `NULL`, this function will emit @ref
  GLFW_INVALID_VALUE and the init allocator will be unchanged.

  The functions in the allocator must fulfil a number of requirements.  See the
  documentation for @ref GLFWallocatefun, @ref GLFWreallocatefun and @ref
  GLFWdeallocatefun for details.

  @param[in] allocator The allocator to use at the next initialization, or
  `NULL` to use the default one.

  @errors Possible errors include @ref GLFW_INVALID_VALUE.

  @pointer_lifetime The specified allocator is copied before this function
  returns.

  @thread_safety This function must only be called from the main thread.

  @sa @ref init_allocator
  @sa @ref glfwInit

  @since Added in version 3.4.

  @ingroup init

}

procedure glfwInitAllocator(const allocator: pGLFWallocator); cdecl; external GLFW_DLL;

 {

 Retrieves the version of the GLFW library.

   This function retrieves the major, minor and revision numbers of the GLFW
   library.  It is intended for when you are using GLFW as a shared library and
   want to ensure that you are using the minimum required version.

   Any or all of the version arguments may be `NULL`.

   param[out] major Where to store the major version number, or `NULL`.
   param[out] minor Where to store the minor version number, or `NULL`.
   param[out] rev Where to store the revision number, or `NULL`.

   errors None.

   remark This function may be called before ref glfwInit.

   thread_safety This function may be called from any thread.

 }
procedure glfwGetVersion(major, minor, rev: pinteger); cdecl; external GLFW_DLL;
 {
 Returns a string describing the compile-time configuration.

   This function returns the compile-time generated
   [version string](ref intro_version_string) of the GLFW library binary.  It
   describes the version, platform, compiler and any platform-specific
   compile-time options.  It should not be confused with the OpenGL or OpenGL
   ES version string, queried with `glGetString`.

   __Do not use the version string__ to parse the GLFW library version.  The
   ref glfwGetVersion function provides the version of the running library
   binary in numerical format.

   return The ASCII encoded GLFW version string.

   errors None.

   remark This function may be called before ref glfwInit.

   pointer_lifetime The returned string is static and compile-time generated.

   thread_safety This function may be called from any thread.

 }
function glfwGetVersionString(): pchar; cdecl; external GLFW_DLL;
{
 Returns and clears the last error for the calling thread.

   This function returns and clears the [error code](ref errors) of the last
   error that occurred on the calling thread, and optionally a UTF-8 encoded
   human-readable description of it.  If no error has occurred since the last
   call, it returns ref GLFW_NO_ERROR (zero) and the description pointer is
   set to `NULL`.

   param[in] description Where to store the error description pointer, or `NULL`.
   return The last error code for the calling thread, or ref GLFW_NO_ERROR
   (zero).

   errors None.

   pointer_lifetime The returned string is allocated and freed by GLFW.  You
   should not free it yourself.  It is guaranteed to be valid only until the
   next error occurs or the library is terminated.

   remark This function may be called before ref glfwInit.

   thread_safety This function may be called from any thread.

   sa ref error_handling
   sa ref glfwSetErrorCallback

   since Added in version 3.3.

   ingroup init

}
function glfwGetError(const description: PPChar): integer; cdecl; external GLFW_DLL;
{
/ Returns the currently selected platform.

 This function returns the platform that was selected during initialization.  The
 returned value will be one of `GLFW_PLATFORM_WIN32`, `GLFW_PLATFORM_COCOA`,
 `GLFW_PLATFORM_WAYLAND`, `GLFW_PLATFORM_X11` or `GLFW_PLATFORM_NULL`.

 @return The currently selected platform, or zero if an error occurred.

 @errors Possible errors include @ref GLFW_NOT_INITIALIZED.

 @thread_safety This function may be called from any thread.

 @sa @ref platform
 @sa @ref glfwPlatformSupported

 @since Added in version 3.4.

 @ingroup init


}
function glfwGetPlatform(): integer; cdecl; external GLFW_DLL;
{

  Returns whether the library includes support for the specified platform.

   This function returns whether the library was compiled with support for the specified
   platform.  The platform must be one of `GLFW_PLATFORM_WIN32`, `GLFW_PLATFORM_COCOA`,
   `GLFW_PLATFORM_WAYLAND`, `GLFW_PLATFORM_X11` or `GLFW_PLATFORM_NULL`.

   @param[in] platform The platform to query.
   @return `GLFW_TRUE` if the platform is supported, or `GLFW_FALSE` otherwise.

   @errors Possible errors include @ref GLFW_INVALID_ENUM.

   @remark This function may be called before @ref glfwInit.

   @thread_safety This function may be called from any thread.

   @sa @ref platform
   @sa @ref glfwGetPlatform

   @since Added in version 3.4.

   @ingroup init


}
function glfwPlatformSupported(plattform: integer): integer; cdecl; external GLFW_DLL;


//========================================================================
//Monitor
//========================================================================
 {
 /!   Returns the currently connected monitors.

   This function returns an array of handles for all currently connected
   monitors.  The primary monitor is always first in the returned array.  If no
   monitors were found, this function returns `NULL`.

   param[out] count Where to store the number of monitors in the returned
   array.  This is set to zero if an error occurred.
   return An array of monitor handles, or `NULL` if no monitors were found or
   if an [error](ref error_handling) occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   pointer_lifetime The returned array is allocated and freed by GLFW.  You
   should not free it yourself.  It is guaranteed to be valid only until the
   monitor configuration changes or the library is terminated.

   thread_safety This function must only be called from the main thread.

   sa ref monitor_monitors
   sa ref monitor_event
   sa ref glfwGetPrimaryMonitor

   since Added in version 3.0.
 }
function glfwGetMonitors(var Monitors: GLFW_INT): PGLFWmonitor; cdecl; external GLFW_DLL;
{
/!   Returns the primary monitor.

   This function returns the primary monitor.  This is usually the monitor
   where elements like the task bar or global menu bar are located.

   return The primary monitor, or `NULL` if no monitors were found or if an
   [error](ref error_handling) occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   remark The primary monitor is always first in the array returned by ref
   glfwGetMonitors.

   sa ref monitor_monitors
   sa ref glfwGetMonitors

   since Added in version 3.0.


}
function glfwGetPrimaryMonitor(): pGLFWmonitor; cdecl; external GLFW_DLL;
{
/!   Returns the position of the monitor's viewport on the virtual screen.

   This function returns the position, in screen coordinates, of the upper-left
   corner of the specified monitor.

   Any or all of the position arguments may be `NULL`.  If an error occurs, all
   non-`NULL` position arguments will be set to zero.

   param[in] monitor The monitor to query.
   param[out] xpos Where to store the monitor x-coordinate, or `NULL`.
   param[out] ypos Where to store the monitor y-coordinate, or `NULL`.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref monitor_properties

   since Added in version 3.0.
}
procedure glfwGetMonitorPos(monitor: pGLFWmonitor; var xpos: GLFW_INT;
  var ypos: GLFW_INT); cdecl; external GLFW_DLL;
{ Retrieves the work area of the monitor.

   This function returns the position, in screen coordinates, of the upper-left
   corner of the work area of the specified monitor along with the work area
   size in screen coordinates. The work area is defined as the area of the
   monitor not occluded by the operating system task bar where present. If no
   task bar exists then the work area is the monitor resolution in screen
   coordinates.

   Any or all of the position and size arguments may be `NULL`.  If an error
   occurs, all non-`NULL` position and size arguments will be set to zero.

   param[in] monitor The monitor to query.
   param[out] xpos Where to store the monitor x-coordinate, or `NULL`.
   param[out] ypos Where to store the monitor y-coordinate, or `NULL`.
   param[out] width Where to store the monitor width, or `NULL`.
   param[out] height Where to store the monitor height, or `NULL`.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref monitor_workarea

   since Added in version 3.3.

   ingroup monitor
 /
GLFWAPI void glfwGetMonitorWorkarea(GLFWmonitor monitor, int xpos, int ypos, int width, int height);}

procedure glfwGetMonitorWorkarea(monitor: pGLFWmonitor;
  var Xpos, Ypos, Width, Height: GLFW_INT); cdecl; external GLFW_DLL;
 {
 /!   Returns the physical size of the monitor.

   This function returns the size, in millimetres, of the display area of the
   specified monitor.

   Some systems do not provide accurate monitor size information, either
   because the monitor
   [EDID](https://en.wikipedia.org/wiki/Extended_display_identification_data)
   data is incorrect or because the driver does not report it accurately.

   Any or all of the size arguments may be `NULL`.  If an error occurs, all
   non-`NULL` size arguments will be set to zero.

   param[in] monitor The monitor to query.
   param[out] widthMM Where to store the width, in millimetres, of the
   monitor's display area, or `NULL`.
   param[out] heightMM Where to store the height, in millimetres, of the
   monitor's display area, or `NULL`.

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   remark win32 On Windows 8 and earlier the physical size is calculated from
   the current resolution and system DPI instead of querying the monitor EDID data.

   thread_safety This function must only be called from the main thread.

   sa ref monitor_properties

   since Added in version 3.0.
 }
procedure glfwGetMonitorPhysicalSize(Monitor: pGLFWmonitor;
  var WidthMM: GLFW_INT; var HeightMM: GLFW_INT); cdecl; external GLFW_DLL;

{ Retrieves the content scale for the specified monitor.

   This function retrieves the content scale for the specified monitor.  The
   content scale is the ratio between the current DPI and the platform's
   default DPI.  This is especially important for text and any UI elements.  If
   the pixel dimensions of your UI scaled by this look appropriate on your
   machine then it should appear at a reasonable size on other machines
   regardless of their DPI and scaling settings.  This relies on the system DPI
   and scaling settings being somewhat correct.

   The content scale may depend on both the monitor resolution and pixel
   density and on user settings.  It may be very different from the raw DPI
   calculated from the physical size and current resolution.

   param[in] monitor The monitor to query.
   param[out] xscale Where to store the x-axis content scale, or `NULL`.
   param[out] yscale Where to store the y-axis content scale, or `NULL`.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref monitor_scale
   sa ref glfwGetWindowContentScale

   since Added in version 3.3.
   ingroup monitor
   }
procedure glfwGetMonitorContentScale(monitor: pGLFWmonitor; var xscale, yscale: single);
  cdecl; external GLFW_DLL;
{
/!   Returns the name of the specified monitor.

   This function returns a human-readable name, encoded as UTF-8, of the
   specified monitor.  The name typically reflects the make and model of the
   monitor and is not guaranteed to be unique among the connected monitors.

   param[in] monitor The monitor to query.
   return The UTF-8 encoded name of the monitor, or `NULL` if an
   [error](ref error_handling) occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   pointer_lifetime The returned string is allocated and freed by GLFW.  You
   should not free it yourself.  It is valid until the specified monitor is
   disconnected or the library is terminated.

   thread_safety This function must only be called from the main thread.

   sa ref monitor_properties

   since Added in version 3.0.

}
function glfwGetMonitorName(Monitor: pGLFWmonitor): pchar; cdecl; external GLFW_DLL;

 { Sets the user pointer of the specified monitor.

   This function sets the user-defined pointer of the specified monitor.  The
   current value is retained until the monitor is disconnected.  The initial
   value is `NULL`.

   This function may be called from the monitor callback, even for a monitor
   that is being disconnected.

   param[in] monitor The monitor whose pointer to set.
   param[in] pointer The new value.

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function may be called from any thread.  Access is not
   synchronized.

   sa ref monitor_userptr
   sa ref glfwGetMonitorUserPointer

   since Added in version 3.3.

   ingroup monitor
 /
GLFWAPI void glfwSetMonitorUserPointer(GLFWmonitor monitor, void pointer);}
procedure glfwSetMonitorUserPointer(Monitor: pGLFWmonitor; UserPointer: Pointer);
  cdecl; external GLFW_DLL;

{ Returns the user pointer of the specified monitor.

   This function returns the current value of the user-defined pointer of the
   specified monitor.  The initial value is `NULL`.

   This function may be called from the monitor callback, even for a monitor
   that is being disconnected.

   param[in] monitor The monitor whose pointer to return.

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function may be called from any thread.  Access is not
   synchronized.

   sa ref monitor_userptr
   sa ref glfwSetMonitorUserPointer

   since Added in version 3.3.

   ingroup monitor
 /
GLFWAPI void glfwGetMonitorUserPointer(GLFWmonitor monitor);}
function glfwGetMonitorUserPointer(monitor: pGLFWmonitor): Pointer;
  cdecl; external GLFW_DLL;
 {
 /!   Sets the monitor configuration callback.

   This function sets the monitor configuration callback, or removes the
   currently set callback.  This is called when a monitor is connected to or
   disconnected from the system.

   param[in] callback The new callback, or `NULL` to remove the currently set
   callback.
   return The previously set callback, or `NULL` if no callback was set or the
   library had not been [initialized](ref intro_init).

   callback_signature
   code
   void function_name(GLFWmonitor monitor, int event)
   endcode
   For more information about the callback parameters, see the
   [function pointer type](ref GLFWmonitorfun).

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   sa ref monitor_event

   since Added in version 3.0.
 }

function glfwSetMonitorCallback(cbfun: GLFWmonitorfun): pGLFWmonitorfun;
  cdecl; external GLFW_DLL; //Untest

//========================================================================
//Video Mode
//========================================================================

{
/!   Returns the available video modes for the specified monitor.

   This function returns an array of all video modes supported by the specified
   monitor.  The returned array is sorted in ascending order, first by color
   bit depth (the sum of all channel depths), then by resolution area (the
   product of width and height), then resolution width and finally by refresh
   rate.

   param[in] monitor The monitor to query.
   param[out] count Where to store the number of video modes in the returned
   array.  This is set to zero if an error occurred.
   return An array of video modes, or `NULL` if an
   [error](ref error_handling) occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   pointer_lifetime The returned array is allocated and freed by GLFW.  You
   should not free it yourself.  It is valid until the specified monitor is
   disconnected, this function is called again for that monitor or the library
   is terminated.

   thread_safety This function must only be called from the main thread.

   sa ref monitor_modes
   sa ref glfwGetVideoMode

   since Added in version 1.0.
   glfw3 Changed to return an array of modes for a specific monitor.

   ingroup monitor
 /
}
function glfwGetVideoModes(monitor: pGLFWmonitor; var Count: integer): PGLFWvidmode;
  cdecl; external GLFW_DLL;
  {
  /!   Returns the current mode of the specified monitor.

   This function returns the current video mode of the specified monitor.  If
   you have created a full screen window for that monitor, the return value
   will depend on whether that window is iconified.

   param[in] monitor The monitor to query.
   return The current mode of the monitor, or `NULL` if an
   [error](ref error_handling) occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   pointer_lifetime The returned array is allocated and freed by GLFW.  You
   should not free it yourself.  It is valid until the specified monitor is
   disconnected or the library is terminated.

   thread_safety This function must only be called from the main thread.

   sa ref monitor_modes
   sa ref glfwGetVideoModes

   since Added in version 3.0.  Replaces `glfwGetDesktopMode`.

   ingroup monitor
 /
  }
function glfwGetVideoMode(monitor: pGLFWmonitor): pGLFWvidmode; cdecl;
  external GLFW_DLL;
{
!   Generates a gamma ramp and sets it for the specified monitor.

   This function generates an appropriately sized gamma ramp from the specified
   exponent and then calls ref glfwSetGammaRamp with it.  The value must be
   a finite number greater than zero.

   The software controlled gamma ramp is applied _in addition_ to the hardware
   gamma correction, which today is usually an approximation of sRGB gamma.
   This means that setting a perfectly linear ramp, or gamma 1.0, will produce
   the default (usually sRGB-like) behavior.

   For gamma correct rendering with OpenGL or OpenGL ES, see the ref
   GLFW_SRGB_CAPABLE hint.

   param[in] monitor The monitor whose gamma ramp to set.
   param[in] gamma The desired exponent.

   errors Possible errors include ref GLFW_NOT_INITIALIZED, ref
   GLFW_INVALID_VALUE and ref GLFW_PLATFORM_ERROR.

   remark wayland Gamma handling is a privileged protocol, this function
   will thus never be implemented and emits ref GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref monitor_gamma

   since Added in version 3.0
}
procedure glfwSetGamma(monitor: pGLFWmonitor; gamma: single); cdecl; external GLFW_DLL;
{
/!   Returns the current gamma ramp for the specified monitor.

   This function returns the current gamma ramp of the specified monitor.

   param[in] monitor The monitor to query.
   return The current gamma ramp, or `NULL` if an
   [error](ref error_handling) occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   remark wayland Gamma handling is a privileged protocol, this function
   will thus never be implemented and emits ref GLFW_PLATFORM_ERROR while
   returning `NULL`.

   pointer_lifetime The returned structure and its arrays are allocated and
   freed by GLFW.  You should not free them yourself.  They are valid until the
   specified monitor is disconnected, this function is called again for that
   monitor or the library is terminated.

   thread_safety This function must only be called from the main thread.
}

function glfwGetGammaRamp(monitor: pGLFWmonitor): PGLFWgammaramp;
  cdecl; external GLFW_DLL;

 {
  !   Sets the current gamma ramp for the specified monitor.

   This function sets the current gamma ramp for the specified monitor.  The
   original gamma ramp for that monitor is saved by GLFW the first time this
   function is called and is restored by ref glfwTerminate.

   The software controlled gamma ramp is applied _in addition_ to the hardware
   gamma correction, which today is usually an approximation of sRGB gamma.
   This means that setting a perfectly linear ramp, or gamma 1.0, will produce
   the default (usually sRGB-like) behavior.

   For gamma correct rendering with OpenGL or OpenGL ES, see the ref
   GLFW_SRGB_CAPABLE hint.

   param[in] monitor The monitor whose gamma ramp to set.
   param[in] ramp The gamma ramp to use.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   remark The size of the specified gamma ramp should match the size of the
   current ramp for that monitor.

   remark win32 The gamma ramp size must be 256.

   remark wayland Gamma handling is a privileged protocol, this function
   will thus never be implemented and emits ref GLFW_PLATFORM_ERROR.

   pointer_lifetime The specified gamma ramp is copied before this function
   returns.

   thread_safety This function must only be called from the main thread.

   sa ref monitor_gamma

   since Added in version 3.0.
 }
procedure glfwSetGammaRamp(monitor: pGLFWmonitor; ramp: pGLFWgammaramp);
  cdecl; external GLFW_DLL;

//========================================================================
//Windows (not the SO)
//========================================================================

{
/!   Resets all window hints to their default values.

   This function resets all window hints to their
   [default values](ref window_hints_values).

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   sa ref window_hints
   sa ref glfwWindowHint
   sa ref glfwWindowHintString

   since Added in version 3.0.
}
procedure glfwDefaultWindowHints; cdecl; external GLFW_DLL;
{
/!   Sets the specified window hint to the desired value.

   This function sets hints for the next call to ref glfwCreateWindow.  The
   hints, once set, retain their values until changed by a call to this
   function or ref glfwDefaultWindowHints, or until the library is terminated.

   Only integer value hints can be set with this function.  String value hints
   are set with ref glfwWindowHintString.

   This function does not check whether the specified hint values are valid.
   If you set hints to invalid values this will instead be reported by the next
   call to ref glfwCreateWindow.

   Some hints are platform specific.  These may be set on any platform but they
   will only affect their specific platform.  Other platforms will ignore them.
   Setting these hints requires no platform specific headers or functions.

   param[in] hint The [window hint](ref window_hints) to set.
   param[in] value The new value of the window hint.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_INVALID_ENUM.

   thread_safety This function must only be called from the main thread.

   sa ref window_hints
   sa ref glfwWindowHintString
   sa ref glfwDefaultWindowHints

   since Added in version 3.0.  Replaces `glfwOpenWindowHint`.
}

procedure glfwWindowHint(hint: integer; Value: integer); cdecl; external GLFW_DLL;
{
/!   Sets the specified window hint to the desired value.

   This function sets hints for the next call to ref glfwCreateWindow.  The
   hints, once set, retain their values until changed by a call to this
   function or ref glfwDefaultWindowHints, or until the library is terminated.

   Only string type hints can be set with this function.  Integer value hints
   are set with ref glfwWindowHint.

   This function does not check whether the specified hint values are valid.
   If you set hints to invalid values this will instead be reported by the next
   call to ref glfwCreateWindow.

   Some hints are platform specific.  These may be set on any platform but they
   will only affect their specific platform.  Other platforms will ignore them.
   Setting these hints requires no platform specific headers or functions.

   param[in] hint The [window hint](ref window_hints) to set.
   param[in] value The new value of the window hint.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_INVALID_ENUM.

   pointer_lifetime The specified string is copied before this function
   returns.

   thread_safety This function must only be called from the main thread.

   sa ref window_hints
   sa ref glfwWindowHint
   sa ref glfwDefaultWindowHints

   since Added in version 3.3.

}
procedure glfwWindowHintString(hint: integer; const Value: pchar);
  cdecl; external GLFW_DLL;
  {
  
/!   Creates a window and its associated context.

   This function creates a window and its associated OpenGL or OpenGL ES
   context.  Most of the options controlling how the window and its context
   should be created are specified with [window hints](ref window_hints).

   Successful creation does not change which context is current.  Before you
   can use the newly created context, you need to
   [make it current](ref context_current).  For information about the `share`
   parameter, see ref context_sharing.

   The created window, framebuffer and context may differ from what you
   requested, as not all parameters and hints are
   [hard constraints](ref window_hints_hard).  This includes the size of the
   window, especially for full screen windows.  To query the actual attributes
   of the created window, framebuffer and context, see ref
   glfwGetWindowAttrib, ref glfwGetWindowSize and ref glfwGetFramebufferSize.

   To create a full screen window, you need to specify the monitor the window
   will cover.  If no monitor is specified, the window will be windowed mode.
   Unless you have a way for the user to choose a specific monitor, it is
   recommended that you pick the primary monitor.  For more information on how
   to query connected monitors, see ref monitor_monitors.

   For full screen windows, the specified size becomes the resolution of the
   window's _desired video mode_.  As long as a full screen window is not
   iconified, the supported video mode most closely matching the desired video
   mode is set for the specified monitor.  For more information about full
   screen windows, including the creation of so called _windowed full screen_
   or _borderless full screen_ windows, see ref window_windowed_full_screen.

   Once you have created the window, you can switch it between windowed and
   full screen mode with ref glfwSetWindowMonitor.  This will not affect its
   OpenGL or OpenGL ES context.

   By default, newly created windows use the placement recommended by the
   window system.  To create the window at a specific position, make it
   initially invisible using the [GLFW_VISIBLE](ref GLFW_VISIBLE_hint) window
   hint, set its [position](ref window_pos) and then [show](ref window_hide)
   it.

   As long as at least one full screen window is not iconified, the screensaver
   is prohibited from starting.

   Window systems put limits on window sizes.  Very large or very small window
   dimensions may be overridden by the window system on creation.  Check the
   actual [size](ref window_size) after creation.

   The [swap interval](ref buffer_swap) is not set during window creation and
   the initial value may vary depending on driver settings and defaults.

   param[in] width The desired width, in screen coordinates, of the window.
   This must be greater than zero.
   param[in] height The desired height, in screen coordinates, of the window.
   This must be greater than zero.
   param[in] title The initial, UTF-8 encoded window title.
   param[in] monitor The monitor to use for full screen mode, or `NULL` for
   windowed mode.
   param[in] share The window whose context to share resources with, or `NULL`
   to not share resources.
   return The handle of the created window, or `NULL` if an
   [error](ref error_handling) occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED, ref
   GLFW_INVALID_ENUM, ref GLFW_INVALID_VALUE, ref GLFW_API_UNAVAILABLE, ref
   GLFW_VERSION_UNAVAILABLE, ref GLFW_FORMAT_UNAVAILABLE and ref
   GLFW_PLATFORM_ERROR.

   remark win32 Window creation will fail if the Microsoft GDI software
   OpenGL implementation is the only one available.

   remark win32 If the executable has an icon resource named `GLFW_ICON,` it
   will be set as the initial icon for the window.  If no such icon is present,
   the `IDI_APPLICATION` icon will be used instead.  To set a different icon,
   see ref glfwSetWindowIcon.

   remark win32 The context to share resources with must not be current on
   any other thread.

   remark macos The OS only supports forward-compatible core profile contexts
   for OpenGL versions 3.2 and later.  Before creating an OpenGL context of
   version 3.2 or later you must set the
   [GLFW_OPENGL_FORWARD_COMPAT](ref GLFW_OPENGL_FORWARD_COMPAT_hint) and
   [GLFW_OPENGL_PROFILE](ref GLFW_OPENGL_PROFILE_hint) hints accordingly.
   OpenGL 3.0 and 3.1 contexts are not supported at all on macOS.

   remark macos The GLFW window has no icon, as it is not a document
   window, but the dock icon will be the same as the application bundle's icon.
   For more information on bundles, see the
   [Bundle Programming Guide](https://developer.apple.com/library/mac/documentation/CoreFoundation/Conceptual/CFBundles/)
   in the Mac Developer Library.

   remark macos The first time a window is created the menu bar is created.
   If GLFW finds a `MainMenu.nib` it is loaded and assumed to contain a menu
   bar.  Otherwise a minimal menu bar is created manually with common commands
   like Hide, Quit and About.  The About entry opens a minimal about dialog
   with information from the application's bundle.  Menu bar creation can be
   disabled entirely with the ref GLFW_COCOA_MENUBAR init hint.

   remark macos On OS X 10.10 and later the window frame will not be rendered
   at full resolution on Retina displays unless the
   [GLFW_COCOA_RETINA_FRAMEBUFFER](ref GLFW_COCOA_RETINA_FRAMEBUFFER_hint)
   hint is `GLFW_TRUE` and the `NSHighResolutionCapable` key is enabled in the
   application bundle's `Info.plist`.  For more information, see
   [High Resolution Guidelines for OS X](https://developer.apple.com/library/mac/documentation/GraphicsAnimation/Conceptual/HighResolutionOSX/Explained/Explained.html)
   in the Mac Developer Library.  The GLFW test and example programs use
   a custom `Info.plist` template for this, which can be found as
   `CMake/MacOSXBundleInfo.plist.in` in the source tree.

   remark macos When activating frame autosaving with
   [GLFW_COCOA_FRAME_NAME](ref GLFW_COCOA_FRAME_NAME_hint), the specified
   window size and position may be overridden by previously saved values.

   remark x11 Some window managers will not respect the placement of
   initially hidden windows.

   remark x11 Due to the asynchronous nature of X11, it may take a moment for
   a window to reach its requested state.  This means you may not be able to
   query the final size, position or other attributes directly after window
   creation.

   remark x11 The class part of the `WM_CLASS` window property will by
   default be set to the window title passed to this function.  The instance
   part will use the contents of the `RESOURCE_NAME` environment variable, if
   present and not empty, or fall back to the window title.  Set the
   [GLFW_X11_CLASS_NAME](ref GLFW_X11_CLASS_NAME_hint) and
   [GLFW_X11_INSTANCE_NAME](ref GLFW_X11_INSTANCE_NAME_hint) window hints to
   override this.

   remark wayland Compositors should implement the xdg-decoration protocol
   for GLFW to decorate the window properly.  If this protocol isn't
   supported, or if the compositor prefers client-side decorations, a very
   simple fallback frame will be drawn using the wp_viewporter protocol.  A
   compositor can still emit close, maximize or fullscreen events, using for
   instance a keybind mechanism.  If neither of these protocols is supported,
   the window won't be decorated.

   remark wayland A full screen window will not attempt to change the mode,
   no matter what the requested size or refresh rate.

   remark wayland Screensaver inhibition requires the idle-inhibit protocol
   to be implemented in the user's compositor.

   thread_safety This function must only be called from the main thread.

   sa ref window_creation
   sa ref glfwDestroyWindow

   since Added in version 3.0.  Replaces `glfwOpenWindow`.

  }
function glfwCreateWindow(Width, Height: integer; title: pchar;
  monitor: pGLFWmonitor; share: pGLFWwindow): pGLFWwindow; cdecl; external GLFW_DLL;
 {
 Destroys the specified window and its context.

   This function destroys the specified window and its context.  On calling
   this function, no further callbacks will be called for that window.

   If the context of the specified window is current on the main thread, it is
   detached before being destroyed.

   param[in] window The window to destroy.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   note The context of the specified window must not be current on any other
   thread when this function is called.

   reentrancy This function must not be called from a callback.

   thread_safety This function must only be called from the main thread.

   sa ref window_creation
   sa ref glfwCreateWindow

   since Added in version 3.0.  Replaces `glfwCloseWindow`.

   ingroup window

 }
procedure glfwDestroyWindow(Window: pGLFWwindow); cdecl; external GLFW_DLL;

 {
 Checks the close flag of the specified window.

   This function returns the value of the close flag of the specified window.

   param[in] window The window to query.
   return The value of the close flag.

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function may be called from any thread.  Access is not
   synchronized.

   sa ref window_close

   since Added in version 3.0.


 }
function glfwWindowShouldClose(Window: pGLFWwindow): integer; cdecl; external GLFW_DLL;
 {
  Sets the close flag of the specified window.

   This function sets the value of the close flag of the specified window.
   This can be used to override the user's attempt to close the window, or
   to signal that it should be closed.

   param[in] window The window whose flag to change.
   param[in] value The new value.

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function may be called from any thread.  Access is not
   synchronized.

   sa ref window_close

   since Added in version 3.0.
 }
procedure glfwSetWindowShouldClose(window: pGLFWwindow; Value: integer);
  cdecl; external GLFW_DLL;
 {
 Sets the title of the specified window.

   This function sets the window title, encoded as UTF-8, of the specified
   window.

   param[in] window The window whose title to change.
   param[in] title The UTF-8 encoded window title.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   remark macos The window title will not be updated until the next time you
   process events.

   thread_safety This function must only be called from the main thread.

   sa ref window_title

   since Added in version 1.0.
   glfw3 Added window handle parameter.
 }

procedure glfwSetWindowTitle(window: pGLFWwindow; const title: pchar);
  cdecl; external GLFW_DLL;

 {Returns the title of the specified window.

 This function returns the window title, encoded as UTF-8, of the specified
 window.  This is the title set previously by @ref glfwCreateWindow
 or @ref glfwSetWindowTitle.

 @param[in] window The window to query.
 @return The UTF-8 encoded window title, or `NULL` if an
 [error](@ref error_handling) occurred.

 @errors Possible errors include @ref GLFW_NOT_INITIALIZED.

 @remark The returned title is currently a copy of the title last set by @ref
 glfwCreateWindow or @ref glfwSetWindowTitle.  It does not include any
 additional text which may be appended by the platform or another program.

 @pointer_lifetime The returned string is allocated and freed by GLFW.  You
 should not free it yourself.  It is valid until the next call to @ref
 glfwGetWindowTitle or @ref glfwSetWindowTitle, or until the library is
 terminated.

 @thread_safety This function must only be called from the main thread.

 @sa @ref window_title
 @sa @ref glfwSetWindowTitle

 @since Added in version 3.4.

 @ingroup window

}

function glfwGetWindowTitle(window: pGLFWwindow): pchar; cdecl; external GLFW_DLL;



 {
 Sets the icon for the specified window.

   This function sets the icon of the specified window.  If passed an array of
   candidate images, those of or closest to the sizes desired by the system are
   selected.  If no images are specified, the window reverts to its default
   icon.

   The pixels are 32-bit, little-endian, non-premultiplied RGBA, i.e. eight
   bits per channel with the red channel first.  They are arranged canonically
   as packed sequential rows, starting from the top-left corner.

   The desired image sizes varies depending on platform and system settings.
   The selected images will be rescaled as needed.  Good sizes include 16x16,
   32x32 and 48x48.

   param[in] window The window whose icon to set.
   param[in] count The number of images in the specified array, or zero to
   revert to the default window icon.
   param[in] images The images to create the icon from.  This is ignored if
   count is zero.

   errors Possible errors include ref GLFW_NOT_INITIALIZED, ref
   GLFW_INVALID_VALUE and ref GLFW_PLATFORM_ERROR.

   pointer_lifetime The specified image data is copied before this function
   returns.

   remark macos The GLFW window has no icon, as it is not a document
   window, so this function does nothing.  The dock icon will be the same as
   the application bundle's icon.  For more information on bundles, see the
   [Bundle Programming Guide](https://developer.apple.com/library/mac/documentation/CoreFoundation/Conceptual/CFBundles/)
   in the Mac Developer Library.

   remark wayland There is no existing protocol to change an icon, the
   window will thus inherit the one defined in the application's desktop file.
   This function always emits ref GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref window_icon

   since Added in version 3.2.

}
procedure glfwSetWindowIcon(window: pGLFWWindow; Count: integer; images: pGLFWimage);
  cdecl; external GLFW_DLL;
 {
 
 Sets the position of the content area of the specified window.

   This function sets the position, in screen coordinates, of the upper-left
   corner of the content area of the specified windowed mode window.  If the
   window is a full screen window, this function does nothing.

   __Do not use this function__ to move an already visible window unless you
   have very good reasons for doing so, as it will confuse and annoy the user.

   The window manager may put limits on what positions are allowed.  GLFW
   cannot and should not override these limits.

   param[in] window The window to query.
   param[in] xpos The x-coordinate of the upper-left corner of the content area.
   param[in] ypos The y-coordinate of the upper-left corner of the content area.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   remark wayland There is no way for an application to set the global
   position of its windows, this function will always emit ref
   GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref window_pos
   sa ref glfwGetWindowPos

   since Added in version 1.0.
   glfw3 Added window handle parameter.
 }
procedure glfwSetWindowPos(window: pGLFWwindow; xpos, ypos: integer);
  cdecl; external GLFW_DLL;
{
Retrieves the size of the content area of the specified window.

   This function retrieves the size, in screen coordinates, of the content area
   of the specified window.  If you wish to retrieve the size of the
   framebuffer of the window in pixels, see ref glfwGetFramebufferSize.

   Any or all of the size arguments may be `NULL`.  If an error occurs, all
   non-`NULL` size arguments will be set to zero.

   param[in] window The window whose size to retrieve.
   param[out] width Where to store the width, in screen coordinates, of the
   content area, or `NULL`.
   param[out] height Where to store the height, in screen coordinates, of the
   content area, or `NULL`.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref window_size
   sa ref glfwSetWindowSize

   since Added in version 1.0.
   glfw3 Added window handle parameter.
}
procedure glfwGetWindowSize(window: pGLFWwindow; var Width, Height: integer);
  cdecl; external GLFW_DLL;
 {
 Sets the size limits of the specified window.

   This function sets the size limits of the content area of the specified
   window.  If the window is full screen, the size limits only take effect
   once it is made windowed.  If the window is not resizable, this function
   does nothing.

   The size limits are applied immediately to a windowed mode window and may
   cause it to be resized.

   The maximum dimensions must be greater than or equal to the minimum
   dimensions and all must be greater than or equal to zero.

   param[in] window The window to set limits for.
   param[in] minwidth The minimum width, in screen coordinates, of the content
   area, or `GLFW_DONT_CARE`.
   param[in] minheight The minimum height, in screen coordinates, of the
   content area, or `GLFW_DONT_CARE`.
   param[in] maxwidth The maximum width, in screen coordinates, of the content
   area, or `GLFW_DONT_CARE`.
   param[in] maxheight The maximum height, in screen coordinates, of the
   content area, or `GLFW_DONT_CARE`.

   errors Possible errors include ref GLFW_NOT_INITIALIZED, ref
   GLFW_INVALID_VALUE and ref GLFW_PLATFORM_ERROR.

   remark If you set size limits and an aspect ratio that conflict, the
   results are undefined.

   remark wayland The size limits will not be applied until the window is
   actually resized, either by the user or by the compositor.

   thread_safety This function must only be called from the main thread.

   sa ref window_sizelimits
   sa ref glfwSetWindowAspectRatio

   since Added in version 3.2.
 }
procedure glfwSetWindowSizeLimits(window: pGLFWwindow; minwidth: integer;
  minheight: integer; maxwidth: integer; maxheight: integer); cdecl; external GLFW_DLL;
{
 Sets the aspect ratio of the specified window.

   This function sets the required aspect ratio of the content area of the
   specified window.  If the window is full screen, the aspect ratio only takes
   effect once it is made windowed.  If the window is not resizable, this
   function does nothing.

   The aspect ratio is specified as a numerator and a denominator and both
   values must be greater than zero.  For example, the common 16:9 aspect ratio
   is specified as 16 and 9, respectively.

   If the numerator and denominator is set to `GLFW_DONT_CARE` then the aspect
   ratio limit is disabled.

   The aspect ratio is applied immediately to a windowed mode window and may
   cause it to be resized.

   param[in] window The window to set limits for.
   param[in] numer The numerator of the desired aspect ratio, or
   `GLFW_DONT_CARE`.
   param[in] denom The denominator of the desired aspect ratio, or
   `GLFW_DONT_CARE`.

   errors Possible errors include ref GLFW_NOT_INITIALIZED, ref
   GLFW_INVALID_VALUE and ref GLFW_PLATFORM_ERROR.

   remark If you set size limits and an aspect ratio that conflict, the
   results are undefined.

   remark wayland The aspect ratio will not be applied until the window is
   actually resized, either by the user or by the compositor.

   thread_safety This function must only be called from the main thread.

   sa ref window_sizelimits
   sa ref glfwSetWindowSizeLimits

   since Added in version 3.2.

}
procedure glfwSetWindowAspectRatio(window: pGLFWwindow; numer: integer; demon: integer);
  cdecl; external GLFW_DLL;
 {
/*! @  Sets the size of the content area of the specified window.
 *
 *  This function sets the size, in screen coordinates, of the content area of
 *  the specified window.
 *
 *  For full screen windows, this function updates the resolution of its desired
 *  video mode and switches to the video mode closest to it, without affecting
 *  the window's context.  As the context is unaffected, the bit depths of the
 *  framebuffer remain unchanged.
 *
 *  If you wish to update the refresh rate of the desired video mode in addition
 *  to its resolution, see @ref glfwSetWindowMonitor.
 *
 *  The window manager may put limits on what sizes are allowed.  GLFW cannot
 *  and should not override these limits.
 *
 *  @param[in] window The window to resize.
 *  @param[in] width The desired width, in screen coordinates, of the window
 *  content area.
 *  @param[in] height The desired height, in screen coordinates, of the window
 *  content area.
 *
 *  @errors Possible errors include @ref GLFW_NOT_INITIALIZED and @ref
 *  GLFW_PLATFORM_ERROR.
 *
 *  @remark @wayland A full screen window will not attempt to change the mode,
 *  no matter what the requested size.
 *
 *  @thread_safety This function must only be called from the main thread.
 *
 *  @sa @ref window_size
 *  @sa @ref glfwGetWindowSize
 *  @sa @ref glfwSetWindowMonitor
 *
 *  @since Added in version 1.0.
 *  @glfw3 Added window handle parameter.
 *
}
procedure glfwSetWindowSize(window: pGLFWwindow; Width, Height: integer);
  cdecl; external GLFW_DLL;

{
 Retrieves the size of the framebuffer of the specified window.

   This function retrieves the size, in pixels, of the framebuffer of the
   specified window.  If you wish to retrieve the size of the window in screen
   coordinates, see ref glfwGetWindowSize.

   Any or all of the size arguments may be `NULL`.  If an error occurs, all
   non-`NULL` size arguments will be set to zero.

   param[in] window The window whose framebuffer to query.
   param[out] width Where to store the width, in pixels, of the framebuffer,
   or `NULL`.
   param[out] height Where to store the height, in pixels, of the framebuffer,
   or `NULL`.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref window_fbsize
   sa ref glfwSetFramebufferSizeCallback

   since Added in version 3.0.
}
procedure glfwGetFramebufferSize(window: pGLFWwindow; var Width, Height: integer);
  cdecl; external GLFW_DLL;
 {
 Retrieves the size of the frame of the window.

   This function retrieves the size, in screen coordinates, of each edge of the
   frame of the specified window.  This size includes the title bar, if the
   window has one.  The size of the frame may vary depending on the
   [window-related hints](ref window_hints_wnd) used to create it.

   Because this function retrieves the size of each window frame edge and not
   the offset along a particular coordinate axis, the retrieved values will
   always be zero or positive.

   Any or all of the size arguments may be `NULL`.  If an error occurs, all
   non-`NULL` size arguments will be set to zero.

   param[in] window The window whose frame size to query.
   param[out] left Where to store the size, in screen coordinates, of the left
   edge of the window frame, or `NULL`.
   param[out] top Where to store the size, in screen coordinates, of the top
   edge of the window frame, or `NULL`.
   param[out] right Where to store the size, in screen coordinates, of the
   right edge of the window frame, or `NULL`.
   param[out] bottom Where to store the size, in screen coordinates, of the
   bottom edge of the window frame, or `NULL`.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref window_size

   since Added in version 3.1.

 }

procedure glfwGetWindowFrameSize(window: PGLFWwindow;
  var left, top, right, bottom: integer); cdecl; external GLFW_DLL;


{
 Retrieves the content scale for the specified window.

   This function retrieves the content scale for the specified window.  The
   content scale is the ratio between the current DPI and the platform's
   default DPI.  This is especially important for text and any UI elements.  If
   the pixel dimensions of your UI scaled by this look appropriate on your
   machine then it should appear at a reasonable size on other machines
   regardless of their DPI and scaling settings.  This relies on the system DPI
   and scaling settings being somewhat correct.

   On systems where each monitors can have its own content scale, the window
   content scale will depend on which monitor the system considers the window
   to be on.

   param[in] window The window to query.
   param[out] xscale Where to store the x-axis content scale, or `NULL`.
   param[out] yscale Where to store the y-axis content scale, or `NULL`.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref window_scale
   sa ref glfwSetWindowContentScaleCallback
   sa ref glfwGetMonitorContentScale

   since Added in version 3.3.
}
procedure glfwGetWindowContentScale(window: pGLFWwindow; var xscale, yscale: single);
  cdecl; external GLFW_DLL;


{ Returns the opacity of the whole window.

   This function returns the opacity of the window, including any decorations.

   The opacity (or alpha) value is a positive finite number between zero and
   one, where zero is fully transparent and one is fully opaque.  If the system
   does not support whole window transparency, this function always returns one.

   The initial opacity value for newly created windows is one.

   param[in] window The window to query.
   return The opacity value of the specified window.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref window_transparency
   sa ref glfwSetWindowOpacity

   since Added in version 3.3.

}
function glfwGetWindowOpacity(window: pGLFWwindow): single; cdecl; external GLFW_DLL;

{ Sets the opacity of the whole window.

   This function sets the opacity of the window, including any decorations.

   The opacity (or alpha) value is a positive finite number between zero and
   one, where zero is fully transparent and one is fully opaque.

   The initial opacity value for newly created windows is one.

   A window created with framebuffer transparency may not use whole window
   transparency.  The results of doing this are undefined.

   param[in] window The window to set the opacity for.
   param[in] opacity The desired opacity of the specified window.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref window_transparency
   sa ref glfwGetWindowOpacity

   since Added in version 3.3.
}
procedure glfwSetWindowOpacity(monitor: pGLFWwindow; opacity: single);
  cdecl; external GLFW_DLL;

{
 Iconifies the specified window.

   This function iconifies (minimizes) the specified window if it was
   previously restored.  If the window is already iconified, this function does
   nothing.

   If the specified window is a full screen window, GLFW restores the original
   video mode of the monitor.  The window's desired video mode is set again
   when the window is restored.

   param[in] window The window to iconify.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref window_iconify
   sa ref glfwRestoreWindow
   sa ref glfwMaximizeWindow

   since Added in version 2.1.
   glfw3 Added window handle parameter.
}
procedure glfwIconifyWindow(window: pGLFWwindow); cdecl; external GLFW_DLL;

{ Restores the specified window.

   This function restores the specified window if it was previously iconified
   (minimized) or maximized.  If the window is already restored, this function
   does nothing.

   If the specified window is an iconified full screen window, its desired
   video mode is set again for its monitor when the window is restored.

   param[in] window The window to restore.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref window_iconify
   sa ref glfwIconifyWindow
   sa ref glfwMaximizeWindow

   since Added in version 2.1.
   glfw3 Added window handle parameter.
}
procedure glfwRestoreWindow(window: pGLFWwindow); cdecl; external GLFW_DLL;

{
 Maximizes the specified window.

   This function maximizes the specified window if it was previously not
   maximized.  If the window is already maximized, this function does nothing.

   If the specified window is a full screen window, this function does nothing.

   param[in] window The window to maximize.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   par Thread Safety
   This function may only be called from the main thread.

   sa ref window_iconify
   sa ref glfwIconifyWindow
   sa ref glfwRestoreWindow

   since Added in GLFW 3.2.

}
procedure glfwMaximizeWindow(window: pGLFWwindow); cdecl; external GLFW_DLL;

{
 Makes the specified window visible.

   This function makes the specified window visible if it was previously
   hidden.  If the window is already visible or is in full screen mode, this
   function does nothing.

   By default, windowed mode windows are focused when shown
   Set the [GLFW_FOCUS_ON_SHOW](ref GLFW_FOCUS_ON_SHOW_hint) window hint
   to change this behavior for all newly created windows, or change the
   behavior for an existing window with ref glfwSetWindowAttrib.

   param[in] window The window to make visible.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   remark wayland Because Wayland wants every frame of the desktop to be
   complete, this function does not immediately make the window visible.
   Instead it will become visible the next time the window framebuffer is
   updated after this call.

   thread_safety This function must only be called from the main thread.

   sa ref window_hide
   sa ref glfwHideWindow

   since Added in version 3.0.
}
procedure glfwShowWindow(window: pGLFWwindow); cdecl; external GLFW_DLL;

{
 Hides the specified window.

   This function hides the specified window if it was previously visible.  If
   the window is already hidden or is in full screen mode, this function does
   nothing.

   param[in] window The window to hide.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref window_hide
   sa ref glfwShowWindow

   since Added in version 3.0.


}
procedure glfwHideWindow(window: pGLFWwindow); cdecl; external GLFW_DLL;

{
 Brings the specified window to front and sets input focus.

   This function brings the specified window to front and sets input focus.
   The window should already be visible and not iconified.

   By default, both windowed and full screen mode windows are focused when
   initially created.  Set the [GLFW_FOCUSED](ref GLFW_FOCUSED_hint) to
   disable this behavior.

   Also by default, windowed mode windows are focused when shown
   with ref glfwShowWindow. Set the
   [GLFW_FOCUS_ON_SHOW](ref GLFW_FOCUS_ON_SHOW_hint) to disable this behavior.

   __Do not use this function__ to steal focus from other applications unless
   you are certain that is what the user wants.  Focus stealing can be
   extremely disruptive.

   For a less disruptive way of getting the user's attention, see
   [attention requests](ref window_attention).

   param[in] window The window to give input focus.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   remark wayland It is not possible for an application to bring its windows
   to front, this function will always emit ref GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref window_focus
   sa ref window_attention

   since Added in version 3.2.
}
procedure glfwFocusWindow(window: pGLFWwindow); cdecl; external GLFW_DLL;

 { Requests user attention to the specified window.

   This function requests user attention to the specified window.  On
   platforms where this is not supported, attention is requested to the
   application as a whole.

   Once the user has given attention, usually by focusing the window or
   application, the system will end the request automatically.

   param[in] window The window to request attention to.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   remark macos Attention is requested to the application as a whole, not the
   specific window.

   thread_safety This function must only be called from the main thread.

   sa ref window_attention

   since Added in version 3.3.

}
procedure glfwRequestWindowAttention(window: pGLFWwindow); cdecl; external GLFW_DLL;

 {
 Returns the monitor that the window uses for full screen mode.

   This function returns the handle of the monitor that the specified window is
   in full screen on.

   param[in] window The window to query.
   return The monitor, or `NULL` if the window is in windowed mode or an
   [error](ref error_handling) occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   sa ref window_monitor
   sa ref glfwSetWindowMonitor

   since Added in version 3.0.

 }
function glfwGetWindowMonitor(window: pGLFWwindow): pGLFWmonitor;
  cdecl; external GLFW_DLL;


{
 Sets the mode, monitor, video mode and placement of a window.

   This function sets the monitor that the window uses for full screen mode or,
   if the monitor is `NULL`, makes it windowed mode.

   When setting a monitor, this function updates the width, height and refresh
   rate of the desired video mode and switches to the video mode closest to it.
   The window position is ignored when setting a monitor.

   When the monitor is `NULL`, the position, width and height are used to
   place the window content area.  The refresh rate is ignored when no monitor
   is specified.

   If you only wish to update the resolution of a full screen window or the
   size of a windowed mode window, see ref glfwSetWindowSize.

   When a window transitions from full screen to windowed mode, this function
   restores any previous window settings such as whether it is decorated,
   floating, resizable, has size or aspect ratio limits, etc.

   param[in] window The window whose monitor, size or video mode to set.
   param[in] monitor The desired monitor, or `NULL` to set windowed mode.
   param[in] xpos The desired x-coordinate of the upper-left corner of the
   content area.
   param[in] ypos The desired y-coordinate of the upper-left corner of the
   content area.
   param[in] width The desired with, in screen coordinates, of the content
   area or video mode.
   param[in] height The desired height, in screen coordinates, of the content
   area or video mode.
   param[in] refreshRate The desired refresh rate, in Hz, of the video mode,
   or `GLFW_DONT_CARE`.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   remark The OpenGL or OpenGL ES context will not be destroyed or otherwise
   affected by any resizing or mode switching, although you may need to update
   your viewport if the framebuffer size has changed.

   remark wayland The desired window position is ignored, as there is no way
   for an application to set this property.

   remark wayland Setting the window to full screen will not attempt to
   change the mode, no matter what the requested size or refresh rate.

   thread_safety This function must only be called from the main thread.

   sa ref window_monitor
   sa ref window_full_screen
   sa ref glfwGetWindowMonitor
   sa ref glfwSetWindowSize

   since Added in version 3.2.
}
procedure glfwSetWindowMonitor(window: pGLFWwindow; monitor: pGLFWmonitor;
  xpos, ypos, Width, Height, refreshRate: integer); cdecl; external GLFW_DLL;
  {
   Returns an attribute of the specified window.

   This function returns the value of an attribute of the specified window or
   its OpenGL or OpenGL ES context.

   param[in] window The window to query.
   param[in] attrib The [window attribute](ref window_attribs) whose value to
   return.
   return The value of the attribute, or zero if an
   [error](ref error_handling) occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED, ref
   GLFW_INVALID_ENUM and ref GLFW_PLATFORM_ERROR.

   remark Framebuffer related hints are not window attributes.  See ref
   window_attribs_fb for more information.

   remark Zero is a valid value for many window and context related
   attributes so you cannot use a return value of zero as an indication of
   errors.  However, this function should not fail as long as it is passed
   valid arguments and the library has been [initialized](ref intro_init).

   remark wayland The Wayland protocol provides no way to check whether a
   window is iconfied, so ref GLFW_ICONIFIED always returns `GLFW_FALSE`.

   thread_safety This function must only be called from the main thread.

   sa ref window_attribs
   sa ref glfwSetWindowAttrib

   since Added in version 3.0.  Replaces `glfwGetWindowParam` and
   `glfwGetGLVersion`.
 }
procedure glfwGetWindowAttrib(window: pGLFWwindow; attrib: integer);
  cdecl; external GLFW_DLL;

 {
 
 Sets an attribute of the specified window.

   This function sets the value of an attribute of the specified window.

   The supported attributes are [GLFW_DECORATED](ref GLFW_DECORATED_attrib),
   [GLFW_RESIZABLE](ref GLFW_RESIZABLE_attrib),
   [GLFW_FLOATING](ref GLFW_FLOATING_attrib),
   [GLFW_AUTO_ICONIFY](ref GLFW_AUTO_ICONIFY_attrib) and
   [GLFW_FOCUS_ON_SHOW](ref GLFW_FOCUS_ON_SHOW_attrib).

   Some of these attributes are ignored for full screen windows.  The new
   value will take effect if the window is later made windowed.

   Some of these attributes are ignored for windowed mode windows.  The new
   value will take effect if the window is later made full screen.

   param[in] window The window to set the attribute for.
   param[in] attrib A supported window attribute.
   param[in] value `GLFW_TRUE` or `GLFW_FALSE`.

   errors Possible errors include ref GLFW_NOT_INITIALIZED, ref
   GLFW_INVALID_ENUM, ref GLFW_INVALID_VALUE and ref GLFW_PLATFORM_ERROR.

   remark Calling ref glfwGetWindowAttrib will always return the latest
   value, even if that value is ignored by the current mode of the window.

   thread_safety This function must only be called from the main thread.

   sa ref window_attribs
   sa ref glfwGetWindowAttrib

   since Added in version 3.3.

   ingroup window
 }

procedure glfwSetWindowAttrib(window: pGLFWwindow; att: integer; Value: integer);
  cdecl; external GLFW_DLL;


procedure glfwGetWindowPos(window: pGLFWWindow; var xpos, ypos: integer);
  cdecl; external GLFW_DLL;


{
   Sets the user pointer of the specified window.

   This function sets the user-defined pointer of the specified window.  The
   current value is retained until the window is destroyed.  The initial value
   is `NULL`.

   param[in] window The window whose pointer to set.
   param[in] pointer The new value.

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function may be called from any thread.  Access is not
   synchronized.

   sa ref window_userptr
   sa ref glfwGetWindowUserPointer

   since Added in version 3.0.
}

procedure glfwSetWindowUserPointer(window: pGLFWwindow; userpointer: pointer);
  cdecl; external GLFW_DLL;
{
/!   Returns the user pointer of the specified window.

   This function returns the current value of the user-defined pointer of the
   specified window.  The initial value is `NULL`.

   param[in] window The window whose pointer to return.

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function may be called from any thread.  Access is not
   synchronized.

   sa ref window_userptr
   sa ref glfwSetWindowUserPointer

   since Added in version 3.0.
 }

function glfwGetWindowUserPointer(window: pGLFWwindow): Pointer;
  cdecl; external GLFW_DLL;
{
/!   Sets the position callback for the specified window.

   This function sets the position callback of the specified window, which is
   called when the window is moved.  The callback is provided with the
   position, in screen coordinates, of the upper-left corner of the content
   area of the window.

   param[in] window The window whose callback to set.
   param[in] callback The new callback, or `NULL` to remove the currently set
   callback.
   return The previously set callback, or `NULL` if no callback was set or the
   library had not been [initialized](ref intro_init).

   callback_signature
   code
   void function_name(GLFWwindow window, int xpos, int ypos)
   endcode
   For more information about the callback parameters, see the
   [function pointer type](ref GLFWwindowposfun).

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   remark wayland This callback will never be called, as there is no way for
   an application to know its global position.

   thread_safety This function must only be called from the main thread.

   sa ref window_pos

 }
function glfwSetWindowPosCallback(window: pGLFWwindow;
  cbfun: GLFWwindowposfun): pGLFWwindowposfun; cdecl; external GLFW_DLL;
 {
 /!   Sets the size callback for the specified window.

   This function sets the size callback of the specified window, which is
   called when the window is resized.  The callback is provided with the size,
   in screen coordinates, of the content area of the window.

   param[in] window The window whose callback to set.
   param[in] callback The new callback, or `NULL` to remove the currently set
   callback.
   return The previously set callback, or `NULL` if no callback was set or the
   library had not been [initialized](ref intro_init).

   callback_signature
   code
   void function_name(GLFWwindow window, int width, int height)
   endcode
   For more information about the callback parameters, see the
   [function pointer type](ref GLFWwindowsizefun).

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   sa ref window_size

   since Added in version 1.0.
   glfw3 Added window handle parameter and return value.
 }
function glfwSetWindowSizeCallback(window: pGLFWwindow;
  cbfun: GLFWwindowsizefun): pGLFWwindowsizefun; cdecl; external GLFW_DLL;
{
/!   Sets the close callback for the specified window.

   This function sets the close callback of the specified window, which is
   called when the user attempts to close the window, for example by clicking
   the close widget in the title bar.

   The close flag is set before this callback is called, but you can modify it
   at any time with ref glfwSetWindowShouldClose.

   The close callback is not triggered by ref glfwDestroyWindow.

   param[in] window The window whose callback to set.
   param[in] callback The new callback, or `NULL` to remove the currently set
   callback.
   return The previously set callback, or `NULL` if no callback was set or the
   library had not been [initialized](ref intro_init).

   callback_signature
   code
   void function_name(GLFWwindow window)
   endcode
   For more information about the callback parameters, see the
   [function pointer type](ref GLFWwindowclosefun).

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   remark macos Selecting Quit from the application menu will trigger the
   close callback for all windows.

   thread_safety This function must only be called from the main thread.

   sa ref window_close

   since Added in version 2.5.
   glfw3 Added window handle parameter and return value.

 }
function glfwSetWindowCloseCallback(window: pGLFWwindow;
  ccbfun: GLFWwindowclosefun): pGLFWwindowclosefun; cdecl; external GLFW_DLL;

{
/!   Sets the refresh callback for the specified window.

   This function sets the refresh callback of the specified window, which is
   called when the content area of the window needs to be redrawn, for example
   if the window has been exposed after having been covered by another window.

   On compositing window systems such as Aero, Compiz, Aqua or Wayland, where
   the window contents are saved off-screen, this callback may be called only
   very infrequently or never at all.

   param[in] window The window whose callback to set.
   param[in] callback The new callback, or `NULL` to remove the currently set
   callback.
   return The previously set callback, or `NULL` if no callback was set or the
   library had not been [initialized](ref intro_init).

   callback_signature
   code
   void function_name(GLFWwindow window);
   endcode
   For more information about the callback parameters, see the
   [function pointer type](ref GLFWwindowrefreshfun).

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   sa ref window_refresh

   since Added in version 2.5.
   glfw3 Added window handle parameter and return value.

 }
function glfwSetWindowRefreshCallback(window: pGLFWwindow;
  cbfun: GLFWwindowrefreshfun): pGLFWwindowrefreshfun; cdecl; external GLFW_DLL;
{
 /!   Sets the focus callback for the specified window.

   This function sets the focus callback of the specified window, which is
   called when the window gains or loses input focus.

   After the focus callback is called for a window that lost input focus,
   synthetic key and mouse button release events will be generated for all such
   that had been pressed.  For more information, see ref glfwSetKeyCallback
   and ref glfwSetMouseButtonCallback.

   param[in] window The window whose callback to set.
   param[in] callback The new callback, or `NULL` to remove the currently set
   callback.
   return The previously set callback, or `NULL` if no callback was set or the
   library had not been [initialized](ref intro_init).

   callback_signature
   code
   void function_name(GLFWwindow window, int focused)
   endcode
   For more information about the callback parameters, see the
   [function pointer type](ref GLFWwindowfocusfun).

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   sa ref window_focus

   since Added in version 3.0.

}
function glfwSetWindowFocusCallback(window: pGLFWwindow;
  cbfun: GLFWwindowfocusfun): pGLFWwindowfocusfun; cdecl; external GLFW_DLL;
 {
  /!   Sets the iconify callback for the specified window.

   This function sets the iconification callback of the specified window, which
   is called when the window is iconified or restored.

   param[in] window The window whose callback to set.
   param[in] callback The new callback, or `NULL` to remove the currently set
   callback.
   return The previously set callback, or `NULL` if no callback was set or the
   library had not been [initialized](ref intro_init).

   callback_signature
   code
   void function_name(GLFWwindow window, int iconified)
   endcode
   For more information about the callback parameters, see the
   [function pointer type](ref GLFWwindowiconifyfun).

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   remark wayland The XDG-shell protocol has no event for iconification, so
   this callback will never be called.

   thread_safety This function must only be called from the main thread.

   sa ref window_iconify

 }

function glfwSetWindowIconifyCallback(window: pGLFWwindow;
  cbfun: GLFWwindowiconifyfun): pGLFWwindowiconifyfun; cdecl; external GLFW_DLL;

{ Sets the maximize callback for the specified window.

   This function sets the maximization callback of the specified window, which
   is called when the window is maximized or restored.

   param[in] window The window whose callback to set.
   param[in] callback The new callback, or `NULL` to remove the currently set
   callback.
   return The previously set callback, or `NULL` if no callback was set or the
   library had not been [initialized](ref intro_init).

   callback_signature

   void function_name(GLFWwindow window, int maximized)
   endcode
   For more information about the callback parameters, see the
   [function pointer type](ref GLFWwindowmaximizefun).

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   sa ref window_maximize

   since Added in version 3.3.

// }

function glfwSetWindowMaximizeCallback(Windows: pGLFWwindow;
  cbfun: GLFWwindowmaximizefun): pGLFWwindowmaximizefun; cdecl; external GLFW_DLL;

{
 /!   Sets the framebuffer resize callback for the specified window.

   This function sets the framebuffer resize callback of the specified window,
   which is called when the framebuffer of the specified window is resized.

   param[in] window The window whose callback to set.
   param[in] callback The new callback, or `NULL` to remove the currently set
   callback.
   return The previously set callback, or `NULL` if no callback was set or the
   library had not been [initialized](ref intro_init).

   callback_signature
   code
   void function_name(GLFWwindow window, int width, int height)
   endcode
   For more information about the callback parameters, see the
   [function pointer type](ref GLFWframebuffersizefun).

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   sa ref window_fbsize

   since Added in version 3.0.

 /
}

function glfwSetFramebufferSizeCallback(window: pGLFWwindow;
  cbfun: GLFWframebuffersizefun): pGLFWframebuffersizefun; cdecl; external GLFW_DLL;
{
 Sets the window content scale callback for the specified window.

   This function sets the window content scale callback of the specified window,
   which is called when the content scale of the specified window changes.

   param[in] window The window whose callback to set.
   param[in] callback The new callback, or `NULL` to remove the currently set
   callback.
   return The previously set callback, or `NULL` if no callback was set or the
   library had not been [initialized](ref intro_init).

   callback_signature

   void function_name(GLFWwindow window, float xscale, float yscale)
   endcode
   For more information about the callback parameters, see the
   [function pointer type](ref GLFWwindowcontentscalefun).

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   sa ref window_scale
   sa ref glfwGetWindowContentScale

   since Added in version 3.3.

   ingroup window
}
function glfwSetWindowContentScaleCallback(window: pGLFWwindow;
  cbfun: GLFWwindowcontentscalefun): pGLFWwindowcontentscalefun;
  cdecl; external GLFW_DLL;

 {
  /!   Processes all pending events.

   This function processes only those events that are already in the event
   queue and then returns immediately.  Processing events will cause the window
   and input callbacks associated with those events to be called.

   On some platforms, a window move, resize or menu operation will cause event
   processing to block.  This is due to how event processing is designed on
   those platforms.  You can use the
   [window refresh callback](ref window_refresh) to redraw the contents of
   your window when necessary during such operations.

   Do not assume that callbacks you set will _only_ be called in response to
   event processing functions like this one.  While it is necessary to poll for
   events, window systems that require GLFW to register callbacks of its own
   can pass events to GLFW in response to many window system function calls.
   GLFW will pass those events on to the application callbacks before
   returning.

   Event processing is not required for joystick input to work.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   reentrancy This function must not be called from a callback.

   thread_safety This function must only be called from the main thread.

   sa ref events
   sa ref glfwWaitEvents
   sa ref glfwWaitEventsTimeout

   since Added in version 1.0.
 }
procedure glfwPollEvents; cdecl; external GLFW_DLL;
 {
  /!   Waits until events are queued and processes them.

   This function puts the calling thread to sleep until at least one event is
   available in the event queue.  Once one or more events are available,
   it behaves exactly like ref glfwPollEvents, i.e. the events in the queue
   are processed and the function then returns immediately.  Processing events
   will cause the window and input callbacks associated with those events to be
   called.

   Since not all events are associated with callbacks, this function may return
   without a callback having been called even if you are monitoring all
   callbacks.

   On some platforms, a window move, resize or menu operation will cause event
   processing to block.  This is due to how event processing is designed on
   those platforms.  You can use the
   [window refresh callback](ref window_refresh) to redraw the contents of
   your window when necessary during such operations.

   Do not assume that callbacks you set will _only_ be called in response to
   event processing functions like this one.  While it is necessary to poll for
   events, window systems that require GLFW to register callbacks of its own
   can pass events to GLFW in response to many window system function calls.
   GLFW will pass those events on to the application callbacks before
   returning.

   Event processing is not required for joystick input to work.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   reentrancy This function must not be called from a callback.

   thread_safety This function must only be called from the main thread.

   sa ref events
   sa ref glfwPollEvents
   sa ref glfwWaitEventsTimeout

   since Added in version 2.5.

 }
procedure glfwWaitEvents; cdecl; external GLFW_DLL;
{ Waits with timeout until events are queued and processes them.

   This function puts the calling thread to sleep until at least one event is
   available in the event queue, or until the specified timeout is reached.  If
   one or more events are available, it behaves exactly like ref
   glfwPollEvents, i.e. the events in the queue are processed and the function
   then returns immediately.  Processing events will cause the window and input
   callbacks associated with those events to be called.

   The timeout value must be a positive finite number.

   Since not all events are associated with callbacks, this function may return
   without a callback having been called even if you are monitoring all
   callbacks.

   On some platforms, a window move, resize or menu operation will cause event
   processing to block.  This is due to how event processing is designed on
   those platforms.  You can use the
   [window refresh callback](ref window_refresh) to redraw the contents of
   your window when necessary during such operations.

   Do not assume that callbacks you set will _only_ be called in response to
   event processing functions like this one.  While it is necessary to poll for
   events, window systems that require GLFW to register callbacks of its own
   can pass events to GLFW in response to many window system function calls.
   GLFW will pass those events on to the application callbacks before
   returning.

   Event processing is not required for joystick input to work.

   param[in] timeout The maximum amount of time, in seconds, to wait.

   errors Possible errors include ref GLFW_NOT_INITIALIZED, ref
   GLFW_INVALID_VALUE and ref GLFW_PLATFORM_ERROR.

   reentrancy This function must not be called from a callback.

   thread_safety This function must only be called from the main thread.

   sa ref events
   sa ref glfwPollEvents
   sa ref glfwWaitEvents

   since Added in version 3.2.

}
procedure glfwWaitEventsTimeout(timeout: double); cdecl; external GLFW_DLL;
{ Posts an empty event to the event queue.

   This function posts an empty event from the current thread to the event
   queue, causing ref glfwWaitEvents or ref glfwWaitEventsTimeout to return.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   thread_safety This function may be called from any thread.

   sa ref events
   sa ref glfwWaitEvents
   sa ref glfwWaitEventsTimeout

   since Added in version 3.1.}

procedure glfwPostEmptyEvent; cdecl; external GLFW_DLL; //Version 3.1

//========================================================================
//Input
//========================================================================
 {
 /!   Returns the value of an input option for the specified window.

   This function returns the value of an input option for the specified window.
   The mode must be one of ref GLFW_CURSOR, ref GLFW_STICKY_KEYS,
   ref GLFW_STICKY_MOUSE_BUTTONS, ref GLFW_LOCK_KEY_MODS or
   ref GLFW_RAW_MOUSE_MOTION.

   param[in] window The window to query.
   param[in] mode One of `GLFW_CURSOR`, `GLFW_STICKY_KEYS`,
   `GLFW_STICKY_MOUSE_BUTTONS`, `GLFW_LOCK_KEY_MODS` or
   `GLFW_RAW_MOUSE_MOTION`.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_INVALID_ENUM.

   thread_safety This function must only be called from the main thread.

   sa ref glfwSetInputMode

   since Added in version 3.0.
 }
function glfwGetInputMode(window: pGLFWwindow; mode: integer): integer;
  cdecl; external GLFW_DLL;
 {
  /!   Sets an input option for the specified window.

   This function sets an input mode option for the specified window.  The mode
   must be one of ref GLFW_CURSOR, ref GLFW_STICKY_KEYS,
   ref GLFW_STICKY_MOUSE_BUTTONS, ref GLFW_LOCK_KEY_MODS or
   ref GLFW_RAW_MOUSE_MOTION.

   If the mode is `GLFW_CURSOR`, the value must be one of the following cursor
   modes:
   - `GLFW_CURSOR_NORMAL` makes the cursor visible and behaving normally.
   - `GLFW_CURSOR_HIDDEN` makes the cursor invisible when it is over the
     content area of the window but does not restrict the cursor from leaving.
   - `GLFW_CURSOR_DISABLED` hides and grabs the cursor, providing virtual
     and unlimited cursor movement.  This is useful for implementing for
     example 3D camera controls.

   If the mode is `GLFW_STICKY_KEYS`, the value must be either `GLFW_TRUE` to
   enable sticky keys, or `GLFW_FALSE` to disable it.  If sticky keys are
   enabled, a key press will ensure that ref glfwGetKey returns `GLFW_PRESS`
   the next time it is called even if the key had been released before the
   call.  This is useful when you are only interested in whether keys have been
   pressed but not when or in which order.

   If the mode is `GLFW_STICKY_MOUSE_BUTTONS`, the value must be either
   `GLFW_TRUE` to enable sticky mouse buttons, or `GLFW_FALSE` to disable it.
   If sticky mouse buttons are enabled, a mouse button press will ensure that
   ref glfwGetMouseButton returns `GLFW_PRESS` the next time it is called even
   if the mouse button had been released before the call.  This is useful when
   you are only interested in whether mouse buttons have been pressed but not
   when or in which order.

   If the mode is `GLFW_LOCK_KEY_MODS`, the value must be either `GLFW_TRUE` to
   enable lock key modifier bits, or `GLFW_FALSE` to disable them.  If enabled,
   callbacks that receive modifier bits will also have the ref
   GLFW_MOD_CAPS_LOCK bit set when the event was generated with Caps Lock on,
   and the ref GLFW_MOD_NUM_LOCK bit when Num Lock was on.

   If the mode is `GLFW_RAW_MOUSE_MOTION`, the value must be either `GLFW_TRUE`
   to enable raw (unscaled and unaccelerated) mouse motion when the cursor is
   disabled, or `GLFW_FALSE` to disable it.  If raw motion is not supported,
   attempting to set this will emit ref GLFW_PLATFORM_ERROR.  Call ref
   glfwRawMouseMotionSupported to check for support.

   param[in] window The window whose input mode to set.
   param[in] mode One of `GLFW_CURSOR`, `GLFW_STICKY_KEYS`,
   `GLFW_STICKY_MOUSE_BUTTONS`, `GLFW_LOCK_KEY_MODS` or
   `GLFW_RAW_MOUSE_MOTION`.
   param[in] value The new value of the specified input mode.

   errors Possible errors include ref GLFW_NOT_INITIALIZED, ref
   GLFW_INVALID_ENUM and ref GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref glfwGetInputMode

   since Added in version 3.0.  Replaces `glfwEnable` and `glfwDisable`.
 }
procedure glfwSetInputMode(window: pGLFWwindow; mode, Value: integer);
  cdecl; external GLFW_DLL;
{ Returns whether raw mouse motion is supported.

   This function returns whether raw mouse motion is supported on the current
   system.  This status does not change after GLFW has been initialized so you
   only need to check this once.  If you attempt to enable raw motion on
   a system that does not support it, ref GLFW_PLATFORM_ERROR will be emitted.

   Raw mouse motion is closer to the actual motion of the mouse across
   a surface.  It is not affected by the scaling and acceleration applied to
   the motion of the desktop cursor.  That processing is suitable for a cursor
   while raw motion is better for controlling for example a 3D camera.  Because
   of this, raw mouse motion is only provided when the cursor is disabled.

   return `GLFW_TRUE` if raw mouse motion is supported on the current machine,
   or `GLFW_FALSE` otherwise.

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   sa ref raw_mouse_motion
   sa ref glfwSetInputMode

   since Added in version 3.3.
}

function glfwRawMouseMotionSupported(): integer; cdecl; external GLFW_DLL;
{
 Returns the layout-specific name of the specified printable key.

   This function returns the name of the specified printable key, encoded as
   UTF-8.  This is typically the character that key would produce without any
   modifier keys, intended for displaying key bindings to the user.  For dead
   keys, it is typically the diacritic it would add to a character.

   __Do not use this function__ for [text input](ref input_char).  You will
   break text input for many languages even if it happens to work for yours.

   If the key is `GLFW_KEY_UNKNOWN`, the scancode is used to identify the key,
   otherwise the scancode is ignored.  If you specify a non-printable key, or
   `GLFW_KEY_UNKNOWN` and a scancode that maps to a non-printable key, this
   function returns `NULL` but does not emit an error.

   This behavior allows you to always pass in the arguments in the
   [key callback](ref input_key) without modification.

   The printable keys are:
   - `GLFW_KEY_APOSTROPHE`
   - `GLFW_KEY_COMMA`
   - `GLFW_KEY_MINUS`
   - `GLFW_KEY_PERIOD`
   - `GLFW_KEY_SLASH`
   - `GLFW_KEY_SEMICOLON`
   - `GLFW_KEY_EQUAL`
   - `GLFW_KEY_LEFT_BRACKET`
   - `GLFW_KEY_RIGHT_BRACKET`
   - `GLFW_KEY_BACKSLASH`
   - `GLFW_KEY_WORLD_1`
   - `GLFW_KEY_WORLD_2`
   - `GLFW_KEY_0` to `GLFW_KEY_9`
   - `GLFW_KEY_A` to `GLFW_KEY_Z`
   - `GLFW_KEY_KP_0` to `GLFW_KEY_KP_9`
   - `GLFW_KEY_KP_DECIMAL`
   - `GLFW_KEY_KP_DIVIDE`
   - `GLFW_KEY_KP_MULTIPLY`
   - `GLFW_KEY_KP_SUBTRACT`
   - `GLFW_KEY_KP_ADD`
   - `GLFW_KEY_KP_EQUAL`

   Names for printable keys depend on keyboard layout, while names for
   non-printable keys are the same across layouts but depend on the application
   language and should be localized along with other user interface text.

   param[in] key The key to query, or `GLFW_KEY_UNKNOWN`.
   param[in] scancode The scancode of the key to query.
   return The UTF-8 encoded, layout-specific name of the key, or `NULL`.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   remark The contents of the returned string may change when a keyboard
   layout change event is received.

   pointer_lifetime The returned string is allocated and freed by GLFW.  You
   should not free it yourself.  It is valid until the library is terminated.

   thread_safety This function must only be called from the main thread.

   sa ref input_key_name

   since Added in version 3.2.
}
function glfwGetKeyName(key, scancode: integer): pchar; cdecl; external GLFW_DLL;
{ Returns the platform-specific scancode of the specified key.

 This function returns the platform-specific scancode of the specified key.

 If the key is `GLFW_KEY_UNKNOWN` or does not exist on the keyboard this
 method will return `-1`.

 param[in] key Any [named key](ref keys).
 return The platform-specific scancode for the key, or `-1` if an
 [error](ref error_handling) occurred.

 errors Possible errors include ref GLFW_NOT_INITIALIZED, ref
 GLFW_INVALID_ENUM and ref GLFW_PLATFORM_ERROR.

 thread_safety This function may be called from any thread.

 sa ref input_key

 since Added in version 3.3.

 ingroup input

}
function glfwGetKeyScancode(key: integer): integer; cdecl; external GLFW_DLL;
{
/!   Returns the last reported state of a keyboard key for the specified
   window.

   This function returns the last state reported for the specified key to the
   specified window.  The returned state is one of `GLFW_PRESS` or
   `GLFW_RELEASE`.  The action `GLFW_REPEAT` is only reported to the key callback.

   If the ref GLFW_STICKY_KEYS input mode is enabled, this function returns
   `GLFW_PRESS` the first time you call it for a key that was pressed, even if
   that key has already been released.

   The key functions deal with physical keys, with [key tokens](ref keys)
   named after their use on the standard US keyboard layout.  If you want to
   input text, use the Unicode character callback instead.

   The [modifier key bit masks](ref mods) are not key tokens and cannot be
   used with this function.

   __Do not use this function__ to implement [text input](ref input_char).

   param[in] window The desired window.
   param[in] key The desired [keyboard key](ref keys).  `GLFW_KEY_UNKNOWN` is
   not a valid key for this function.
   return One of `GLFW_PRESS` or `GLFW_RELEASE`.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_INVALID_ENUM.

   thread_safety This function must only be called from the main thread.

   sa ref input_key

   since Added in version 1.0.
   glfw3 Added window handle parameter.
 }
function glfwGetKey(window: pGLFWwindow; key: integer): integer;
  cdecl; external GLFW_DLL;

 {
 /!   Returns the last reported state of a mouse button for the specified
   window.

   This function returns the last state reported for the specified mouse button
   to the specified window.  The returned state is one of `GLFW_PRESS` or
   `GLFW_RELEASE`.

   If the ref GLFW_STICKY_MOUSE_BUTTONS input mode is enabled, this function
   returns `GLFW_PRESS` the first time you call it for a mouse button that was
   pressed, even if that mouse button has already been released.

   param[in] window The desired window.
   param[in] button The desired [mouse button](ref buttons).
   return One of `GLFW_PRESS` or `GLFW_RELEASE`.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_INVALID_ENUM.

   thread_safety This function must only be called from the main thread.

   sa ref input_mouse_button

   since Added in version 1.0.
   glfw3 Added window handle parameter.

 }
function glfwGetMouseButton(window: pGLFWwindow; button: integer): integer;
  cdecl; external GLFW_DLL;
{
/!   Retrieves the position of the cursor relative to the content area of
   the window.

   This function returns the position of the cursor, in screen coordinates,
   relative to the upper-left corner of the content area of the specified
   window.

   If the cursor is disabled (with `GLFW_CURSOR_DISABLED`) then the cursor
   position is unbounded and limited only by the minimum and maximum values of
   a `double`.

   The coordinate can be converted to their integer equivalents with the
   `floor` function.  Casting directly to an integer type works for positive
   coordinates, but fails for negative ones.

   Any or all of the position arguments may be `NULL`.  If an error occurs, all
   non-`NULL` position arguments will be set to zero.

   param[in] window The desired window.
   param[out] xpos Where to store the cursor x-coordinate, relative to the
   left edge of the content area, or `NULL`.
   param[out] ypos Where to store the cursor y-coordinate, relative to the to
   top edge of the content area, or `NULL`.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref cursor_pos
   sa ref glfwSetCursorPos

   since Added in version 3.0.  Replaces `glfwGetMousePos`.
}
procedure glfwGetCursorPos(window: pGLFWwindow; var xpos, ypos: double);
  cdecl; external GLFW_DLL;
 {
 /!   Sets the position of the cursor, relative to the content area of the
   window.

   This function sets the position, in screen coordinates, of the cursor
   relative to the upper-left corner of the content area of the specified
   window.  The window must have input focus.  If the window does not have
   input focus when this function is called, it fails silently.

   __Do not use this function__ to implement things like camera controls.  GLFW
   already provides the `GLFW_CURSOR_DISABLED` cursor mode that hides the
   cursor, transparently re-centers it and provides unconstrained cursor
   motion.  See ref glfwSetInputMode for more information.

   If the cursor mode is `GLFW_CURSOR_DISABLED` then the cursor position is
   unconstrained and limited only by the minimum and maximum values of
   a `double`.

   param[in] window The desired window.
   param[in] xpos The desired x-coordinate, relative to the left edge of the
   content area.
   param[in] ypos The desired y-coordinate, relative to the top edge of the
   content area.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   remark wayland This function will only work when the cursor mode is
   `GLFW_CURSOR_DISABLED`, otherwise it will do nothing.

   thread_safety This function must only be called from the main thread.

   sa ref cursor_pos
   sa ref glfwGetCursorPos

   since Added in version 3.0.  Replaces `glfwSetMousePos`.

   ingroup input
 /
 }
procedure glfwSetCursorPos(window: pGLFWwindow; xpos, ypos: double);
  cdecl; external GLFW_DLL;
 {
 /!   Creates a custom cursor.

   Creates a new custom cursor image that can be set for a window with ref
   glfwSetCursor.  The cursor can be destroyed with ref glfwDestroyCursor.
   Any remaining cursors are destroyed by ref glfwTerminate.

   The pixels are 32-bit, little-endian, non-premultiplied RGBA, i.e. eight
   bits per channel with the red channel first.  They are arranged canonically
   as packed sequential rows, starting from the top-left corner.

   The cursor hotspot is specified in pixels, relative to the upper-left corner
   of the cursor image.  Like all other coordinate systems in GLFW, the X-axis
   points to the right and the Y-axis points down.

   param[in] image The desired cursor image.
   param[in] xhot The desired x-coordinate, in pixels, of the cursor hotspot.
   param[in] yhot The desired y-coordinate, in pixels, of the cursor hotspot.
   return The handle of the created cursor, or `NULL` if an
   [error](ref error_handling) occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED, ref
   GLFW_INVALID_VALUE and ref GLFW_PLATFORM_ERROR.

   pointer_lifetime The specified image data is copied before this function
   returns.

   thread_safety This function must only be called from the main thread.

   sa ref cursor_object
   sa ref glfwDestroyCursor
   sa ref glfwCreateStandardCursor

   since Added in version 3.1.
 }

function glfwCreateCursor(const image: pGLFWimage; var xhot, yhot: integer): pGLFWcursor;
  cdecl; external GLFW_DLL;
{
/!   Creates a cursor with a standard shape.

   Returns a cursor with a [standard shape](ref shapes), that can be set for
   a window with ref glfwSetCursor.

   param[in] shape One of the [standard shapes](ref shapes).
   return A new cursor ready to use or `NULL` if an
   [error](ref error_handling) occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED, ref
   GLFW_INVALID_ENUM and ref GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref cursor_object
   sa ref glfwCreateCursor

}
function glfwCreateStandardCursor(shape: integer): pGLFWcursor; cdecl;
  external GLFW_DLL;
 {
 /!   Destroys a cursor.

   This function destroys a cursor previously created with ref
   glfwCreateCursor.  Any remaining cursors will be destroyed by ref
   glfwTerminate.

   If the specified cursor is current for any window, that window will be
   reverted to the default cursor.  This does not affect the cursor mode.

   param[in] cursor The cursor object to destroy.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   reentrancy This function must not be called from a callback.

   thread_safety This function must only be called from the main thread.

   sa ref cursor_object
   sa ref glfwCreateCursor

   since Added in version 3.1.
 }
procedure glfwDestroyCursor(cursor: pGLFWcursor); cdecl; external GLFW_DLL;
{
/!   Sets the cursor for the window.

   This function sets the cursor image to be used when the cursor is over the
   content area of the specified window.  The set cursor will only be visible
   when the [cursor mode](ref cursor_mode) of the window is
   `GLFW_CURSOR_NORMAL`.

   On some platforms, the set cursor may not be visible unless the window also
   has input focus.

   param[in] window The window to set the cursor for.
   param[in] cursor The cursor to set, or `NULL` to switch back to the default
   arrow cursor.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_PLATFORM_ERROR.

   thread_safety This function must only be called from the main thread.

   sa ref cursor_object

   since Added in version 3.1.
}
procedure glfwSetCursor(window: pGLFWwindow; cursor: pGLFWcursor);
  cdecl; external GLFW_DLL;
 {
 /!   Sets the key callback.

   This function sets the key callback of the specified window, which is called
   when a key is pressed, repeated or released.

   The key functions deal with physical keys, with layout independent
   [key tokens](ref keys) named after their values in the standard US keyboard
   layout.  If you want to input text, use the
   [character callback](ref glfwSetCharCallback) instead.

   When a window loses input focus, it will generate synthetic key release
   events for all pressed keys.  You can tell these events from user-generated
   events by the fact that the synthetic ones are generated after the focus
   loss event has been processed, i.e. after the
   [window focus callback](ref glfwSetWindowFocusCallback) has been called.

   The scancode of a key is specific to that platform or sometimes even to that
   machine.  Scancodes are intended to allow users to bind keys that don't have
   a GLFW key token.  Such keys have `key` set to `GLFW_KEY_UNKNOWN`, their
   state is not saved and so it cannot be queried with ref glfwGetKey.

   Sometimes GLFW needs to generate synthetic key events, in which case the
   scancode may be zero.

   param[in] window The window whose callback to set.
   param[in] callback The new key callback, or `NULL` to remove the currently
   set callback.
   return The previously set callback, or `NULL` if no callback was set or the
   library had not been [initialized](ref intro_init).

   callback_signature
   code
   void function_name(GLFWwindow window, int key, int scancode, int action, int mods)
   endcode
   For more information about the callback parameters, see the
   [function pointer type](ref GLFWkeyfun).

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   sa ref input_key

   since Added in version 1.0.
   glfw3 Added window handle parameter and return value.
 }
function glfwSetKeyCallback(window: pGLFWwindow; cbfun: GLFWkeyfun): pGLFWKeyFun;
  cdecl; external GLFW_DLL;
{

/!   Sets the Unicode character callback.

   This function sets the character callback of the specified window, which is
   called when a Unicode character is input.

   The character callback is intended for Unicode text input.  As it deals with
   characters, it is keyboard layout dependent, whereas the
   [key callback](ref glfwSetKeyCallback) is not.  Characters do not map 1:1
   to physical keys, as a key may produce zero, one or more characters.  If you
   want to know whether a specific physical key was pressed or released, see
   the key callback instead.

   The character callback behaves as system text input normally does and will
   not be called if modifier keys are held down that would prevent normal text
   input on that platform, for example a Super (Command) key on macOS or Alt key
   on Windows.

   param[in] window The window whose callback to set.
   param[in] callback The new callback, or `NULL` to remove the currently set
   callback.
   return The previously set callback, or `NULL` if no callback was set or the
   library had not been [initialized](ref intro_init).

   callback_signature
   code
   void function_name(GLFWwindow window, unsigned int codepoint)
   endcode
   For more information about the callback parameters, see the
   [function pointer type](ref GLFWcharfun).

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   sa ref input_char

   since Added in version 2.4.
}
function glfwSetCharCallback(window: pGLFWwindow; cdfun: GLFWcharfun): pGLFWcharfun;
  cdecl; external GLFW_DLL;
 {
 
/!   Sets the Unicode character with modifiers callback.

   This function sets the character with modifiers callback of the specified
   window, which is called when a Unicode character is input regardless of what
   modifier keys are used.

   The character with modifiers callback is intended for implementing custom
   Unicode character input.  For regular Unicode text input, see the
   [character callback](ref glfwSetCharCallback).  Like the character
   callback, the character with modifiers callback deals with characters and is
   keyboard layout dependent.  Characters do not map 1:1 to physical keys, as
   a key may produce zero, one or more characters.  If you want to know whether
   a specific physical key was pressed or released, see the
   [key callback](ref glfwSetKeyCallback) instead.

   param[in] window The window whose callback to set.
   param[in] callback The new callback, or `NULL` to remove the currently set
   callback.
   return The previously set callback, or `NULL` if no callback was set or an
   [error](ref error_handling) occurred.

   callback_signature
   code
   void function_name(GLFWwindow window, unsigned int codepoint, int mods)
   endcode
   For more information about the callback parameters, see the
   [function pointer type](ref GLFWcharmodsfun).

   deprecated Scheduled for removal in version 4.0.

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   sa ref input_char

   since Added in version 3.1.
 }
function glfwSetCharModsCallback(window: GLFWwindow;
  cbfun: PGLFWcharmodsfun): PGLFWcharmodsfun; cdecl; external GLFW_DLL; //Version 3.1
 {
 /!   Sets the mouse button callback.

   This function sets the mouse button callback of the specified window, which
   is called when a mouse button is pressed or released.

   When a window loses input focus, it will generate synthetic mouse button
   release events for all pressed mouse buttons.  You can tell these events
   from user-generated events by the fact that the synthetic ones are generated
   after the focus loss event has been processed, i.e. after the
   [window focus callback](ref glfwSetWindowFocusCallback) has been called.

   param[in] window The window whose callback to set.
   param[in] callback The new callback, or `NULL` to remove the currently set
   callback.
   return The previously set callback, or `NULL` if no callback was set or the
   library had not been [initialized](ref intro_init).

   callback_signature
   code
   void function_name(GLFWwindow window, int button, int action, int mods)
   endcode
   For more information about the callback parameters, see the
   [function pointer type](ref GLFWmousebuttonfun).

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   sa ref input_mouse_button

   since Added in version 1.0.
   glfw3 Added window handle parameter and return value.
 }
function glfwSetMouseButtonCallback(window: pGLFWwindow;
  cbfun: GLFWmousebuttonfun): pGLFWmousebuttonfun; cdecl; external GLFW_DLL;
 {
 /!   Sets the cursor position callback.

   This function sets the cursor position callback of the specified window,
   which is called when the cursor is moved.  The callback is provided with the
   position, in screen coordinates, relative to the upper-left corner of the
   content area of the window.

   param[in] window The window whose callback to set.
   param[in] callback The new callback, or `NULL` to remove the currently set
   callback.
   return The previously set callback, or `NULL` if no callback was set or the
   library had not been [initialized](ref intro_init).

   callback_signature
   code
   void function_name(GLFWwindow window, double xpos, double ypos);
   endcode
   For more information about the callback parameters, see the
   [function pointer type](ref GLFWcursorposfun).

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   sa ref cursor_pos

   since Added in version 3.0.  Replaces `glfwSetMousePosCallback`.
 }
function glfwSetCursorPosCallback(window: pGLFWwindow;
  cbfun: GLFWcursorposfun): pGLFWcursorposfun; cdecl; external GLFW_DLL;
{
/!   Sets the cursor enter/leave callback.

   This function sets the cursor boundary crossing callback of the specified
   window, which is called when the cursor enters or leaves the content area of
   the window.

   param[in] window The window whose callback to set.
   param[in] callback The new callback, or `NULL` to remove the currently set
   callback.
   return The previously set callback, or `NULL` if no callback was set or the
   library had not been [initialized](ref intro_init).

   callback_signature
   code
   void function_name(GLFWwindow window, int entered)
   endcode
   For more information about the callback parameters, see the
   [function pointer type](ref GLFWcursorenterfun).

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   sa ref cursor_enter

   since Added in version 3.0.
}
function glfwSetCursorEnterCallback(window: pGLFWwindow;
  cbfun: GLFWcursorenterfun): pGLFWcursorenterfun; cdecl; external GLFW_DLL;
 {
 /!   Sets the scroll callback.

   This function sets the scroll callback of the specified window, which is
   called when a scrolling device is used, such as a mouse wheel or scrolling
   area of a touchpad.

   The scroll callback receives all scrolling input, like that from a mouse
   wheel or a touchpad scrolling area.

   param[in] window The window whose callback to set.
   param[in] callback The new scroll callback, or `NULL` to remove the
   currently set callback.
   return The previously set callback, or `NULL` if no callback was set or the
   library had not been [initialized](ref intro_init).

   callback_signature
   code
   void function_name(GLFWwindow window, double xoffset, double yoffset)
   endcode
   For more information about the callback parameters, see the
   [function pointer type](ref GLFWscrollfun).

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   sa ref scrolling

   since Added in version 3.0.  Replaces `glfwSetMouseWheelCallback`.
 }
function glfwSetScrollCallback(window: pGLFWwindow;
  cbfun: GLFWscrollfun): pGLFWscrollfun; cdecl; external GLFW_DLL;
{
   Sets the path drop callback.
 *
 *  This function sets the path drop callback of the specified window, which is
 *  called when one or more dragged paths are dropped on the window.
 *
 *  Because the path array and its strings may have been generated specifically
 *  for that event, they are not guaranteed to be valid after the callback has
 *  returned.  If you wish to use them after the callback returns, you need to
 *  make a deep copy.
 *
 *  @param[in] window The window whose callback to set.
 *  @param[in] callback The new file drop callback, or `NULL` to remove the
 *  currently set callback.
 *  @return The previously set callback, or `NULL` if no callback was set or the
 *  library had not been [initialized](@ref intro_init).
 *
 *  @callback_signature
 *  @code
 *  void function_name(GLFWwindow* window, int path_count, const char* paths[])
 *  @endcode
 *  For more information about the callback parameters, see the
 *  [function pointer type](@ref GLFWdropfun).
 *
 *  @errors Possible errors include @ref GLFW_NOT_INITIALIZED.
 *
 *  @remark @wayland File drop is currently unimplemented.
 *
 *  @thread_safety This function must only be called from the main thread.
 *
 *  @sa @ref path_drop
 *
 *  @since Added in version 3.1.
}
function glfwSetDropCallback(window: pGLFWwindow; cbfun: GLFWdropfun): pGLFWdropfun;
  cdecl; external GLFW_DLL;
{
   Returns whether the specified joystick is present.
 *
 *  This function returns whether the specified joystick is present.
 *
 *  There is no need to call this function before other functions that accept
 *  a joystick ID, as they all check for presence before performing any other
 *  work.
 *
 *  @param[in] jid The [joystick](@ref joysticks) to query.
 *  @return `GLFW_TRUE` if the joystick is present, or `GLFW_FALSE` otherwise.
 *
 *  @errors Possible errors include @ref GLFW_NOT_INITIALIZED, @ref
 *  GLFW_INVALID_ENUM and @ref GLFW_PLATFORM_ERROR.
 *
 *  @thread_safety This function must only be called from the main thread.
 *
 *  @sa @ref joystick
 *
 *  @since Added in version 3.0.  Replaces `glfwGetJoystickParam`.
}
function glfwJoystickPresent(jid: integer): integer; cdecl; external GLFW_DLL;
 {
 Returns the values of all axes of the specified joystick.
 *
 *  This function returns the values of all axes of the specified joystick.
 *  Each element in the array is a value between -1.0 and 1.0.
 *
 *  If the specified joystick is not present this function will return `NULL`
 *  but will not generate an error.  This can be used instead of first calling
 *  @ref glfwJoystickPresent.
 *
 *  @param[in] jid The [joystick](@ref joysticks) to query.
 *  @param[out] count Where to store the number of axis values in the returned
 *  array.  This is set to zero if the joystick is not present or an error
 *  occurred.
 *  @return An array of axis values, or `NULL` if the joystick is not present or
 *  an [error](@ref error_handling) occurred.
 *
 *  @errors Possible errors include @ref GLFW_NOT_INITIALIZED, @ref
 *  GLFW_INVALID_ENUM and @ref GLFW_PLATFORM_ERROR.
 *
 *  @pointer_lifetime The returned array is allocated and freed by GLFW.  You
 *  should not free it yourself.  It is valid until the specified joystick is
 *  disconnected or the library is terminated.
 *
 *  @thread_safety This function must only be called from the main thread.
 *
 *  @sa @ref joystick_axis
 *
 *  @since Added in version 3.0.  Replaces `glfwGetJoystickPos`.
 }
function glfwGetJoystickAxes(jid: integer; var Count: integer): pfloat;
  cdecl; external GLFW_DLL;
 {
 Returns the state of all buttons of the specified joystick.
 *
 *  This function returns the state of all buttons of the specified joystick.
 *  Each element in the array is either `GLFW_PRESS` or `GLFW_RELEASE`.
 *
 *  For backward compatibility with earlier versions that did not have @ref
 *  glfwGetJoystickHats, the button array also includes all hats, each
 *  represented as four buttons.  The hats are in the same order as returned by
 *  __glfwGetJoystickHats__ and are in the order _up_, _right_, _down_ and
 *  _left_.  To disable these extra buttons, set the @ref
 *  GLFW_JOYSTICK_HAT_BUTTONS init hint before initialization.
 *
 *  If the specified joystick is not present this function will return `NULL`
 *  but will not generate an error.  This can be used instead of first calling
 *  @ref glfwJoystickPresent.
 *
 *  @param[in] jid The [joystick](@ref joysticks) to query.
 *  @param[out] count Where to store the number of button states in the returned
 *  array.  This is set to zero if the joystick is not present or an error
 *  occurred.
 *  @return An array of button states, or `NULL` if the joystick is not present
 *  or an [error](@ref error_handling) occurred.
 *
 *  @errors Possible errors include @ref GLFW_NOT_INITIALIZED, @ref
 *  GLFW_INVALID_ENUM and @ref GLFW_PLATFORM_ERROR.
 *
 *  @pointer_lifetime The returned array is allocated and freed by GLFW.  You
 *  should not free it yourself.  It is valid until the specified joystick is
 *  disconnected or the library is terminated.
 *
 *  @thread_safety This function must only be called from the main thread.
 *
 *  @sa @ref joystick_button
 *
 *  @since Added in version 2.2.
 *  @glfw3 Changed to return a dynamic array.
 }
function glfwGetJoystickButtons(jid: integer; var Count: integer): pbyte;
  cdecl; external GLFW_DLL;
{

   Returns the state of all hats of the specified joystick.

  This function returns the state of all hats of the specified joystick.
  Each element in the array is one of the following values:

  Name                  | Value
  ----                  | -----
  `GLFW_HAT_CENTERED`   | 0
  `GLFW_HAT_UP`         | 1
  `GLFW_HAT_RIGHT`      | 2
  `GLFW_HAT_DOWN`       | 4
  `GLFW_HAT_LEFT`       | 8
  `GLFW_HAT_RIGHT_UP`   | `GLFW_HAT_RIGHT` \| `GLFW_HAT_UP`
  `GLFW_HAT_RIGHT_DOWN` | `GLFW_HAT_RIGHT` \| `GLFW_HAT_DOWN`
  `GLFW_HAT_LEFT_UP`    | `GLFW_HAT_LEFT` \| `GLFW_HAT_UP`
  `GLFW_HAT_LEFT_DOWN`  | `GLFW_HAT_LEFT` \| `GLFW_HAT_DOWN`

  The diagonal directions are bitwise combinations of the primary (up, right,
  down and left) directions and you can test for these individually by ANDing
  it with the corresponding direction.





  if the specified joystick is not present this function will return `NULL`
  but will not generate an error.  This can be used instead of first calling
  ref glfwJoystickPresent.

  param[in] jid The [joystick](ref joysticks) to query.
  param[out] count Where to store the number of hat states in the returned
  array.  This is set to zero if the joystick is not present or an error
  occurred.
  return An array of hat states, or `NULL` if the joystick is not present
  or an [error](ref error_handling) occurred.

  errors Possible errors include ref GLFW_NOT_INITIALIZED, ref
  GLFW_INVALID_ENUM and ref GLFW_PLATFORM_ERROR.

  pointer_lifetime The returned array is allocated and freed by GLFW.  You
  should not free it yourself.  It is valid until the specified joystick is
  disconnected, this function is called again for that joystick or the library
  is terminated.

  thread_safety This function must only be called from the main thread.

  sa ref joystick_hat

  since Added in version 3.3.

  ingroup input


}
function glfwGetJoystickHats(jid: integer; var Count: integer): pbyte;
  cdecl; external GLFW_DLL;
function glfwGetJoystickName(jid: integer): pchar; cdecl; external GLFW_DLL;
{ Returns the SDL compatible GUID of the specified joystick.

   This function returns the SDL compatible GUID, as a UTF-8 encoded
   hexadecimal string, of the specified joystick.  The returned string is
   allocated and freed by GLFW.  You should not free it yourself.

   The GUID is what connects a joystick to a gamepad mapping.  A connected
   joystick will always have a GUID even if there is no gamepad mapping
   assigned to it.

   If the specified joystick is not present this function will return `NULL`
   but will not generate an error.  This can be used instead of first calling
   ref glfwJoystickPresent.

   The GUID uses the format introduced in SDL 2.0.5.  This GUID tries to
   uniquely identify the make and model of a joystick but does not identify
   a specific unit, e.g. all wired Xbox 360 controllers will have the same
   GUID on that platform.  The GUID for a unit may vary between platforms
   depending on what hardware information the platform specific APIs provide.

   param[in] jid The [joystick](ref joysticks) to query.
   return The UTF-8 encoded GUID of the joystick, or `NULL` if the joystick
   is not present or an [error](ref error_handling) occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED, ref
   GLFW_INVALID_ENUM and ref GLFW_PLATFORM_ERROR.

   pointer_lifetime The returned string is allocated and freed by GLFW.  You
   should not free it yourself.  It is valid until the specified joystick is
   disconnected or the library is terminated.

   thread_safety This function must only be called from the main thread.

   sa ref gamepad

   since Added in version 3.3.

   ingroup input
 /

}
function glfwGetJoystickGUID(jid: integer): pchar; cdecl; external GLFW_DLL;

{ Sets the user pointer of the specified joystick.

   This function sets the user-defined pointer of the specified joystick.  The
   current value is retained until the joystick is disconnected.  The initial
   value is `NULL`.

   This function may be called from the joystick callback, even for a joystick
   that is being disconnected.

   param[in] jid The joystick whose pointer to set.
   param[in] pointer The new value.

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function may be called from any thread.  Access is not
   synchronized.

   sa ref joystick_userptr
   sa ref glfwGetJoystickUserPointer

   since Added in version 3.3.

   ingroup input
 /
}
procedure glfwSetJoystickUserPointer(jid: integer; userpointer: Pointer);
  cdecl; external GLFW_DLL;
 { Returns the user pointer of the specified joystick.

   This function returns the current value of the user-defined pointer of the
   specified joystick.  The initial value is `NULL`.

   This function may be called from the joystick callback, even for a joystick
   that is being disconnected.

   param[in] jid The joystick whose pointer to return.

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function may be called from any thread.  Access is not
   synchronized.

   sa ref joystick_userptr
   sa ref glfwSetJoystickUserPointer

   since Added in version 3.3.

   ingroup input
 /

}
function glfwGetJoystickUserPointer(jid: integer): Pointer; cdecl; external GLFW_DLL;
{ Returns whether the specified joystick has a gamepad mapping.

   This function returns whether the specified joystick is both present and has
   a gamepad mapping.

   If the specified joystick is present but does not have a gamepad mapping
   this function will return `GLFW_FALSE` but will not generate an error.  Call
   ref glfwJoystickPresent to check if a joystick is present regardless of
   whether it has a mapping.

   param[in] jid The [joystick](ref joysticks) to query.
   return `GLFW_TRUE` if a joystick is both present and has a gamepad mapping,
   or `GLFW_FALSE` otherwise.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_INVALID_ENUM.

   thread_safety This function must only be called from the main thread.

   sa ref gamepad
   sa ref glfwGetGamepadState

   since Added in version 3.3.

   ingroup input

}
function glfwJoystickIsGamepad(jid: integer): integer; cdecl; external GLFW_DLL;
{ Sets the joystick configuration callback.

   This function sets the joystick configuration callback, or removes the
   currently set callback.  This is called when a joystick is connected to or
   disconnected from the system.

   For joystick connection and disconnection events to be delivered on all
   platforms, you need to call one of the [event processing](ref events)
   functions.  Joystick disconnection may also be detected and the callback
   called by joystick functions.  The function will then return whatever it
   returns if the joystick is not present.

   param[in] callback The new callback, or `NULL` to remove the currently set
   callback.
   return The previously set callback, or `NULL` if no callback was set or the
   library had not been [initialized](ref intro_init).

   callback_signature

   void function_name(int jid, int event)

   For more information about the callback parameters, see the
   [function pointer type](ref GLFWjoystickfun).

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function must only be called from the main thread.

   sa ref joystick_event

   since Added in version 3.2.

   ingroup input

}
function glfwSetJoystickCallback(cbfun: GLFWjoystickfun): pGLFWjoystickfun;
  cdecl; external GLFW_DLL;

{
 Adds the specified SDL_GameControllerDB gamepad mappings.

   This function parses the specified ASCII encoded string and updates the
   internal list with any gamepad mappings it finds.  This string may
   contain either a single gamepad mapping or many mappings separated by
   newlines.  The parser supports the full format of the `gamecontrollerdb.txt`
   source file including empty lines and comments.

   See ref gamepad_mapping for a description of the format.

   If there is already a gamepad mapping for a given GUID in the internal list,
   it will be replaced by the one passed to this function.  If the library is
   terminated and re-initialized the internal list will revert to the built-in
   default.

   param[in] string The string containing the gamepad mappings.
   return `GLFW_TRUE` if successful, or `GLFW_FALSE` if an
   [error](ref error_handling) occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_INVALID_VALUE.

   thread_safety This function must only be called from the main thread.

   sa ref gamepad
   sa ref glfwJoystickIsGamepad
   sa ref glfwGetGamepadName

   since Added in version 3.3.

   ingroup input


}
function glfwUpdateGamepadMappings(mappings: pchar): integer; cdecl; external GLFW_DLL;
{
 !   Returns the human-readable gamepad name for the specified joystick.

   This function returns the human-readable name of the gamepad from the
   gamepad mapping assigned to the specified joystick.

   If the specified joystick is not present or does not have a gamepad mapping
   this function will return `NULL` but will not generate an error.  Call
   ref glfwJoystickPresent to check whether it is present regardless of
   whether it has a mapping.

   param[in] jid The [joystick](ref joysticks) to query.
   return The UTF-8 encoded name of the gamepad, or `NULL` if the
   joystick is not present, does not have a mapping or an
   [error](ref error_handling) occurred.

   pointer_lifetime The returned string is allocated and freed by GLFW.  You
   should not free it yourself.  It is valid until the specified joystick is
   disconnected, the gamepad mappings are updated or the library is terminated.

   thread_safety This function must only be called from the main thread.

   sa ref gamepad
   sa ref glfwJoystickIsGamepad

   since Added in version 3.3.

   ingroup input

}
function glfwGetGamepadName(jid: integer): pchar; cdecl; external GLFW_DLL;

{ !   Retrieves the state of the specified joystick remapped as a gamepad.

   This function retrieves the state of the specified joystick remapped to
   an Xbox-like gamepad.

   If the specified joystick is not present or does not have a gamepad mapping
   this function will return `GLFW_FALSE` but will not generate an error.  Call
   ref glfwJoystickPresent to check whether it is present regardless of
   whether it has a mapping.

   The Guide button may not be available for input as it is often hooked by the
   system or the Steam client.

   Not all devices have all the buttons or axes provided by ref
   GLFWgamepadstate.  Unavailable buttons and axes will always report
   `GLFW_RELEASE` and 0.0 respectively.

   param[in] jid The [joystick](ref joysticks) to query.
   param[out] state The gamepad input state of the joystick.
   return `GLFW_TRUE` if successful, or `GLFW_FALSE` if no joystick is
   connected, it has no gamepad mapping or an [error](ref error_handling)
   occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_INVALID_ENUM.

   thread_safety This function must only be called from the main thread.

   sa ref gamepad
   sa ref glfwUpdateGamepadMappings
   sa ref glfwJoystickIsGamepad

   since Added in version 3.3.

   ingroup input


}
function glfwGetGamepadState(jid: integer; state: pGLFWgamepadstate): integer;
  cdecl; external GLFW_DLL;


//  ========================================================================
//   clipboard
//  ========================================================================
procedure glfwSetClipboardString(window: pGLFWwindow; const cbstring: pchar);
  cdecl; external GLFW_DLL;

function glfwGetClipboardString(window: pGLFWwindow): pchar; cdecl; external GLFW_DLL;

//Time
//========================================================================

function glfwGetTime(): double; cdecl; external GLFW_DLL;

procedure glfwSetTime(time: double); cdecl; external GLFW_DLL;
{
 !   Returns the current value of the raw timer.

   This function returns the current value of the raw timer, measured in
   1&nbsp; &nbsp;frequency seconds.  To get the frequency, call ref
   glfwGetTimerFrequency.

   return The value of the timer, or zero if an
   [error](ref error_handling) occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function may be called from any thread.

   sa ref time
   sa ref glfwGetTimerFrequency

   since Added in version 3.2.

   ingroup input


}
function glfwGetTimerValue(): uint64; cdecl; external GLFW_DLL;
{
 !   Returns the frequency, in Hz, of the raw timer.

   This function returns the frequency, in Hz, of the raw timer.

   return The frequency of the timer, in Hz, or zero if an
   [error](ref error_handling) occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function may be called from any thread.

   sa ref time
   sa ref glfwGetTimerValue

   since Added in version 3.2.


}

function glfwGetTimerFrequency(): uint64; cdecl; external GLFW_DLL;

{
Makes the context of the specified window current for the calling
 *  thread.
 *
 *  This function makes the OpenGL or OpenGL ES context of the specified window
 *  current on the calling thread.  A context must only be made current on
 *  a single thread at a time and each thread can have only a single current
 *  context at a time.
 *
 *  When moving a context between threads, you must make it non-current on the
 *  old thread before making it current on the new one.
 *
 *  By default, making a context non-current implicitly forces a pipeline flush.
 *  On machines that support `GL_KHR_context_flush_control`, you can control
 *  whether a context performs this flush by setting the
 *  [GLFW_CONTEXT_RELEASE_BEHAVIOR](@ref GLFW_CONTEXT_RELEASE_BEHAVIOR_hint)
 *  hint.
 *
 *  The specified window must have an OpenGL or OpenGL ES context.  Specifying
 *  a window without a context will generate a @ref GLFW_NO_WINDOW_CONTEXT
 *  error.
 *
 *  @param[in] window The window whose context to make current, or `NULL` to
 *  detach the current context.
 *
 *  @errors Possible errors include @ref GLFW_NOT_INITIALIZED, @ref
 *  GLFW_NO_WINDOW_CONTEXT and @ref GLFW_PLATFORM_ERROR.
 *
 *  @thread_safety This function may be called from any thread.
 *
 *  @sa @ref context_current
 *  @sa @ref glfwGetCurrentContext
 *
 *  @since Added in version 3.0.
}
procedure glfwMakeContextCurrent(window: pGLFWwindow); cdecl; external GLFW_DLL;

{
Returns the window whose context is current on the calling thread.
 *
 *  This function returns the window whose OpenGL or OpenGL ES context is
 *  current on the calling thread.
 *
 *  @return The window whose context is current, or `NULL` if no window's
 *  context is current.
 *
 *  @errors Possible errors include @ref GLFW_NOT_INITIALIZED.
 *
 *  @thread_safety This function may be called from any thread.
 *
 *  @sa @ref context_current
 *  @sa @ref glfwMakeContextCurrent
 *
 *  @since Added in version 3.0.
}
function glfwGetCurrentContext: pGLFWwindow; cdecl; external GLFW_DLL;
//========================================================================
//Context
//========================================================================
{
Swaps the front and back buffers of the specified window.

    This function swaps the front and back buffers of the specified window when
    rendering with OpenGL or OpenGL ES.  If the swap interval is greater than
    zero, the GPU driver waits the specified number of screen updates before
    swapping the buffers.

    The specified window must have an OpenGL or OpenGL ES context.  Specifying
    a window without a context will generate a @ref GLFW_NO_WINDOW_CONTEXT
    error.

    This function does not apply to Vulkan.  If you are rendering with Vulkan,
    see `vkQueuePresentKHR` instead.

    @param[in] window The window whose buffers to swap.

    @errors Possible errors include @ref GLFW_NOT_INITIALIZED, @ref
    GLFW_NO_WINDOW_CONTEXT and @ref GLFW_PLATFORM_ERROR.

    @remark __EGL:__ The context of the specified window must be current on the
    calling thread.

    @thread_safety This function may be called from any thread.

    @sa @ref buffer_swap
    @sa @ref glfwSwapInterval

    @since Added in version 1.0.
    @glfw3 Added window handle parameter.
}

procedure glfwSwapBuffers(window: pGLFWwindow); cdecl; external GLFW_DLL;
{
Sets the swap interval for the current context.

    This function sets the swap interval for the current OpenGL or OpenGL ES
    context, i.e. the number of screen updates to wait from the time @ref
    glfwSwapBuffers was called before swapping the buffers and returning.  This
    is sometimes called _vertical synchronization_, _vertical retrace
    synchronization_ or just _vsync_.

    A context that supports either of the `WGL_EXT_swap_control_tear` and
    `GLX_EXT_swap_control_tear` extensions also accepts _negative_ swap
    intervals, which allows the driver to swap immediately even if a frame
    arrives a little bit late.  You can check for these extensions with @ref
    glfwExtensionSupported.

    A context must be current on the calling thread.  Calling this function
    without a current context will cause a @ref GLFW_NO_CURRENT_CONTEXT error.

    This function does not apply to Vulkan.  If you are rendering with Vulkan,
    see the present mode of your swapchain instead.

    @param[in] interval The minimum number of screen updates to wait for
    until the buffers are swapped by @ref glfwSwapBuffers.

    @errors Possible errors include @ref GLFW_NOT_INITIALIZED, @ref
    GLFW_NO_CURRENT_CONTEXT and @ref GLFW_PLATFORM_ERROR.

    @remark This function is not called during context creation, leaving the
    swap interval set to whatever is the default on that platform.  This is done
    because some swap interval extensions used by GLFW do not allow the swap
    interval to be reset to zero once it has been set to a non-zero value.

    @remark Some GPU drivers do not honor the requested swap interval, either
    because of a user setting that overrides the application's request or due to
    bugs in the driver.

    @thread_safety This function may be called from any thread.

    @sa @ref buffer_swap
    @sa @ref glfwSwapBuffers

    @since Added in version 1.0.
}
procedure glfwSwapInterval(interval: integer); cdecl; external GLFW_DLL;
 {
  Returns whether the specified extension is available.

    This function returns whether the specified
    [API extension](@ref context_glext) is supported by the current OpenGL or
    OpenGL ES context.  It searches both for client API extension and context
    creation API extensions.

    A context must be current on the calling thread.  Calling this function
    without a current context will cause a @ref GLFW_NO_CURRENT_CONTEXT error.

    As this functions retrieves and searches one or more extension strings each
    call, it is recommended that you cache its results if it is going to be used
    frequently.  The extension strings will not change during the lifetime of
    a context, so there is no danger in doing this.

    This function does not apply to Vulkan.  If you are using Vulkan, see @ref
    glfwGetRequiredInstanceExtensions, `vkEnumerateInstanceExtensionProperties`
    and `vkEnumerateDeviceExtensionProperties` instead.

    @param[in] extension The ASCII encoded name of the extension.
    @return `GLFW_TRUE` if the extension is available, or `GLFW_FALSE`
    otherwise.

    @errors Possible errors include @ref GLFW_NOT_INITIALIZED, @ref
    GLFW_NO_CURRENT_CONTEXT, @ref GLFW_INVALID_VALUE and @ref
    GLFW_PLATFORM_ERROR.

    @thread_safety This function may be called from any thread.

    @sa @ref context_glext
    @sa @ref glfwGetProcAddress

    @since Added in version 1.0.
 }
function glfwExtensionSupported(extension: pchar): integer; cdecl; external GLFW_DLL;
{
Returns the address of the specified function for the current
    context.

    This function returns the address of the specified OpenGL or OpenGL ES
    [core or extension function](@ref context_glext), if it is supported
    by the current context.

    A context must be current on the calling thread.  Calling this function
    without a current context will cause a @ref GLFW_NO_CURRENT_CONTEXT error.

    This function does not apply to Vulkan.  If you are rendering with Vulkan,
    see @ref glfwGetInstanceProcAddress, `vkGetInstanceProcAddr` and
    `vkGetDeviceProcAddr` instead.

    @aram[in] procname The ASCII encoded name of the function.
    return The address of the function, or `NULL` if an
    [error](@ref error_handling) occurred.

    errors Possible errors include @ref GLFW_NOT_INITIALIZED, @ref
    GLFW_NO_CURRENT_CONTEXT and @ref GLFW_PLATFORM_ERROR.

    remark The address of a given function is not guaranteed to be the same
    between contexts.

    remark This function may return a non-`NULL` address despite the
    associated version or extension not being available.  Always check the
    context version or extension string first.

    pointer_lifetime The returned function pointer is valid until the context
    is destroyed or the library is terminated.

    thread_safety This function may be called from any thread.

    sa @ref context_glext
    sa @ref glfwExtensionSupported

    since Added in version 1.0.
 }
function glfwGetProcAddress(procname: pchar): pGLFWglproc; cdecl; external GLFW_DLL;

{    Returns whether the Vulkan loader and an ICD have been found.

   This function returns whether the Vulkan loader and any minimally functional
   ICD have been found.

   The availability of a Vulkan loader and even an ICD does not by itself
   guarantee that surface creation or even instance creation is possible.
   For example, on Fermi systems Nvidia will install an ICD that provides no
   actual Vulkan support.  Call ref glfwGetRequiredInstanceExtensions to check
   whether the extensions necessary for Vulkan surface creation are available
   and ref glfwGetPhysicalDevicePresentationSupport to check whether a queue
   family of a physical device supports image presentation.

   return `GLFW_TRUE` if Vulkan is minimally available, or `GLFW_FALSE`
   otherwise.

   errors Possible errors include ref GLFW_NOT_INITIALIZED.

   thread_safety This function may be called from any thread.

   sa ref vulkan_support

   since Added in version 3.2.

   ingroup vulkan

}

function glfwVulkanSupported(): integer; cdecl; external GLFW_DLL;




 { Returns the Vulkan instance extensions required by GLFW.

   This function returns an array of names of Vulkan instance extensions required
   by GLFW for creating Vulkan surfaces for GLFW windows.  If successful, the
   list will always contain `VK_KHR_surface`, so if you don't require any
   additional extensions you can pass this list directly to the
   `VkInstanceCreateInfo` struct.

   If Vulkan is not available on the machine, this function returns `NULL` and
   generates a ref GLFW_API_UNAVAILABLE error.  Call ref glfwVulkanSupported
   to check whether Vulkan is at least minimally available.

   If Vulkan is available but no set of extensions allowing window surface
   creation was found, this function returns `NULL`.  You may still use Vulkan
   for off-screen rendering and compute work.

   param[out] count Where to store the number of extensions in the returned
   array.  This is set to zero if an error occurred.
   return An array of ASCII encoded extension names, or `NULL` if an
   [error](ref error_handling) occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_API_UNAVAILABLE.

   remark Additional extensions may be required by future versions of GLFW.
   You should check if any extensions you wish to enable are already in the
   returned array, as it is an error to specify an extension more than once in
   the `VkInstanceCreateInfo` struct.

   remark macos This function currently supports either the
   `VK_MVK_macos_surface` extension from MoltenVK or `VK_EXT_metal_surface`
   extension.

   pointer_lifetime The returned array is allocated and freed by GLFW.  You
   should not free it yourself.  It is guaranteed to be valid only until the
   library is terminated.

   thread_safety This function may be called from any thread.

   sa ref vulkan_ext
   sa ref glfwCreateWindowSurface

   since Added in version 3.2.

   ingroup vulkan

}
function glfwGetRequiredInstanceExtensions(var Count: uint32): PPChar;
  cdecl; external GLFW_DLL;


{$IFDEF VK_VERSION_1_0}
 {
   Returns the address of the specified Vulkan instance function.

   This function returns the address of the specified Vulkan core or extension
   function for the specified instance.  If instance is set to `NULL` it can
   return any function exported from the Vulkan loader, including at least the
   following functions:

   - vkEnumerateInstanceExtensionProperties`
   - vkEnumerateInstanceLayerProperties`
   - vkCreateInstance`
   - vkGetInstanceProcAddr`

   If Vulkan is not available on the machine, this function returns `NULL` and
   generates a ref GLFW_API_UNAVAILABLE error.  Call ref glfwVulkanSupported
   to check whether Vulkan is at least minimally available.

   This function is equivalent to calling `vkGetInstanceProcAddr` with
   a platform-specific query of the Vulkan loader as a fallback.

   param[in] instance The Vulkan instance to query, or `NULL` to retrieve
   functions related to instance creation.
   param[in] procname The ASCII encoded name of the function.
   return The address of the function, or `NULL` if an
   [error](ref error_handling) occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED and ref
   GLFW_API_UNAVAILABLE.

   pointer_lifetime The returned function pointer is valid until the library
   is terminated.

   thread_safety This function may be called from any thread.

   sa ref vulkan_proc

   since Added in version 3.2.
}
function glfwGetInstanceProcAddress(instance: VkInstance;
  procname: PChar): pglfwGetInstanceProcAddress; cdecl; external GLFW_DLL;
{
 f Returns whether the specified queue family can present images.

   This function returns whether the specified queue family of the specified
   physical device supports presentation to the platform GLFW was built for.

   If Vulkan or the required window surface creation instance extensions are
   not available on the machine, or if the specified instance was not created
   with the required extensions, this function returns `GLFW_FALSE` and
   generates a ref GLFW_API_UNAVAILABLE error.  Call ref glfwVulkanSupported
   to check whether Vulkan is at least minimally available and ref
   glfwGetRequiredInstanceExtensions to check what instance extensions are
   required.

   param[in] instance The instance that the physical device belongs to.
   param[in] device The physical device that the queue family belongs to.
   param[in] queuefamily The index of the queue family to query.
   return `GLFW_TRUE` if the queue family supports presentation, or
   `GLFW_FALSE` otherwise.

   errors Possible errors include ref GLFW_NOT_INITIALIZED, ref
   GLFW_API_UNAVAILABLE and ref GLFW_PLATFORM_ERROR.

   remark macos This function currently always returns `GLFW_TRUE`, as the
   `VK_MVK_macos_surface` extension does not provide
   a `vkGetPhysicalDevicePresentationSupport` type function.

   thread_safety This function may be called from any thread.  For
   synchronization details of Vulkan objects, see the Vulkan specification.

   sa ref vulkan_present

   since Added in version 3.2.


}
function glfwGetPhysicalDevicePresentationSupport(instance: VkInstance;
  device: VkPhysicalDevice; queuefamily: UInt32): integer; cdecl; external GLFW_DLL;
 {  Creates a Vulkan surface for the specified window.

   This function creates a Vulkan surface for the specified window.

   If the Vulkan loader or at least one minimally functional ICD were not found,
   this function returns `VK_ERROR_INITIALIZATION_FAILED` and generates a ref
   GLFW_API_UNAVAILABLE error.  Call ref glfwVulkanSupported to check whether
   Vulkan is at least minimally available.

   If the required window surface creation instance extensions are not
   available or if the specified instance was not created with these extensions
   enabled, this function returns `VK_ERROR_EXTENSION_NOT_PRESENT` and
   generates a ref GLFW_API_UNAVAILABLE error.  Call ref
   glfwGetRequiredInstanceExtensions to check what instance extensions are
   required.

   The window surface cannot be shared with another API so the window must
   have been created with the [client api hint](ref GLFW_CLIENT_API_attrib)
   set to `GLFW_NO_API` otherwise it generates a ref GLFW_INVALID_VALUE error
   and returns `VK_ERROR_NATIVE_WINDOW_IN_USE_KHR`.

   The window surface must be destroyed before the specified Vulkan instance.
   It is the responsibility of the caller to destroy the window surface.  GLFW
   does not destroy it for you.  Call `vkDestroySurfaceKHR` to destroy the
   surface.

   param[in] instance The Vulkan instance to create the surface in.
   param[in] window The window to create the surface for.
   param[in] allocator The allocator to use, or `NULL` to use the default
   allocator.
   param[out] surface Where to store the handle of the surface.  This is set
   to `VK_NULL_HANDLE` if an error occurred.
   return `VK_SUCCESS` if successful, or a Vulkan error code if an
   [error](ref error_handling) occurred.

   errors Possible errors include ref GLFW_NOT_INITIALIZED, ref
   GLFW_API_UNAVAILABLE, ref GLFW_PLATFORM_ERROR and ref GLFW_INVALID_VALUE

   remark If an error occurs before the creation call is made, GLFW returns
   the Vulkan error code most appropriate for the error.  Appropriate use of
   ref glfwVulkanSupported and ref glfwGetRequiredInstanceExtensions should
   eliminate almost all occurrences of these errors.

   remark macos This function currently only supports the
   `VK_MVK_macos_surface` extension from MoltenVK.

   remark macos This function creates and sets a `CAMetalLayer` instance for
   the window content view, which is required for MoltenVK to function.

   thread_safety This function may be called from any thread.  For
   synchronization details of Vulkan objects, see the Vulkan specification.

   sa ref vulkan_surface
   sa ref glfwGetRequiredInstanceExtensions

   since Added in version 3.2.



}

function glfwCreateWindowSurface(instance: VkInstance; window: pGLFWwindow;
  var allocator: VkAllocationCallbacks; var surface: VkSurfaceKHR): VkResult;
  cdecl; external GLFW_DLL;

 {
 Sets the desired Vulkan `vkGetInstanceProcAddr` function.

 This function sets the `vkGetInstanceProcAddr` function that GLFW will use for all
 Vulkan related entry point queries.

 This feature is mostly useful on macOS, if your copy of the Vulkan loader is in
 a location where GLFW cannot find it through dynamic loading, or if you are still
 using the static library version of the loader.

 If set to `NULL`, GLFW will try to load the Vulkan loader dynamically by its standard
 name and get this function from there.  This is the default behavior.

 The standard name of the loader is `vulkan-1.dll` on Windows, `libvulkan.so.1` on
 Linux and other Unix-like systems and `libvulkan.1.dylib` on macOS.  If your code is
 also loading it via these names then you probably don't need to use this function.

 The function address you set is never reset by GLFW, but it only takes effect during
 initialization.  Once GLFW has been initialized, any updates will be ignored until the
 library is terminated and initialized again.

 @param[in] loader The address of the function to use, or `NULL`.

 @par Loader function signature
 @code
 PFN_vkVoidFunction vkGetInstanceProcAddr(VkInstance instance, const char* name)
 @endcode
 For more information about this function, see the
 [Vulkan Registry](https://www.khronos.org/registry/vulkan/).

 @errors None.

 @remark This function may be called before @ref glfwInit.

 @thread_safety This function must only be called from the main thread.

 @sa @ref vulkan_loader
 @sa @ref glfwInit

 @since Added in version 3.4.

 @ingroup init

}
procedure glfwInitVulkanLoader (loader: PFN_vkGetInstanceProcAddr);cdecl;external GLFW_DLL;

{$ENDIF}

//  ========================================================================
//   Error
//  ========================================================================
{
 Sets the error callback.

   This function sets the error callback, which is called with an error code
   and a human-readable description each time a GLFW error occurs.

   The error code is set before the callback is called.  Calling ref
   glfwGetError from the error callback will return the same value as the error
   code argument.

   The error callback is called on the thread where the error occurred.  If you
   are using GLFW from multiple threads, your error callback needs to be
   written accordingly.

   Because the description string may have been generated specifically for that
   error, it is not guaranteed to be valid after the callback has returned.  If
   you wish to use it after the callback returns, you need to make a copy.

   Once set, the error callback remains set even after the library has been
   terminated.

   param[in] callback The new callback, or `NULL` to remove the currently set
   callback.
   return The previously set callback, or `NULL` if no callback was set.

   callback_signature
   code
   void callback_name(int error_code, const char description)
   endcode
   For more information about the callback parameters, see the
   [callback pointer type](ref GLFWerrorfun).

   errors None.

   remark This function may be called before ref glfwInit.

   thread_safety This function must only be called from the main thread.

}
function glfwSetErrorCallback(cbfun: GLFWerrorfun): pGLFWerrorfun;
  cdecl; external GLFW_DLL;

implementation

end.

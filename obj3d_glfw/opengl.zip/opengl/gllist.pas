
program getversion;
 
 uses
gl,sysutils;

 
   { ----openglscreen.dll symbols----}
 function mode(x:integer;y:integer): integer; cdecl external 'openglscreen.dll' Name 'SETSCREEN';
 procedure flip() cdecl external 'openglscreen.dll' Name 'GLFLIP';
 function regulate(MyFps:integer;var fps:integer):integer cdecl external 'openglscreen.dll' Name 'REGULATE';
 function getkey:integer cdecl external 'openglscreen.dll' Name 'GETKEYPRESS';
 procedure inittext cdecl external 'openglscreen.dll' Name 'INITTEXT';
 procedure text(xpos:Integer;ypos:Integer;text:pchar;col:longword;size:Single;xres:integer;yres:integer)
 cdecl external 'openglscreen.dll' Name 'DRAWSTRING';
 function rgba(r:integer;g:integer;b:integer;a:integer):longword cdecl external 'openglscreen.dll' Name 'RGBCOL';
 procedure getmouse(var x:integer;var y:integer;var btn:integer;var wheel:integer) cdecl external 'openglscreen.dll' Name 'MOUSE';
   {--------}

 var
 s,tmp:ansistring;
 i,size,key:integer;
 A: TStringArray;
 num:pchar;

  function tally(somestring:pchar;partstring:pchar ):integer;
var
i,j,ln,lnp,count:integer;
label
skip;
begin
ln:=length(somestring);
lnp:=length(partstring);
count:=0;
for i:=0 to ln-1 do
begin
   if somestring[i] <> partstring[0] then goto skip ;
     if somestring[i] = partstring[0] then
     begin
     for j:=0 to lnp-1 do
     begin
     if somestring[j+i]<>partstring[j] then goto skip;
     end;
      count+=1;
     end ;
   skip:
end;
  tally:=count;
end; {tally}

 

 begin
 inittext;
 mode(400,200);
 glOrtho (0, 400, 200, 0,-1, 1);

 s:='';
 i:=1;

s := s+'Card: '+ ansistring(glGetString(GL_RENDERER))+chr(10);
s := s+'Manufacturer '+ansistring(glGetString(GL_VENDOR))+chr(10);
s := s+'OpenGL Version '+ansistring(glGetString(GL_VERSION))+chr(10);
s := s+ ' ' +chr(10);
s := s+'EXTENSIONS:'+chr(10);
 writeln(s);

tmp:=ansistring(glGetString(GL_EXTENSIONS));
tmp:=trim(tmp)+' ';
A := tmp.split(' ');
num:=pchar(tmp);
size:=tally(num,' ');

for i:=0 to size-1 do
begin
writeln(i+1,' ',A[i]);
end;

 i:=1;
while i=1 do
begin
 glClear(GL_COLOR_BUFFER_BIT); 
 text(20,20,'Results on console, <escape> to end . . .',rgba(255,255,255,255),1,400,200);
 key:=getkey;
 if key=27 then i:=2;
flip
end;

end.




 program cube;
 uses
 gl,glu,sysutils;



   { ----openglscreen.dll symbols----}
 function mode(x:integer;y:integer): integer; cdecl external 'openglscreen.dll' Name 'SETSCREEN';
 procedure flip() cdecl external 'openglscreen.dll' Name 'GLFLIP';
 function regulate(MyFps:integer;var fps:integer):integer cdecl external 'openglscreen.dll' Name 'REGULATE';
 function getkey:integer cdecl external 'openglscreen.dll' Name 'GETKEYPRESS';
 procedure inittext cdecl external 'openglscreen.dll' Name 'INITTEXT';
 procedure text(xpos:Integer;ypos:Integer;text:pchar;col:longword;size:Single;xres:integer;yres:integer)
 cdecl external 'openglscreen.dll' Name 'DRAWSTRING';
 function rgba(r:integer;g:integer;b:integer;a:integer):longword cdecl external 'openglscreen.dll' Name 'RGBCOL';
 procedure getmouse(var x:integer;var y:integer;var btn:integer;var wheel:integer) cdecl external 'openglscreen.dll' Name 'MOUSE';
   {--------}


    var
   i,fps,key,xres,yres:integer;
   mx,my,mbtn,mwheel:integer;
   angle: single;
   framerate,mouse:ansistring;

 procedure glsetup(xres:integer;yres:integer) ; // custom setup for the demo
 begin
    glShadeModel(GL_SMOOTH);               //  ' Enables Smooth Color Shading
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glEnable (GL_ALPHA) ;
    glEnable (GL_BLEND) ;
    glViewport(0, 0, xres, yres);       //' Set the viewport
    glMatrixMode(GL_PROJECTION) ;       //' Change Matrix Mode to Projection
    glLoadIdentity ;                    //' Reset View
    gluPerspective(45.0, xres/yres, 1.0, 100.0) ;
    glMatrixMode(GL_MODELVIEW);         //' Return to the modelview matrix
    glLoadIdentity ;                   // '  Reset View
    glclearcolor(0,0,0.3,1) ;          // ' set a background
End;


procedure DrawGlCube(rotangle:single);  //standard cube for demo
begin
    glLoadIdentity(); 
    glTranslatef(0,0,-5);
    glRotatef(rotangle, 0.5, 1.3, 0.9);           // Rotate

    glBegin(GL_QUADS);
     glcolor3f(1,0,0);
    glVertex3f( 1.0, 1.0,-1.0);            // Top right of the quad (top)
    glVertex3f(-1.0, 1.0,-1.0);            // Top left of the quad (top)
     glcolor3f(0,0,1);
    glVertex3f(-1.0, 1.0, 1.0);            // Bottom left of the quad (top)
    glVertex3f( 1.0, 1.0, 1.0);            // Bottom right of the quad (top)

     glcolor3f(0,1,0);
    glVertex3f( 1.0,-1.0, 1.0);            // Top right of the quad (bottom)
    glVertex3f(-1.0,-1.0, 1.0);            // Top left of the quad (bottom)
     glcolor3f(1,0,1);
    glVertex3f(-1.0,-1.0,-1.0);            // Bottom left of the quad (bottom)
    glVertex3f( 1.0,-1.0,-1.0);            // Bottom right of the quad (bottom)

     glcolor3f(0,0,1);
    glVertex3f( 1.0, 1.0, 1.0);            // Top right of the quad (front)
    glVertex3f(-1.0, 1.0, 1.0);            // Top left of the quad (front)
     glcolor3f(1,0,0);
    glVertex3f(-1.0,-1.0, 1.0);            // Bottom left of the quad (front)
    glVertex3f( 1.0,-1.0, 1.0);            // Bottom right of the quad (front)
    
     glcolor3f(1,0,1);
    glVertex3f( 1.0,-1.0,-1.0);            // Bottom left of the quad (back)
    glVertex3f(-1.0,-1.0,-1.0);            // Bottom right of the quad (back)
     glcolor3f(0,1,0);
    glVertex3f(-1.0, 1.0,-1.0);            // Top right of the quad (back)
    glVertex3f( 1.0, 1.0,-1.0);            // Top left of the quad (back)
    
     glcolor3f(1,1,0);
    glVertex3f(-1.0, 1.0, 1.0);            // Top right of the quad (left)
    glVertex3f(-1.0, 1.0,-1.0);            // Top left of the quad (left)
     glcolor3f(0,1,1);
    glVertex3f(-1.0,-1.0,-1.0);            // Bottom left of the quad (left)
    glVertex3f(-1.0,-1.0, 1.0);            // Bottom right of the quad (left)
    
     glcolor3f(1,1,1);
    glVertex3f( 1.0, 1.0,-1.0);            // Top right of the quad (right)
    glVertex3f( 1.0, 1.0, 1.0);            // Top left of the quad (right)
     glcolor3f(0,0,0);
    glVertex3f( 1.0,-1.0, 1.0);            // Bottom left of the quad (right)
    glVertex3f( 1.0,-1.0,-1.0);
    glend
End;


begin
inittext; //always first if text needed
i:=1;
xres:=1024;
yres:=768;
angle:=0.0;
fps:=0;

mode(xres,yres) ; // set the graphics screen size
glsetup(xres,yres);

while i=1 do
begin  {graphics loop}
getmouse(mx,my,mbtn,mwheel);
angle:=angle+0.5;           // rotate the cube

glClear(GL_COLOR_BUFFER_BIT);   // standard opengl instructions
    glEnable (GL_CULL_FACE);
    DrawGlcube(angle);


text(10,10,'Simple opengl screen with a few procedures:-',rgba(255,255,255,255),1.5,xres,yres);
text(10,35,'mode     - Set the screen resolution.',rgba(255,255,255,255),1.5,xres,yres);
text(10,60,'flip     - Always use in graphics loop.',rgba(255,255,255,255),1.5,xres,yres);
text(10,85,'regulate - Set the framerate via sleep (optional).',rgba(255,255,255,255),1.5,xres,yres);
text(10,110,'getkey   - Get a keyboard input,',rgba(255,255,255,255),1.5,xres,yres);
text(10,135,'inittext - First thing to do if you want text,',rgba(255,255,255,255),1.5,xres,yres);
text(10,160,'text     - Print to screen like here.',rgba(255,255,255,255),1.5,xres,yres);
text(10,185,'rgba     - Text colour with alpha channel.',rgba(255,255,255,155),1.5,xres,yres);
text(10,210,'getmouse - Mouse inputs.',rgba(255,255,255,255),1.5,xres,yres);
text(10,750,'press <escape> to end',rgba(255,0,0,255),1,xres,yres);

 text(100,300,'fps =',rgba(200,200,0,255),2,xres,yres);
 str(fps,framerate);
 text(190,300,pchar(framerate),rgba(200,0,0,255),2,xres,yres);

 // the mouse outputs
    str(mx,mouse);
   mouse:=mouse+' X';
 text(100,500,pchar(mouse),rgba(200,100,0,255),2,xres,yres);
     str(my,mouse);
   mouse:=mouse+' Y';
 text(100,530,pchar(mouse),rgba(200,100,0,255),2,xres,yres);
     str(mbtn,mouse);
   mouse:=mouse+' button';
 text(100,560,pchar(mouse),rgba(200,100,0,255),2,xres,yres);
     str(mwheel,mouse);
   mouse:=mouse+' wheel';
 text(100,590,pchar(mouse),rgba(200,100,0,255),2,xres,yres);


flip;  //<-- MUST do flip

sleep(regulate(90,fps));    // set to 90 frames/second (optional speed regulator)

key:=getkey;
if key=27 then i:=0;  //esc to end

end;  {of graphics loop}

end.

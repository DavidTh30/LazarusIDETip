unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Forms, Controls, OpenGLContext, GL;

type

  { TForm1 }

  TForm1 = class(TForm)
    procedure FormCreate(Sender: TObject);
  public
    procedure GLPaint(Sender: TObject);
  end;

var
  Form1: TForm1;
  GLBox: TOpenGLControl;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.FormCreate(Sender: TObject);
begin
  GLBox := TOpenGLControl.Create(Self);
  GLBox.Parent := Self;
  GLBox.Align := alClient;
  GLBox.OnPaint := @GLPaint;
  GLBox.Paint; // <<<---------- Call TOpenGLControl.Paint !!!
end;

procedure TForm1.GLPaint(Sender: TObject);
begin
  glBegin(GL_TRIANGLES);
    glVertex3f( 0, 1, 0);
    glVertex3f(-1,-1, 0);
    glVertex3f( 1,-1, 0);
  glEnd;
  GLBox.SwapBuffers;
end;

end.
